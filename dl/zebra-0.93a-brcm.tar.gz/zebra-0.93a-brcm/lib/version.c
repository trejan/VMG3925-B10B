
char *host_name = "i686-pc-linux-gnu";
