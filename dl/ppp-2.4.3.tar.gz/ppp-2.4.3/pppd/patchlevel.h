/* $Id: patchlevel.h,v 1.62 2004/11/13 12:08:01 paulus Exp $ */

#define VERSION		"2.4.3"
#define DATE		"13 November 2004"
