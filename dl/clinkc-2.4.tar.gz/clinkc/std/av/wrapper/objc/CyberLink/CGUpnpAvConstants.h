//
//  CGUpnpAvConstants.h
//  CyberLink for C
//
//  Created by Satoshi Konno on 08/07/10.
//  Copyright 2008 Satoshi Konno. All rights reserved.
//
