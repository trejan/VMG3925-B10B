//
//  ClinkAVUnitTest.h
//  ClinkUnitTest
//
//  Created by Satoshi Konno on 08/07/16.
//  Copyright 2008 CyberGarage. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import <CyberLink/UPnPAV.h>

@interface ClinkAVUnitTest : SenTestCase {
	CGUpnpAvController *dmc;
}

@end
