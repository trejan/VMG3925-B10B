//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CDmsMobilePhotoppc.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_CDmsMobilePhotoTYPE         129
#define IDD_ABOUTBOX_WIDE               200
#define IDC_STATIC_1                    201
#define IDD_OPTION                      201
#define IDC_STATIC_2                    202
#define IDC_STATIC_3                    203
#define IDS_NEW                         301
#define IDS_MENU                        302
#define IDM_NEW                         401
#define IDM_MENU                        402
#define IDC_EDIT1                       1003
#define IDC_COMBO1                      1005
#define IDC_SELECT_DIRECTORY            1006
#define ID_TOOLS_OPTION                 32771
#define ID_APP_OPTION                   32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
