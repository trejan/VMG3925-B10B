//
//  ClinkUnitTest.h
//  ClinkUnitTest
//
//  Created by Satoshi Konno on 08/07/15.
//  Copyright 2008 CyberGarage. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import <CyberLink/UPnP.h>

@interface ClinkUnitTest : SenTestCase {
	CGUpnpControlPoint *cp;
}
@end
