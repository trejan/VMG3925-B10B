#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"

zcfgRet_t natInfoSet(char *ipIface, struct json_object *tr98Jobj)
{
	objIndex_t natIntfIid;
	rdm_NatIntfSetting_t *natIntfObj = NULL;

//	printf("%s : Enter\n", __FUNCTION__);
	
	IID_INIT(natIntfIid);
	while(zcfgFeObjStructGetNext(RDM_OID_NAT_INTF_SETTING, &natIntfIid, (void **)&natIntfObj) == ZCFG_SUCCESS) {
		if(!strcmp(natIntfObj->Interface, ipIface)) {
			json_object_object_add(tr98Jobj, "NATEnabled", json_object_new_boolean(natIntfObj->Enable));
			zcfgFeObjStructFree(natIntfObj);
			return ZCFG_SUCCESS;
		}
		zcfgFeObjStructFree(natIntfObj);
	}

	/*Default value*/
	json_object_object_add(tr98Jobj, "NATEnabled", json_object_new_boolean(false));

	return ZCFG_SUCCESS;
}

zcfgRet_t defaultGwInfoSet(char *ipIface, struct json_object *tr98Jobj)
{
	objIndex_t ipv4FwdIid;
	rdm_RoutingRouterV4Fwd_t *v4FwdObj = NULL;

//	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(ipv4FwdIid);
	while(zcfgFeObjStructGetNext(RDM_OID_ROUTING_ROUTER_V4_FWD, &ipv4FwdIid, (void **)&v4FwdObj) == ZCFG_SUCCESS) {
		if(!strcmp(v4FwdObj->Interface, ipIface)) {
			json_object_object_add(tr98Jobj, "DefaultGateway", json_object_new_string(v4FwdObj->GatewayIPAddress));
			zcfgFeObjStructFree(v4FwdObj);
			return ZCFG_SUCCESS;
		}
		zcfgFeObjStructFree(v4FwdObj);
	}

	/*Default value*/
	json_object_object_add(tr98Jobj, "DefaultGateway", json_object_new_string(""));

	return ZCFG_SUCCESS;
}

zcfgRet_t dnsInfoSet(char *ipIface, struct json_object *tr98Jobj)
{
	objIndex_t dnsIid;
	rdm_DnsClientSrv_t *dnsSrvObj = NULL;

//	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(dnsIid);
	while(zcfgFeObjStructGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsIid, (void **)&dnsSrvObj) == ZCFG_SUCCESS) {
		if(!strcmp(dnsSrvObj->Interface, ipIface)) {
			json_object_object_add(tr98Jobj, "DNSEnabled", json_object_new_boolean(dnsSrvObj->Enable));
			json_object_object_add(tr98Jobj, "DNSServers", json_object_new_string(dnsSrvObj->DNSServer));
			json_object_object_add(tr98Jobj, "X_ZYXEL_DNSType", json_object_new_string(dnsSrvObj->X_ZYXEL_Type));
			zcfgFeObjStructFree(dnsSrvObj);
			return ZCFG_SUCCESS;
		}
		zcfgFeObjStructFree(dnsSrvObj);
	}

	/*Default value*/
	json_object_object_add(tr98Jobj, "DNSEnabled", json_object_new_boolean(true));
	json_object_object_add(tr98Jobj, "DNSServers", json_object_new_string(""));
	json_object_object_add(tr98Jobj, "X_ZYXEL_DNSType", json_object_new_string(""));

	return ZCFG_SUCCESS;
}


zcfgRet_t ethLinkAdd(char *ethLinkPathName, char *lowerLayer)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	rdm_EthLink_t *ethLinkObj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_ETH_LINK, &objIid, NULL)) != ZCFG_SUCCESS) {
		return ret;
	}

	sprintf(ethLinkPathName, "Ethernet.Link.%d", objIid.idx[0]);

	/*Set LowerLayer for Ethernet.Link*/
	if((ret = zcfgFeObjStructGet(RDM_OID_ETH_LINK, &objIid, (void **)&ethLinkObj)) == ZCFG_SUCCESS) {
		ethLinkObj->Enable = true;
		strcpy(ethLinkObj->LowerLayers, lowerLayer);
		if((ret = zcfgFeObjStructSet(RDM_OID_ETH_LINK, &objIid, (void *)ethLinkObj, NULL)) != ZCFG_SUCCESS) {
			printf("%s : Set Ethernet.Link LowerLayers Fail\n", __FUNCTION__);
		}

		zcfgFeObjStructFree(ethLinkObj);
	}
	else {
		return ret;
	}

	return ret;	
}

zcfgRet_t ipIfaceAdd(char *ipIfacePathName, char *lowerLayer)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	rdm_IpIface_t *ipIfaceObj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE, &objIid, NULL)) != ZCFG_SUCCESS) {
		return ret;
	}

	sprintf(ipIfacePathName, "IP.Interface.%d", objIid.idx[0] );

	/*Set LowerLayer for IP.Interface */
	if((ret = zcfgFeObjStructGet(RDM_OID_IP_IFACE, &objIid, (void **)&ipIfaceObj)) == ZCFG_SUCCESS) {
		ipIfaceObj->Enable = true;
		strcpy(ipIfaceObj->LowerLayers, lowerLayer);
		if((ret = zcfgFeObjStructSet(RDM_OID_IP_IFACE, &objIid, (void *)ipIfaceObj, NULL)) != ZCFG_SUCCESS) {
			printf("%s : Set IP.Interface LowerLayers Fail\n", __FUNCTION__);
		}
		else {
			printf("%s : Set IP.Interface LowerLayers Success\n", __FUNCTION__);
		}

		zcfgFeObjStructFree(ipIfaceObj);
	}
	else {
		printf("%s : Get IP.Interface fail\n", __FUNCTION__);
		return ret;
	}
	
	return ret;
}

zcfgRet_t pppIfaceAdd(char *pppIfacePathName, char *lowerLayer)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	rdm_PppIface_t *pppIfaceObj = NULL;
	char ipIfacePathName[32] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_PPP_IFACE, &objIid, NULL)) != ZCFG_SUCCESS) {
		return ret;
	}

	sprintf(pppIfacePathName, "PPP.Interface.%d", objIid.idx[0] );

	/*Set LowerLayer for PPP.Interface */
	if((ret = zcfgFeObjStructGet(RDM_OID_PPP_IFACE, &objIid, (void **)&pppIfaceObj)) == ZCFG_SUCCESS) {
		//pppIfaceObj->Enable = true;
		strcpy(pppIfaceObj->LowerLayers, lowerLayer);
		if((ret = zcfgFeObjStructSet(RDM_OID_PPP_IFACE, &objIid, (void *)pppIfaceObj, NULL)) != ZCFG_SUCCESS) {
			printf("%s : Set PPP.Interface LowerLayers Fail\n", __FUNCTION__);
		}

		zcfgFeObjStructFree(pppIfaceObj);
	}
	else {
		return ret;
	}

	/*Add Device.IP.Interface.i*/
	ret = ipIfaceAdd(ipIfacePathName, pppIfacePathName);

	return ret;
}

void addDhcpObj(char *devIpIface)
{
	zcfgRet_t ret;
        objIndex_t objIid;
        rdm_Dhcpv4Client_t *dhcpv4Obj = NULL;
	bool found = false;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	while((ret = zcfgFeObjStructGetNext(RDM_OID_DHCPV4_CLIENT, &objIid, (void **)&dhcpv4Obj)) == ZCFG_SUCCESS) {
		/*Search a DHCPv4 Client Object whose value of Interface is empty*/
		if(!strcmp(dhcpv4Obj->Interface, "")) {
			found = true;
			dhcpv4Obj->Enable = true;
			strcpy(dhcpv4Obj->Interface, devIpIface);
			if(zcfgFeObjStructSet(RDM_OID_DHCPV4_CLIENT, &objIid, (void *)dhcpv4Obj, NULL) != ZCFG_SUCCESS) {
				printf("Set DHCPv4.Clien Fail\n");
			}
			zcfgFeObjStructFree(dhcpv4Obj);
			return;
		}
	}

        IID_INIT(objIid);
        if(zcfgFeObjStructAdd(RDM_OID_DHCPV4_CLIENT, &objIid, NULL) == ZCFG_SUCCESS) {
                printf("Add DHCPv4 Client Success\n");
                if(zcfgFeObjStructGet(RDM_OID_DHCPV4_CLIENT, &objIid, (void **)&dhcpv4Obj) == ZCFG_SUCCESS) {
                        dhcpv4Obj->Enable = true;
                        strcpy(dhcpv4Obj->Interface, devIpIface);
                        if(zcfgFeObjStructSet(RDM_OID_DHCPV4_CLIENT, &objIid, (void *)dhcpv4Obj, NULL) == ZCFG_SUCCESS) {
                                printf("Set DHCPv4 Client Success\n");
                        }
                        else {
                                printf("Set DHCPv4 Client Fail\n");
                        }
                        zcfgFeObjStructFree(dhcpv4Obj);
                }
                else {
                        printf("Get DHCPv4 Client Fail\n");
                }
        }
        else {
                printf("Add DHCPv4 Client Fail\n");
        }
}

zcfgRet_t setDhcpObj(char *devIpIface, bool enable)
{
	zcfgRet_t ret;
	objIndex_t dhcpcv4Iid;
	rdm_Dhcpv4Client_t *dhcpc4Obj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(dhcpcv4Iid);
	while((ret = zcfgFeObjStructGetNext(RDM_OID_DHCPV4_CLIENT, &dhcpcv4Iid, (void **)&dhcpc4Obj)) == ZCFG_SUCCESS) {
		if(!strcmp(dhcpc4Obj->Interface, devIpIface)) {
			dhcpc4Obj->Enable = enable;
			if(zcfgFeObjStructSet(RDM_OID_DHCPV4_CLIENT, &dhcpcv4Iid, (void *)dhcpc4Obj, NULL) != ZCFG_SUCCESS) {
				printf("Set DHCPv4.Clien Fail\n");
				zcfgFeObjStructFree(dhcpc4Obj);
				return ZCFG_INTERNAL_ERROR;
			}
			zcfgFeObjStructFree(dhcpc4Obj);
			return ZCFG_SUCCESS;
		}
		zcfgFeObjStructFree(dhcpc4Obj);
	}
	
	return ZCFG_NO_SUCH_OBJECT;
}

zcfgRet_t ipaddrSet(char *devIpIface, objIndex_t *ipIfIid, const char *addrType, struct json_object *tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t v4AddrIid;
	rdm_IpIfaceV4Addr_t *v4AddrObj = NULL;
	struct json_object *paramValue = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(v4AddrIid);
	if(zcfgFeSubInStructGetNext(RDM_OID_IP_IFACE_V4_ADDR, ipIfIid, &v4AddrIid, (void **)&v4AddrObj) == ZCFG_SUCCESS) {
		/*IPv4Address already exist*/
		printf("%s : IPv4Address already exists\n", __FUNCTION__);
		if(!strcmp(v4AddrObj->AddressingType, "Static")) {
			if(!strcmp(addrType, "DHCP")) {
				/*Static to DHCP*/
				if(setDhcpObj(devIpIface, true) == ZCFG_NO_SUCH_OBJECT) {
					addDhcpObj(devIpIface);
				}
			}
			else {
				/*Static to Static*/
				v4AddrObj->Enable = true;
				paramValue = json_object_object_get(tr98Jobj, "ExternalIPAddress");
				if(paramValue != NULL) {
					strcpy(v4AddrObj->IPAddress, json_object_get_string(paramValue));
				}

				paramValue = json_object_object_get(tr98Jobj, "SubnetMask");
				if(paramValue != NULL) {
					strcpy(v4AddrObj->SubnetMask, json_object_get_string(paramValue));
				}

				if(zcfgFeObjStructSet(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, (void *)v4AddrObj, NULL) != ZCFG_SUCCESS) {
					printf("%s : Set IPv4Address Fail\n", __FUNCTION__);
					zcfgFeObjStructFree(v4AddrObj);
					return ZCFG_INTERNAL_ERROR;
				}
			}

			zcfgFeObjStructFree(v4AddrObj);
		}
		else if(!strcmp(v4AddrObj->AddressingType, "DHCP")){
			if(!strcmp(addrType, "DHCP")) {
				printf("%s : DHCP to DHCP\n", __FUNCTION__);
			}
			else {
				/*DHCP to Static*/
				/*Disable DHCP Client, the DHCP backend will delete IPv4Address automatically*/
				setDhcpObj(devIpIface, false);

				/*Add IPv4Address*/
				memcpy(&v4AddrIid, ipIfIid, sizeof(objIndex_t));
				if(zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, NULL) == ZCFG_SUCCESS) {
					printf("%s : Add IPv4Address Success\n", __FUNCTION__);
					if(zcfgFeObjStructGet(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, (void **)&v4AddrObj) == ZCFG_SUCCESS) {
						v4AddrObj->Enable = true;
						paramValue = json_object_object_get(tr98Jobj, "ExternalIPAddress");
						if(paramValue != NULL) {
							strcpy(v4AddrObj->IPAddress, json_object_get_string(paramValue));
						}

						paramValue = json_object_object_get(tr98Jobj, "SubnetMask");
						if(paramValue != NULL) {
							strcpy(v4AddrObj->SubnetMask, json_object_get_string(paramValue));
						}

						if(zcfgFeObjStructSet(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, (void *)v4AddrObj, NULL) != ZCFG_SUCCESS) {
							printf("%s : Set IPv4Address Fail\n", __FUNCTION__);
						}
						zcfgFeObjStructFree(v4AddrObj);
					}
					else {
						printf("%s : Get IPv4Address Fail\n", __FUNCTION__);
					}
				}
				else {
					printf("%s : Add IPv4Address Fail\n", __FUNCTION__);
				}
			}
		}
		else {
			printf("%s : Other : %s to %s", __FUNCTION__, v4AddrObj->AddressingType, addrType);
		}

		zcfgFeObjStructFree(v4AddrObj);
	}
	else {
		printf("%s : IPv4Address does not exist\n", __FUNCTION__);
		if(!strcmp(addrType, "DHCP")) {
			if(setDhcpObj(devIpIface, true) == ZCFG_NO_SUCH_OBJECT) {
				addDhcpObj(devIpIface);
			}
		}
		else if(!strcmp(addrType, "Static")){			
			/*Add IPv4Address*/
			printf("%s : Add Static IPv4Address\n", __FUNCTION__);
			memcpy(&v4AddrIid, ipIfIid, sizeof(objIndex_t));
			if(zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, NULL) == ZCFG_SUCCESS) {
				printf("%s : Add IPv4Address Success\n", __FUNCTION__);
				if(zcfgFeObjStructGet(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, (void **)&v4AddrObj) == ZCFG_SUCCESS) {
					v4AddrObj->Enable = true;
					paramValue = json_object_object_get(tr98Jobj, "ExternalIPAddress");
					if(paramValue != NULL) {
						strcpy(v4AddrObj->IPAddress, json_object_get_string(paramValue));
					}

					paramValue = json_object_object_get(tr98Jobj, "SubnetMask");
					if(paramValue != NULL) {
						strcpy(v4AddrObj->SubnetMask, json_object_get_string(paramValue));
					}

					if(zcfgFeObjStructSet(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, (void *)v4AddrObj, NULL) != ZCFG_SUCCESS) {
						printf("%s : Set IPv4Address Fail\n", __FUNCTION__);
						zcfgFeObjStructFree(v4AddrObj);
						return ZCFG_INTERNAL_ERROR;
					}
					zcfgFeObjStructFree(v4AddrObj);
				}
				else {
					printf("%s : Get IPv4Address Fail\n", __FUNCTION__);
				}
			}
			else {
				printf("%s : Add IPv4Address Fail\n", __FUNCTION__);
			}
		}
	}

	return ret;
}

zcfgRet_t DhcpcIidGet(char *tr98FullPathName, objIndex_t *dhcpcIid){
	zcfgRet_t ret = ZCFG_SUCCESS;
	rdm_Dhcpv4Client_t* dhcpcObj = NULL;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ipIface[32] = {0};
	char *ptr = NULL;
	bool found = false;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	
	ptr = strstr(tr98TmpName, ".DHCPClient");
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	memset(dhcpcIid, 0, sizeof(dhcpcIid));
	while(!found && (ret = zcfgFeObjStructGetNext(RDM_OID_DHCPV4_CLIENT, dhcpcIid, (void **)&dhcpcObj)) == ZCFG_SUCCESS) {
		if(!strcmp(dhcpcObj->Interface, ipIface)) {
			found = true;
		}
		zcfgFeObjStructFree(dhcpcObj);
	}

	if(!found){
		memset(dhcpcIid, 0, sizeof(dhcpcIid));
		return ZCFG_NOT_FOUND;
	}
	
	return ZCFG_SUCCESS;
}
