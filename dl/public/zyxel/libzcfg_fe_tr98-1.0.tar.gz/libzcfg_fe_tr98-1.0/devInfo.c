#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "devInfo_parameter.h"

extern tr98Object_t tr98Obj[];

/* InternetGatewayDevice.DeviceInfo */
zcfgRet_t devInfoObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	uint32_t  devInfoOid = 0;
	objIndex_t devInfoIid;
	struct json_object *devInfoObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, tr181Obj) != ZCFG_SUCCESS) {
		return ZCFG_INVALID_OBJECT;
	}
	

	IID_INIT(devInfoIid);
	devInfoOid = zcfgFeObjNameToObjId(tr181Obj, &devInfoIid);

	if((ret = zcfgFeObjJsonGet(devInfoOid, &devInfoIid, &devInfoObj)) != ZCFG_SUCCESS)
		return ret;
		

	/*fill up tr98 devInfo object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		if(strcmp(paramList->name, "SpecVersion") == 0){
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("1.0"));
			paramList++;
			continue;		
		}
		
		paramValue = json_object_object_get(devInfoObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		/*Not defined in tr181, give it a default value*/
		zcfgLog(ZCFG_LOG_DEBUG, "Can't find parameter %s in TR181\n", paramList->name);
		json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
		paramList++;
	}
	json_object_put(devInfoObj);

	return ZCFG_SUCCESS;
}
/* InternetGatewayDevice.DeviceInfo */
zcfgRet_t devInfoObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	uint32_t  devInfoOid = 0;
	objIndex_t devInfoIid;
	struct json_object *devInfoObj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);
	if(zcfgFe98To181MappingNameGet(tr98FullPathName, tr181Obj) != ZCFG_SUCCESS) {
		return ZCFG_INVALID_OBJECT;
	}
	

	IID_INIT(devInfoIid);
	devInfoOid = zcfgFeObjNameToObjId(tr181Obj, &devInfoIid);
	if((ret = zcfgFeObjJsonGet(devInfoOid, &devInfoIid, &devInfoObj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = devInfoObj;
		devInfoObj = NULL;
		devInfoObj = zcfgFeJsonMultiObjAppend(RDM_OID_DEV_INFO, &devInfoIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(devInfoObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(devInfoObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		paramList++;	
	} /*Edn while*/
	
	/*Set Device.DeviceInfo*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DEV_INFO, &devInfoIid, devInfoObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(devInfoObj);
			return ret;
		}
		json_object_put(devInfoObj);
	}


	return ZCFG_SUCCESS;
}
#if 0
zcfgRet_t devInfoObjNotify(char *tr98ObjName, struct json_object *tr181ParamObj, int handler, struct json_object **tr98NotifyInfo)
{
	bool found = false;
	char *tr181ParamList = NULL;
	char *token = NULL;
	char tr98NotifyNameList[2048] = "";
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	tr181ParamList = (char *)json_object_get_string(tr181ParamObj);

	if(*tr98NotifyInfo == NULL) {
		*tr98NotifyInfo = json_object_new_object();	
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		token = strtok(tr181ParamList, ",");
		while(token != NULL) {
			if(strcmp(token, paramList->name) == 0) {
				found = true;
				break;
			}
			token = strtok(NULL, ",");
		}

		if(found) {
			if(strlen(tr98NotifyNameList) == 0) {
				strcpy(tr98NotifyNameList, paramList->name);
			}
			else {
				strcat(tr98NotifyNameList, ",");
				strcpy(tr98NotifyNameList, paramList->name);
			}
		}
		
		paramList++;
		found = false;
	}

	if(strlen(tr98NotifyNameList) != 0) {
		json_object_object_add(*tr98NotifyInfo, tr98ObjName, json_object_new_string(tr98NotifyNameList));
	}

	return ZCFG_SUCCESS;
}
#endif

zcfgRet_t devInfoObjNotify(char *tr98ObjName, char *tr181ParamName, struct json_object *tr181ParamVal, int handler, struct json_object **tr98NotifyInfo)
{
	bool found = false;
	char tr98Notify[256] = "";
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	if(*tr98NotifyInfo == NULL) {
		*tr98NotifyInfo = json_object_new_object();
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		if(strcmp(tr181ParamName, paramList->name) == 0) {
			found = true;
			sprintf(tr98Notify, "%s.%s", tr98ObjName, paramList->name);
			break;
		}

		paramList++;
	}

	if(found) {
		json_object_object_add(*tr98NotifyInfo, tr98Notify, JSON_OBJ_COPY(tr181ParamVal));
	}

	return ZCFG_SUCCESS;
}

/* InternetGatewayDevice.DeviceInfo */
int devInfoObjAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	char tr181Obj[128] = {0};
	uint32_t  devInfoOid = 0;
	objIndex_t devInfoIid;
	int attrValue = ZCFG_NO_SUCH_PARAMETER;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, tr181Obj) != ZCFG_SUCCESS) {
		return ZCFG_INVALID_OBJECT;
	}
	

	IID_INIT(devInfoIid);
	devInfoOid = zcfgFeObjNameToObjId(tr181Obj, &devInfoIid);
		

	/*fill up tr98 devInfo object*/
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*find the matched parameter*/
		if(strcmp(paramList->name, paramName)){
			paramList++;
			continue;
		}

		/*special case*/
		if(strcmp(paramList->name, "SpecVersion") == 0){
			attrValue = 0;
			break;		
		}
		
		attrValue = zcfgFeParamAttrGetByName(devInfoOid, paramList->name);
		if(attrValue < 0 ) {
			attrValue = 0;
			break;
		}

		break;
	}

	return attrValue;
}

/* InternetGatewayDevice.DeviceInfo *//* all use the batch set, only tr069 use this action*/
zcfgRet_t devInfoObjAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	uint32_t  devInfoOid = 0;
	objIndex_t devInfoIid;
	int attrValue = 0;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);
	if(zcfgFe98To181MappingNameGet(tr98FullPathName, tr181Obj) != ZCFG_SUCCESS) {
		return ZCFG_INVALID_OBJECT;
	}
	

	IID_INIT(devInfoIid);
	devInfoOid = zcfgFeObjNameToObjId(tr181Obj, &devInfoIid);

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*find the matched parameter*/
		if(strcmp(paramList->name, paramName)){
			paramList++;
			continue;
		}
		/*special case*/
		if(strcmp(paramList->name, "SpecVersion") == 0){
			ret = ZCFG_INVALID_ARGUMENTS;
			break;		
		}
		
		attrValue = zcfgFeParamAttrGetByName(devInfoOid, paramList->name);
		if(attrValue < 0) {
			ret = ZCFG_INVALID_ARGUMENTS;
			break;
		}

		/*Write new parameter attribute from tr98 object to tr181 objects*/
		attrValue = zcfgFeNotifyAttrValSet(attrValue, newNotify);
		if( (ret = zcfgFeMultiParamAttrAppend(devInfoOid, multiAttrJobj, paramList->name, attrValue)) != ZCFG_SUCCESS){
			
			zcfgLog(ZCFG_LOG_ERR, "%s(): set %d %s attribute fail\n", __FUNCTION__, devInfoOid, paramList->name);
		}

		break;

	} /*Edn while*/
	
	return ret;
}
