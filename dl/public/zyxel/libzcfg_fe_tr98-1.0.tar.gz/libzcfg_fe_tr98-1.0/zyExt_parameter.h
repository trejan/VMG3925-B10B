tr98Parameter_t para_DnsRtEntry[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "DomainName", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "RouteInterface", PARAMETER_ATTR_WRITE, 33, json_type_string},
	{ "DNSServers", PARAMETER_ATTR_READONLY, 65, json_type_string},
	{ "GatewayAddress", PARAMETER_ATTR_READONLY, 65, json_type_string},
	{ NULL, 0, 0}
};

tr98Parameter_t para_DDns[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "ServiceProvider", PARAMETER_ATTR_WRITE, 33, json_type_string},
	{ "DDNSType", PARAMETER_ATTR_WRITE, 9, json_type_string},
	{ "HostName", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "UserName", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "Password", PARAMETER_ATTR_WRITE, 65, json_type_string},
	{ "IPAddressPolicy", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "UserIPAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "Wildcard", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Offline", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ NULL, 0, 0}
};