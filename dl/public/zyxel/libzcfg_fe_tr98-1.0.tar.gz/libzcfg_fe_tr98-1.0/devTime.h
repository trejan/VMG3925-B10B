/*Parameter*/
extern tr98Parameter_t para_Time[];

/*Handler Function*/
extern zcfgRet_t timeObjGet(char *, int, struct json_object **);
extern zcfgRet_t timeObjSet(char *, int, struct json_object *, struct json_object *);

