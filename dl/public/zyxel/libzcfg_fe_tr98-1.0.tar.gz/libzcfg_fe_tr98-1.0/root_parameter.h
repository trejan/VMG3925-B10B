tr98Parameter_t para_Root[] = {
	{ "DeviceSummary", PARAMETER_ATTR_READONLY, 1025, json_type_string},
	{ "LANDeviceNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "WANDeviceNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};
