/*Parameter*/
extern tr98Parameter_t para_L3Fwd[];
extern tr98Parameter_t para_Fwd[];

/*Handler Function*/
extern zcfgRet_t l3fwdObjGet(char *, int, struct json_object **);


extern zcfgRet_t l3fwdFwdTbObjGet(char *, int, struct json_object **);
extern zcfgRet_t l3fwdFwdTbObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t l3fwdFwdTbObjAdd(char *, int *);
extern zcfgRet_t l3fwdFwdTbObjDel(char *);