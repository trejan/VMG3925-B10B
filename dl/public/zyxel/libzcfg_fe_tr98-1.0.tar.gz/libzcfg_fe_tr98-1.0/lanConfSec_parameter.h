tr98Parameter_t para_LanConfSec[] = {
	{ "ConfigPassword", PARAMETER_ATTR_WRITE, 65, json_type_string},
	{ NULL, 0, 0, 0}
};

