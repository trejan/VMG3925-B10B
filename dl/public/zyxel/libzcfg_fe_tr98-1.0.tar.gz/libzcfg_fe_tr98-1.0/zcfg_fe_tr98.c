#include <ctype.h>

#include "zcfg_fe_tr98.h"
#include "wanDev.h"
#include "devInfo.h"
#include "devTime.h"
#include "root.h"
#include "mgmtSrv.h"
#include "lanDev.h"
#include "l2bridge.h"
#include "l3fwd.h"
#include "lanConfSec.h"
#include "zyExt.h"
#include "diag.h"
#include "firewall.h"
#include "schedule.h"
#include "qos.h"
#include "voice.h"

#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98_handle.h"

static zcfgRet_t zcfgFeTr98ClassNameGet(char *objName, char *className)
{
	char *token = NULL;
	char *tmpName = NULL;
	uint16_t len = 0, c = 0;

	if(objName == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "Object Name is NULL\n");
		return ZCFG_INVALID_OBJECT;
	}

	tmpName = (char *)malloc(strlen(objName)+1);
	strcpy(tmpName, objName);

	if(*(tmpName + strlen(tmpName) - 1) == '.') {
		printf("%s : Invalid object Name %s ended with '.'\n", __FUNCTION__, objName);
		return ZCFG_INVALID_OBJECT;
	}

	token = strtok(tmpName, ".");
	/*InternetGatewayDevice*/
	strcpy(className, token);
	token = strtok(NULL, ".");

	/* Replace number with "i" */
	while(token != NULL) {
		strcat(className, ".");

		len = strlen(token);
		for(c = 0; c < len; c++) {
			if(!isdigit(*(token + c)))
				break;
		}

		if(len == c)
			strcat(className, "i");
		else
			strcat(className, token);

		token = strtok(NULL, ".");
	}

	free(tmpName);
	
	return ZCFG_SUCCESS;
}

static int zcfgFeTr98HandlerGet(char *tr98FullPathName)
{
	int c = 0;

	while(tr98Obj[c].name != NULL) {
		if(strcmp(tr98Obj[c].name, tr98FullPathName) == 0)
			return c;

		c++;
	}
		
	return -1;
}

zcfgRet_t zcfgFeTr181IfaceStackLowerLayerGet(char *higherLayer, char *result)
{
	objIndex_t objIid;
	rdm_IfaceStack_t *ifaceStack = NULL;

	IID_INIT(objIid);
	while(zcfgFeObjStructGetNext(RDM_OID_IFACE_STACK, &objIid, (void **)&ifaceStack) == ZCFG_SUCCESS) {
		if(strcmp(ifaceStack->HigherLayer, higherLayer) == 0) {
			strcpy(result, ifaceStack->LowerLayer);
			zcfgFeObjStructFree(ifaceStack);
			return ZCFG_SUCCESS;
		}
		zcfgFeObjStructFree(ifaceStack);
	}

	return ZCFG_NO_SUCH_OBJECT;
}

zcfgRet_t zcfgFeTr181IfaceStackHigherLayerGet(char *lowerLayer, char *result)
{
	objIndex_t objIid;
	rdm_IfaceStack_t *ifaceStack = NULL;

	IID_INIT(objIid);
	while(zcfgFeObjStructGetNext(RDM_OID_IFACE_STACK, &objIid, (void **)&ifaceStack) == ZCFG_SUCCESS) {
		if(strcmp(ifaceStack->LowerLayer, lowerLayer) == 0) {
			strcpy(result, ifaceStack->HigherLayer);
			zcfgFeObjStructFree(ifaceStack);
			return ZCFG_SUCCESS;
		}
		zcfgFeObjStructFree(ifaceStack);
	}

	return ZCFG_NO_SUCH_OBJECT;
}

zcfgRet_t zcfgFeTr98ObjGet(char *tr98ObjName, struct json_object **value)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;

#if TR98_MAPPING_DEBUG
	printf("Enter %s\n", __FUNCTION__);
#endif
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

#if TR98_MAPPING_DEBUG
	printf("tr98ClassName %s\n", tr98ClassName);
#endif
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(tr98Obj[handler].getObj != NULL)
			return tr98Obj[handler].getObj(tr98ObjName, handler, value);
		else
			return ZCFG_OBJECT_WITHOUT_PARAMETER;
	}
	else {
		return ZCFG_INVALID_OBJECT;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t zcfgFeTr98ObjParamSet(char *paramName, uint32_t type, struct json_object *setJobj, char *value)
{
	struct json_object *setValue = NULL;
	
	if(setJobj == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "The setJobj pointer is NULL value\n");
		return ZCFG_INTERNAL_ERROR;
	}

	switch (type) {
		case json_type_boolean:
			setValue = json_object_new_boolean(atoi(value));
			break;
		case json_type_int:
			setValue = json_object_new_int(atoi(value));
			break;
		case json_type_uint32:
			setValue = json_object_new_int((uint32_t)atoi(value));
			break;
		case json_type_string:
			setValue = json_object_new_string(value);
			break;
		case json_type_time:
			setValue = json_object_new_string(value);
			break;
		default:
			zcfgLog(ZCFG_LOG_ERR, "Type not support\n");
			return ZCFG_ERROR_PARAMETER_TYPE;
			break;
	}

	json_object_object_add(setJobj, paramName, setValue);
	return ZCFG_SUCCESS;
}

zcfgRet_t zcfgFeTr98ObjSet(char *tr98ObjName, struct json_object *value)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;

#if TR98_MAPPING_DEBUG
	printf("Enter %s\n", __FUNCTION__);
#endif
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

#if TR98_MAPPING_DEBUG
	printf("tr98ClassName %s\n", tr98ClassName);
#endif
	//printf("value %s\n", json_object_to_json_string(value));

	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(tr98Obj[handler].setObj != NULL)
			return tr98Obj[handler].setObj(tr98ObjName, handler, value, NULL);
		else
			return ZCFG_SET_READ_ONLY_PARAM;
	}
	else {
		return ZCFG_INVALID_OBJECT;
	}
	
	return ZCFG_SUCCESS;
}

zcfgRet_t zcfgFeTr98MultiObjSet(char *tr98ObjName, struct json_object *value, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;

	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}
	
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(tr98Obj[handler].setObj != NULL)
			return tr98Obj[handler].setObj(tr98ObjName, handler, value, multiJobj);
		else
			return ZCFG_SET_READ_ONLY_PARAM;
	}
	else {
		return ZCFG_INVALID_OBJECT;
	}
	
	return ZCFG_SUCCESS;
}

zcfgRet_t zcfgFeTr98ObjAdd(char *tr98ObjName, int *idx)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;

#if TR98_MAPPING_DEBUG
	printf("Enter %s\n", __FUNCTION__);
#endif
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

#if TR98_MAPPING_DEBUG
	printf("tr98ClassName %s\n", tr98ClassName);
#endif
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(!(tr98Obj[handler].attr & OBJECT_ATTR_CREATE)){
			return ZCFG_INVALID_ARGUMENTS;
		}
		if(tr98Obj[handler].addObj != NULL)
			return tr98Obj[handler].addObj(tr98ObjName, idx);
		else
			return ZCFG_INVALID_ARGUMENTS;
	}
	else {
		return ZCFG_INVALID_OBJECT;
	}

	return ZCFG_SUCCESS;	
}

zcfgRet_t zcfgFeTr98ObjDel(char *tr98ObjName)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;

#if TR98_MAPPING_DEBUG
	printf("Enter %s\n", __FUNCTION__);
#endif
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

#if TR98_MAPPING_DEBUG
	printf("tr98ClassName %s\n", tr98ClassName);
#endif
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(!(tr98Obj[handler].attr & OBJECT_ATTR_CREATE)){
			return ZCFG_INVALID_ARGUMENTS;
		}
		if(tr98Obj[handler].delObj != NULL)
			return tr98Obj[handler].delObj(tr98ObjName);
		else
			return ZCFG_INVALID_ARGUMENTS;
	}
	else {
		return ZCFG_INVALID_OBJECT;
	}
	
	return ZCFG_SUCCESS;
}

zcfgRet_t zcfgFeTr98DefaultValueSet(struct json_object *tr98Jobj, char *paramName, int type)
{
	switch(type) {
		case json_type_uint32:
		case json_type_int:
			json_object_object_add(tr98Jobj, paramName, json_object_new_int(0));
			break;
		case json_type_string:
			json_object_object_add(tr98Jobj, paramName, json_object_new_string(""));
			break;
		case json_type_boolean:
			json_object_object_add(tr98Jobj, paramName, json_object_new_boolean(false));
			break;
		default:
			printf("%s : Unknown Type\n", __FUNCTION__);
			break;
	}

	return ZCFG_SUCCESS;
}

int zcfgFeTr98ObjAttrGet(char *tr98ObjName)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;

#if TR98_MAPPING_DEBUG
	printf("Enter %s\n", __FUNCTION__);
#endif
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}
		
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		return tr98Obj[handler].attr;
	}
	else {
		return ZCFG_INVALID_OBJECT;
	}
	
}

zcfgRet_t zcfgFeTr98Notify(struct json_object *tr181NotifyInfo, struct json_object **tr98NotifyInfo)
{
	zcfgRet_t ret;
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr181ObjName[128] = {0};
	char tr181ParamName[64] = {0};
	char tr98ClassName[128] = {0};
	char *ptr = NULL, *token = NULL, *tmp = NULL;
	int handler = 0;

#if TR98_MAPPING_DEBUG
	printf("Enter %s\n", __FUNCTION__);
#endif
	if(tr181NotifyInfo == NULL && tr98NotifyInfo == NULL) {
		printf("Invalid arguments\n");
		return ZCFG_INVALID_ARGUMENTS;
	}

	json_object_object_foreach(tr181NotifyInfo, tr181NotifyName, tr181ParamVal) {
		/*Get object path name*/
		strcpy(tr181ObjName, tr181NotifyName);
		ptr = strrchr(tr181ObjName, '.');
		if(ptr == NULL) {
			printf("Invalid arguments of %s\n", tr181NotifyName);
			return ZCFG_INVALID_ARGUMENTS;
		}
		strcpy(tr181ParamName, ptr+1);

		*ptr = '\0';

		if((ret = zcfgFe181To98MappingNameGet(tr181ObjName, tr98ObjName)) == ZCFG_SUCCESS) {
			printf("TR98 Object Name %s\n", tr98ObjName);
	
			if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
				return ret;
			}

			handler = zcfgFeTr98HandlerGet(tr98ClassName);
			if(handler != -1) {
				if(tr98Obj[handler].notify != NULL)
					ret = tr98Obj[handler].notify(tr98ObjName, tr181ParamName, tr181ParamVal, handler, tr98NotifyInfo);
			}
		}
		else { /*Not found, maybe one by one mapping*/
			/*Replace Device to InternetGatewayDevice */
			token = strtok_r(tr181ObjName, ".", &tmp);
			if(token != NULL && !strcmp(token, "Device")) {
				strcpy(tr98ObjName, "InternetGatewayDevice.");
				strcat(tr98ObjName, tmp);
			}
			else {
				printf("Invalid arguments of %s\n", tr181NotifyName);
				return ZCFG_INVALID_ARGUMENTS;
			}
			
			if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
				return ret;
			}

			handler = zcfgFeTr98HandlerGet(tr98ClassName);
			if(handler != -1) {
				if(tr98Obj[handler].notify != NULL)
					ret = tr98Obj[handler].notify(tr98ObjName, tr181ParamName, tr181ParamVal, handler, tr98NotifyInfo);
			}
		}
	}

	return ret;
}

zcfgRet_t zcfgFeTr98ParamList(char *tr98ObjName)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}
#if TR98_MAPPING_DEBUG
	printf("tr98ClassName %s\n", tr98ClassName);
#endif	
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		paramList = tr98Obj[handler].parameter;
		if(paramList == NULL)
		{
			return ZCFG_SUCCESS;
		}
		while(paramList->name != NULL) {
			printf("parameter name %s\n", paramList->name);
			paramList++;
		}
	}
	
	return ZCFG_SUCCESS;
}

int zcfgFeTr98ParamAttrGetByName(char *tr98ObjName, char *name)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(tr98Obj[handler].getAttr != NULL){
			return tr98Obj[handler].getAttr(tr98ObjName, handler, name);
		}
		else{
		paramList = tr98Obj[handler].parameter;
		if(paramList == NULL)
		{
			return ZCFG_NO_SUCH_PARAMETER;
		}
		while(paramList->name!= NULL) {
			if(strcmp(paramList->name, name) == 0){
				return paramList->attr;
			}
			paramList++;
		}
	}
	}
	
	return ZCFG_NO_SUCH_PARAMETER;
}

int zcfgFeTr98ParamAttrMultiSetByName(char *tr98ObjName, char *name, int notify, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;
	
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		if(tr98Obj[handler].setAttr != NULL){
			return tr98Obj[handler].setAttr(tr98ObjName, handler, name, notify, multiJobj);
		}
		else{
			return ZCFG_REQUEST_REJECT;
		}
	}
	
	return ZCFG_NO_SUCH_PARAMETER;
}


int zcfgFeTr98ParamTypeGetByName(char *tr98ObjName, char *name)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}
	
	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		paramList = tr98Obj[handler].parameter;
		if(paramList == NULL)
		{
			return ZCFG_NO_SUCH_PARAMETER;
		}
		while(paramList->name!= NULL) {
			if(strcmp(paramList->name, name) == 0){
				return paramList->type;
			}
			paramList++;
		}
	}
	
	return ZCFG_NO_SUCH_PARAMETER;
}

zcfgRet_t zcfgFeTr98ParamChk(char *tr98ObjName, char *name, char *value)
{
	zcfgRet_t ret;
	char tr98ClassName[128] = {0};
	int handler = 0;
	tr98Parameter_t *paramList = NULL;
	json_type type;
	char *p = NULL;
	bool found = FALSE;
	int len = 0, index = 0;

	if((ret = zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName)) != ZCFG_SUCCESS) {
		return ret;
	}

	handler = zcfgFeTr98HandlerGet(tr98ClassName);
	if(handler != -1) {
		paramList = tr98Obj[handler].parameter;
		if(paramList == NULL)
		{
			return ZCFG_NO_SUCH_PARAMETER;
		}
		while(paramList->name!= NULL) {
			if(strcmp(paramList->name, name) == 0){
				found = TRUE;
				break;
			}
			paramList++;
		}
	}
	if(!found){
		return ZCFG_NO_SUCH_PARAMETER;
	}
		
	if(paramList->attr & PARAMETER_ATTR_READONLY) {
		zcfgLog(ZCFG_LOG_ERR, "Can not set a read-only parameter %s\n", name);
		return ZCFG_SET_READ_ONLY_PARAM;
	}
	
	type = paramList->type;
	if(type == json_type_string || type == json_type_time) {
		if(strlen(value) >= paramList->len) {
			return ZCFG_INVALID_PARAM_VALUE_LENGTH;
		}
	}
	switch(type){
		case json_type_int:
			p = value;
			if(atol(value)<0){
				if(*p != '-'){
					return ZCFG_INVALID_PARAM_VALUE;
				}
				p++;
			}
			while(*p!='\0'){
				if(!isdigit(*p)){
					return ZCFG_INVALID_PARAM_VALUE;
				}
				p++;
			}
			break;
		case json_type_uint8:
		case json_type_uint16:
		case json_type_uint32:
			p = value;
			while(*p!='\0'){
				if(!isdigit(*p)){
					return ZCFG_INVALID_PARAM_VALUE;
				}
				p++;
			}
			break;
		case json_type_boolean:
			if(strcasecmp(value, "true")==0 ){
				strcpy(value, "1");
				break;
			}
			else if(strcasecmp(value, "false")==0 ){
				strcpy(value, "0");
				break;
			}
			if( (strcmp(value, "0")!=0) && (strcmp(value, "1")!=0)){
				return ZCFG_INVALID_PARAM_VALUE;
			}
			break;
		case json_type_time:/*0001-01-01T00:00:00Z*/
			len = strlen(value);
			if(len != 19 && len != 20){
				return ZCFG_INVALID_PARAM_VALUE;
			}
			p = value;
			for(index = 0; index<len; index++){
				if(index==4 || index==7){
					if(!(*p == '-')){
						return ZCFG_INVALID_PARAM_VALUE;
					}
				}
				else if(index == 10){
					if(!(*p == 'T')){
						return ZCFG_INVALID_PARAM_VALUE;
					}
				}
				else if(index == 13 || index ==16){
					if(!(*p == ':')){
						return ZCFG_INVALID_PARAM_VALUE;
					}
				}
				else if(index == 19){
					if(!(*p == 'Z')){
						return ZCFG_INVALID_PARAM_VALUE;
					}
				}
				else{
					if(!isdigit(*p)){
						return ZCFG_INVALID_PARAM_VALUE;
					}
				}	
				p++;
			}
			break;
		default:
			break;
	}
	
	return ZCFG_SUCCESS;
}

zcfgSubObjNameList_t* zcfgFeTr98SubObjNameListGet(char *tr98ObjName){
	zcfgSubObjNameList_t *head = NULL, *now = NULL, *node = NULL;
	char tr98ClassName[128] = {0};
	int c = 0;
	char *subName = NULL;
	char *ptr = NULL;
	bool find = false;
	
	if(zcfgFeTr98ClassNameGet(tr98ObjName, tr98ClassName) != ZCFG_SUCCESS) {
		return NULL;
	}
		
	while(tr98Obj[c].name != NULL) {
		find = false;
		if((strncmp(tr98Obj[c].name, tr98ClassName, strlen(tr98ClassName)) == 0) && (strlen(tr98Obj[c].name)>strlen(tr98ClassName))){
			ptr = strchr(tr98Obj[c].name+strlen(tr98ClassName)+1, '.');
			if( ptr == NULL ){
				find = true;
			}
			else if( /*index*/ strcmp(ptr, ".i") == 0){
				find = true;
			}
			if( !find){
				c++;
				continue;
			}
			
			node = (zcfgSubObjNameList_t*)malloc(sizeof(zcfgSubObjNameList_t));
			subName = tr98Obj[c].name + strlen(tr98ClassName) + 1;
			node->objName = (char *)malloc(strlen(subName)+1);
			strcpy(node->objName, subName);
			if(head == NULL) {
				node->next = NULL;
				head = node;
				now = node;
			}
			else {
				now->next = node;
				now = node;
				now->next = NULL;
			}

		}
		c++;
	}
	
	return head;
}

