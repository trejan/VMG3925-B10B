
zcfgRet_t natInfoSet(char *, struct json_object *);
zcfgRet_t defaultGwInfoSet(char *, struct json_object *);
zcfgRet_t dnsInfoSet(char *, struct json_object *);
zcfgRet_t ethLinkAdd(char *, char *);
zcfgRet_t ipIfaceAdd(char *, char *);
zcfgRet_t pppIfaceAdd(char *, char *);
void addDhcpObj(char *);
zcfgRet_t setDhcpObj(char *, bool);
zcfgRet_t ipaddrSet(char *, objIndex_t *, const char *, struct json_object *);