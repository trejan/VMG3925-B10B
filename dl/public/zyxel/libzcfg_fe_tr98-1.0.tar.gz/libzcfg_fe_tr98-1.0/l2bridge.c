#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "l2bridge_parameter.h"

extern tr98Object_t tr98Obj[];


/*  TR98 Object Name : InternetGatewayDevice.Layer2Bridging

    Related object in TR181:
    Device.Bridging
*/
zcfgRet_t l2BridingObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  bridingOid = 0;
	objIndex_t bridingIid;
	struct json_object *bridingJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;	
	char zyxelPrefixParam[64] = {0};

	printf("Enter %s\n", __FUNCTION__);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else                /* mappingPathName will be Bridging */
		printf("TR181 object %s\n", mappingPathName);


	IID_INIT(bridingIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	bridingOid = zcfgFeObjNameToObjId(tr181Obj, &bridingIid);
	if((ret = zcfgFeObjJsonGet(bridingOid, &bridingIid, &bridingJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 Bridging object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		paramValue = json_object_object_get(bridingJobj, paramList->name);
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		strcpy(zyxelPrefixParam, "X_ZYXEL_");
		strcat(zyxelPrefixParam, paramList->name);
		paramValue = json_object_object_get(bridingJobj, zyxelPrefixParam);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(bridingJobj);
	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.Layer2Bridging.Bridge.i

    Related object in TR181:
    Device.Bridging.Bridge.i
    Device.Bridging.Bridge.i.Port.i
*/
zcfgRet_t l2BrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	char tmpChar[4] ={0};
	char paramName[64] = {0};
	uint32_t  brOid = 0;
	objIndex_t brIid;
	struct json_object *brJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t numOfInstance = 0;
	char *ptr = NULL;
	char zyxelPrefixParam[64] = {0};

	printf("Enter %s\n", __FUNCTION__);
	
      if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else        /* mappingPathName will be Bridging */
		printf("TR181 object %s\n", mappingPathName);
	
	ptr = strrchr(mappingPathName, '.');
	strcpy(tmpChar, ptr+1);
	numOfInstance = atoi(tmpChar);

	IID_INIT(brIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	brOid = zcfgFeObjNameToObjId(tr181Obj, &brIid);
	if((ret = zcfgFeObjJsonGet(brOid, &brIid, &brJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 Bridging object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		paramValue = json_object_object_get(brJobj, paramList->name);
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		/*we default use this object index number as parameter 'BridgeKey' under tr98 */
		if(strstr(paramList->name, "BridgeKey") != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(numOfInstance));
			paramList++;
			continue;
		}

		if(strstr(paramList->name, "Standard") != NULL){
			sprintf(paramName, "%s", "Standard");
			paramValue = json_object_object_get(brJobj, paramName);
			if(paramValue != NULL){
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}
		
		if(strstr(paramList->name, "Enable") != NULL){
			sprintf(paramName, "%s", "Enable");
			paramValue = json_object_object_get(brJobj, paramName);
			if(paramValue != NULL){
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}

		if(strstr(paramList->name, "Status") != NULL){
			sprintf(paramName, "%s", "Status");
			paramValue = json_object_object_get(brJobj, paramName);
			if(paramValue != NULL){
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}	
		
		strcpy(zyxelPrefixParam, "X_ZYXEL_");
		strcat(zyxelPrefixParam, paramList->name);
		paramValue = json_object_object_get(brJobj, zyxelPrefixParam);
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		
		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(brJobj);
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  brOid = 0;
	objIndex_t brIid;
	struct json_object *brJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	char zyxelPrefixParam[64] = {0};

	printf("Enter %s\n", __FUNCTION__);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else      /* mappingPathName will be Bridging */
		printf("TR181 object %s\n", mappingPathName);

	IID_INIT(brIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	brOid = zcfgFeObjNameToObjId(tr181Obj, &brIid);
	if((ret = zcfgFeObjJsonGet(brOid, &brIid, &brJobj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = brJobj;
		brJobj = NULL;
		brJobj = zcfgFeJsonMultiObjAppend(RDM_OID_BRIDGING_BR, &brIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		/*Write new parameter value from tr98 object to tr181 objects*/
		printf("Parameter Name %s\n", paramList->name);
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			/*Write value from Config to Device.Bridging.Bridge.i*/
			tr181ParamValue = json_object_object_get(brJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(brJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		/*special case*/
		if(strstr(paramList->name, "Standard") != NULL){
			json_object_object_add(brJobj, "Standard", JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
			
		if(strstr(paramList->name, "Enable") != NULL){
			json_object_object_add(brJobj, "Enable", JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
			
		strcpy(zyxelPrefixParam, "X_ZYXEL_");
		strcat(zyxelPrefixParam, paramList->name);
		tr181ParamValue = json_object_object_get(brJobj, zyxelPrefixParam);
		if(tr181ParamValue != NULL) {
			json_object_object_add(brJobj, zyxelPrefixParam, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}		

		paramList++;	
	} /*Edn while*/

	/*Set Bridging.Bridge.i */
	if(multiJobj)
		json_object_put(tmpObj);
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_BRIDGING_BR, &brIid, brJobj, NULL)) != ZCFG_SUCCESS ){
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.Bridging.Bridge.i Fail\n", __FUNCTION__);
			json_object_put(brJobj);
			return ret;
		}
		else
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.Bridging.Bridge.i Success\n", __FUNCTION__);

		json_object_put(brJobj);	
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t iid;
	rdm_BridgingBrPort_t *bridgePortObj = NULL;
			
	printf("Enter %s\n", __FUNCTION__);
	
	/*add the object "Device.Bridging.Bridge.i" */
	IID_INIT(iid);	
	if((ret = zcfgFeObjStructAdd(RDM_OID_BRIDGING_BR, &iid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	/*add the management object "Device.Bridging.Bridge.i.Port.1"*/
	if((ret = zcfgFeObjStructAdd(RDM_OID_BRIDGING_BR_PORT, &iid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
//printf("306 Level %d objIid.idx[%d,%d,%d,%d,%d,%d]\n",  iid.level, iid.idx[0], iid.idx[1], iid.idx[2], iid.idx[3], iid.idx[4], iid.idx[5]);
		
	if((ret = zcfgFeObjStructGet(RDM_OID_BRIDGING_BR_PORT, &iid, (void **)&bridgePortObj)) == ZCFG_SUCCESS){
		bridgePortObj->Enable = true;
		bridgePortObj->ManagementPort = true;
		if((ret = zcfgFeObjStructSet(RDM_OID_BRIDGING_BR_PORT, &iid, (void *)bridgePortObj, NULL)) != ZCFG_SUCCESS)
			printf("Set Bridge Port Object Fail\n");
		
		zcfgFeObjStructFree(bridgePortObj);
	}
	else
		return ret;

	*idx = iid.idx[0];
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char mappingPathName[32] = {0};
	uint32_t  oid = 0;
	objIndex_t objIid;

	printf("Enter %s\n", __FUNCTION__);

        if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS)
		return ret;
		
	IID_INIT(objIid);
	printf("mappingPathName %s\n", mappingPathName);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	oid = zcfgFeObjNameToObjId(tr181Obj, &objIid);

	ret = zcfgFeObjJsonDel(oid, &objIid, NULL);
	if(ret == ZCFG_SUCCESS)
		printf("Delete Object Success\n");
	else{
		printf("Delete Object Fail\n");
		return ret;
	}

	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.Layer2Bridging.Filter.i

    Related object in TR181:
    Device.Bridging.Filter.i
*/
zcfgRet_t l2BrFilterObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tmpChar[4] = {0};
	char tr181Obj[128] = {0};
	char paramName[64] = {0};
	char filterBrRef[32] = {0};
	char filterIntf[32] = {0};
	char numOfFilterIntf[4] = {0};
	uint32_t  brFilterOid = 0, brPortOid = 0;
	char *ptr = NULL;
	uint8_t numOfInstance = 0;
	objIndex_t brFilterIid, brPortIid;
	struct json_object *brFilterJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char zyxelPrefixParam[64] = {0};
	rdm_BridgingBrPort_t *brPortObj = NULL;

	printf("Enter %s\n", __FUNCTION__);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else   /* mappingPathName will be Bridging.Filter.i */
		printf("TR181 object %s\n", mappingPathName);

	ptr = strrchr(mappingPathName, '.');
	strcpy(tmpChar, ptr+1);
	numOfInstance = atoi(tmpChar);	

	IID_INIT(brFilterIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	brFilterOid = zcfgFeObjNameToObjId(tr181Obj, &brFilterIid);
	if((ret = zcfgFeObjJsonGet(brFilterOid, &brFilterIid, &brFilterJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 Bridging object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		paramValue = json_object_object_get(brFilterJobj, paramList->name);
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		/*we default use this object index number as parameter 'FilterKey' under tr98 */
		if((strstr(paramList->name, "FilterKey") != NULL) ||(strstr(paramList->name, "FilterInterface") != NULL)){
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(numOfInstance));
			paramList++;
			continue;
		}
		
		/*we default use index number of object "Device.Bridging.Bridge.i" as the parameter 'FilterBridgeReference' under tr98 */
		if(strstr(paramList->name, "FilterBridgeReference") != NULL){
			sprintf(paramName, "%s", "Bridge");
			paramValue = json_object_object_get(brFilterJobj, paramName);
			if(paramValue != NULL) {
				sprintf(filterBrRef, "%s", json_object_get_string(paramValue));
				ptr = NULL;
				ptr = strrchr(filterBrRef, '.');
				strcpy(tmpChar, ptr+1);
				numOfInstance = atoi(tmpChar);	
				json_object_object_add(*tr98Jobj, paramList->name,  json_object_new_int(numOfInstance));
				paramList++;
				continue;	
			}
		}

		/*we default use parameter 'X_ZYXEL_AvailableInterfaceKey' under object "Bridging.Bridge.i.Port.i" as the parameter 'FilterInterface' under tr98. 
		   actually in tr98 , the parameter 'FilterInterface' is associated with the corresponding 'AvailableInterfaceKey' under tr98 object 'InternetGatewayDevice.Layer2Bridging.AvailableInterface.i',
		   but in tr181, it doesn't have the AvailableInterface object, so we add the parameters which belong 'AvailableInterface' under object 'Bridging.Bridge.i.Port.i'. */
		if(strstr(paramList->name, "FilterInterface") != NULL){
			sprintf(paramName, "%s", "Interface");
			paramValue = json_object_object_get(brFilterJobj, paramName);
			if(paramValue != NULL){
				IID_INIT(brPortIid);
				sprintf(filterIntf, "Device.%s", json_object_get_string(paramValue));
				brPortOid = zcfgFeObjNameToObjId(filterIntf, &brPortIid);
				if((ret = zcfgFeObjStructGet(RDM_OID_BRIDGING_BR_PORT, &brPortIid, (void **)&brPortObj)) == ZCFG_SUCCESS) {
					sprintf(numOfFilterIntf,"%d",brPortObj->X_ZYXEL_AvailableInterfaceKey);
					zcfgFeObjStructFree(brPortObj);
				}
				else 
					return ret;
				
				json_object_object_add(*tr98Jobj, paramList->name,  json_object_new_string(numOfFilterIntf));
				paramList++;
				continue;
			}
		}

		if(strstr(paramList->name, "Enable") != NULL){
			sprintf(paramName, "%s", "Enable");
			paramValue = json_object_object_get(brFilterJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}

		if(strstr(paramList->name, "Status") != NULL){
			sprintf(paramName, "%s", "Status");
			paramValue = json_object_object_get(brFilterJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}

		strcpy(zyxelPrefixParam, "X_ZYXEL_");
		strcat(zyxelPrefixParam, paramList->name);
		paramValue = json_object_object_get(brFilterJobj, zyxelPrefixParam);
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(brFilterJobj);
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrFilterObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char brPath[32] = {0};
	char brPortPath[32] = {0};
	char tr181Obj[128] = {0};
	uint32_t  brFilterOid = 0;
	objIndex_t brFilterIid, brPortIid;
	uint8_t filterIntf =0;
	struct json_object *brFilterJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	char zyxelPrefixParam[64] = {0};
	rdm_BridgingBrPort_t *brPortObj = NULL;

	printf("Enter %s\n", __FUNCTION__);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else       /* mappingPathName will be Bridging.Filter.i */
		printf("TR181 object %s\n", mappingPathName);

	IID_INIT(brFilterIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	brFilterOid = zcfgFeObjNameToObjId(tr181Obj, &brFilterIid);
	if((ret = zcfgFeObjJsonGet(brFilterOid, &brFilterIid, &brFilterJobj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = brFilterJobj;
		brFilterJobj = NULL;
		brFilterJobj = zcfgFeJsonMultiObjAppend(RDM_OID_BRIDGING_FILTER, &brFilterIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			/*Write value from Config to Device.Bridging.Filter.i*/
			tr181ParamValue = json_object_object_get(brFilterJobj, paramList->name);
			if(tr181ParamValue != NULL){
				json_object_object_add(brFilterJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		/*special case*/		
		if(strstr(paramList->name, "Enable") != NULL){
			json_object_object_add(brFilterJobj, "Enable", JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		if(strstr(paramList->name, "FilterBridgeReference") != NULL){
			sprintf(brPath, "Bridging.Bridge.%s", json_object_get_string(paramValue));	
			json_object_object_add(brFilterJobj, "Bridge", json_object_new_string(brPath));
			paramList++;
			continue;
		}

		if(strstr(paramList->name, "FilterInterface") != NULL){
			IID_INIT(brPortIid);
			filterIntf = json_object_get_int(paramValue);
			while(zcfgFeObjStructGetNext(RDM_OID_BRIDGING_BR_PORT, &brPortIid, (void **)&brPortObj) == ZCFG_SUCCESS){
				if (brPortObj->X_ZYXEL_AvailableInterfaceKey == filterIntf){
					sprintf(brPortPath, "Bridging.Bridge.%d.Port.%d", brPortIid.idx[0], brPortIid.idx[1]);
					zcfgFeObjStructFree(brPortObj);
					break;
				}
				else
					zcfgFeObjStructFree(brPortObj);
			}

			
			json_object_object_add(brFilterJobj, "Interface", json_object_new_string(brPortPath));
			paramList++;
			continue;
		}		
			
		strcpy(zyxelPrefixParam, "X_ZYXEL_");
		strcat(zyxelPrefixParam, paramList->name);
		tr181ParamValue = json_object_object_get(brFilterJobj, zyxelPrefixParam);
		if(tr181ParamValue != NULL) {
			json_object_object_add(brFilterJobj, zyxelPrefixParam, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}		

		paramList++;	
	} /*Edn while*/

	/*Set Device.Bridging.Filter.i */
	if(multiJobj)
		json_object_put(tmpObj);
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_BRIDGING_FILTER, &brFilterIid, brFilterJobj, NULL)) != ZCFG_SUCCESS ){
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.Bridging.Filter.i Fail\n", __FUNCTION__);
			json_object_put(brFilterJobj);
			return ret;
		}
		else
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.Bridging.Filter.i Success\n", __FUNCTION__);

		json_object_put(brFilterJobj);
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrFilterObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objIid;
		
	printf("Enter %s\n", __FUNCTION__);
	
	/*add the object "Device.Bridging.Filter.i" */
	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_BRIDGING_FILTER, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	*idx = objIid.idx[0];
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrFilterObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char mappingPathName[32] = {0};
	uint32_t  oid = 0;
	objIndex_t objIid;

	printf("Enter %s\n", __FUNCTION__);

        if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS)
		return ret;
		
	IID_INIT(objIid);
	printf("mappingPathName %s\n", mappingPathName);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	oid = zcfgFeObjNameToObjId(tr181Obj, &objIid);

	ret = zcfgFeObjJsonDel(oid, &objIid, NULL);
	if(ret == ZCFG_SUCCESS)
		printf("Delete Object Success\n");
	else
		printf("Delete Object Fail\n");
		return ret;

	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.Layer2Bridging.AvailableInterface.i

    Related object in TR181:
    Device.Bridging.Bridge.i.Port.i
*/
zcfgRet_t l2BrAvailableIntfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[32] = {0};
	uint32_t oid = 0;
	objIndex_t objIid;
	struct json_object *brPortJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char zyxelPrefixParam[64] = {0};
	char paramName[64] = {0};
	char tr181Obj[32] = {0};
	char mapping98ObjName[128] = {0};

	printf("Enter %s\n", __FUNCTION__);

       if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else   /* mappingPathName will be Bridging */
		printf("TR181 object %s\n", mappingPathName);
		
	IID_INIT(objIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	oid = zcfgFeObjNameToObjId(tr181Obj, &objIid);
	
	if((ret = zcfgFeObjJsonGet(oid, &objIid, &brPortJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 Bridging object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){		
		/*special case*/
		if(strstr(paramList->name, "InterfaceReference") != NULL){
			sprintf(paramName, "%s", "LowerLayers");
			sprintf(tr181Obj, "%s", json_object_get_string(json_object_object_get(brPortJobj, paramName)));		
			zcfgFe181To98MappingNameGet(tr181Obj, mapping98ObjName);				
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(mapping98ObjName));
			paramList++;
			continue;
		}
		
		strcpy(zyxelPrefixParam, "X_ZYXEL_");
		strcat(zyxelPrefixParam, paramList->name);
		paramValue = json_object_object_get(brPortJobj, zyxelPrefixParam);	
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(brPortJobj);
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrVlanObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	char tmpChar[4] ={0};
	char paramName[64] = {0};
	uint32_t  vlanOid = 0;
	objIndex_t vlanIid;
	struct json_object *vlanJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t numOfInstance = 0;
	char *ptr = NULL;
	char zyxelPrefixParam[64] = {0};

	printf("Enter %s\n", __FUNCTION__);
	
    if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
    }
	else
		printf("TR181 object %s\n", mappingPathName);
	
	ptr = strstr(mappingPathName, "VLANTermination.");
	strcpy(tmpChar, ptr+16);
	numOfInstance = atoi(tmpChar);

	IID_INIT(vlanIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	vlanOid = zcfgFeObjNameToObjId(tr181Obj, &vlanIid);
	if((ret = zcfgFeObjJsonGet(vlanOid, &vlanIid, &vlanJobj)) != ZCFG_SUCCESS){
		return ret;
	}
	
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		paramValue = json_object_object_get(vlanJobj, paramList->name);
		if(paramValue != NULL){
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		
		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(vlanJobj);
	return ZCFG_SUCCESS;
}

zcfgRet_t l2BrVlanObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  vlanOid = 0;
	objIndex_t vlanIid;
	struct json_object *vlanJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	char zyxelPrefixParam[64] = {0};

	printf("Enter %s\n", __FUNCTION__);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else
		printf("TR181 object %s\n", mappingPathName);

	IID_INIT(vlanIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	vlanOid = zcfgFeObjNameToObjId(tr181Obj, &vlanIid);
	if((ret = zcfgFeObjJsonGet(vlanOid, &vlanIid, &vlanJobj)) != ZCFG_SUCCESS){
		return ret;
	}
	if(multiJobj){
		tmpObj = vlanJobj;
		vlanJobj = NULL;
		vlanJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ETH_VLAN_TERM, &vlanIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL){
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			tr181ParamValue = json_object_object_get(vlanJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(vlanJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		/*special case*/
		paramList++;	
	} /*Edn while*/

	if(multiJobj)
		json_object_put(tmpObj);
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_ETH_VLAN_TERM, &vlanIid, vlanJobj, NULL)) != ZCFG_SUCCESS ){
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.Ethernet.VLANTermination.i Fail\n", __FUNCTION__);
			json_object_put(vlanJobj);
			return ret;
		}
		else
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.Ethernet.VLANTermination.i Success\n", __FUNCTION__);

		json_object_put(vlanJobj);	
	}
	return ZCFG_SUCCESS;
}


