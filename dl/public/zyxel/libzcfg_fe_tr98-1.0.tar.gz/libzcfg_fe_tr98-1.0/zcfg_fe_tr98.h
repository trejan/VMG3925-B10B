#ifndef _ZCFG_FE_TR98_H
#define _ZCFG_FE_TR98_H

#include <json/json.h>

#include <json/json_object.h>
#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcmd_schema.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_schema.h"

#define TR98_MAPPING_DEBUG 0

typedef struct tr98Parameter_s {
	char 			*name;			/*parameter name*/
	int 			attr;			/*parameter attribute*/
	int			len;			/*parameter length*/
	json_type		type;			/*parameter type*/
}tr98Parameter_t;

typedef struct tr98Object_s {
	char			*name;			   /*object full path name*/
	int 			attr;			   /*object attribute*/
	struct tr98Parameter_s 	*parameter;		   /*next level parameters*/
	int (*getObj)(char *, int, struct json_object **);
	int (*setObj)(char *, int, struct json_object *, struct json_object *);
	int (*addObj)(char *, int *);
	int (*delObj)(char *);
	int (*notify)(char *, char *, struct json_object *, int, struct json_object **);
	int (*getAttr)(char *, int , char *);
	int (*setAttr)(char *, int , char *, int , struct json_object *);
}tr98Object_t;

#define TR98_MAX_OBJ_NAME_LENGTH 128

zcfgRet_t zcfgFeTr98ObjGet(char *, struct json_object **);
zcfgRet_t zcfgFeTr98ObjParamSet(char *, uint32_t , struct json_object *, char *);
zcfgRet_t zcfgFeTr98ObjSet(char *, struct json_object *);
zcfgRet_t zcfgFeTr98MultiObjSet(char *, struct json_object *, struct json_object *);
zcfgRet_t zcfgFeTr98ObjAdd(char *, int *);
zcfgRet_t zcfgFeTr98ObjDel(char *);
zcfgRet_t zcfgFeTr98DefaultValueSet(struct json_object *, char *, int);
int zcfgFeTr98ObjAttrGet(char *);
zcfgRet_t zcfgFeTr98Notify(struct json_object *, struct json_object **);
zcfgRet_t zcfgFeTr98ParamList(char *);

int zcfgFeTr98ParamAttrGetByName(char *, char *);
int zcfgFeTr98ParamAttrMultiSetByName(char *, char *, int , struct json_object *);
int zcfgFeTr98ParamTypeGetByName(char *, char *);
zcfgRet_t zcfgFeTr98ParamChk(char *, char *, char *);
zcfgSubObjNameList_t* zcfgFeTr98SubObjNameListGet(char *);

zcfgRet_t zcfgFeTr181IfaceStackLowerLayerGet(char *higherLayer, char *result);
zcfgRet_t zcfgFeTr181IfaceStackHigherLayerGet(char *lowerLayer, char *result);

#define JSON_OBJ_COPY(json_object) json_tokener_parse(json_object_to_json_string(json_object))

#endif
