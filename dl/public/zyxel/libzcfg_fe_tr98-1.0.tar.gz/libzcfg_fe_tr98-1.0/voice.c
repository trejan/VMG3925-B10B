#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"

extern tr98Object_t tr98Obj[];


zcfgRet_t getVoiceConfig(zcfg_offset_t oid, objIndex_t *objIid, int handler, struct json_object **tr98Jobj){
	
	zcfgRet_t ret = ZCFG_SUCCESS;
	struct json_object *getObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFeObjJsonGet(oid, objIid, &getObj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get obj(oid %d) codec object ret=%d\n", __FUNCTION__, oid, ret);
		return ret;
	}

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name){
		/* get parameter value from tr181 */
		paramValue = json_object_object_get(getObj, paramList->name);

		/* write it to tr098 json object */
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
		}

		paramList++;
		continue;
	}

	zcfgFeJsonObjFree(getObj);
	return ZCFG_SUCCESS;

}

zcfgRet_t setVoiceConfig(zcfg_offset_t oid, objIndex_t *objIid, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	struct json_object *obj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;

	if((ret = zcfgFeObjJsonGet(oid, objIid, &obj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get object(oid %d) with ret=%d\n", __FUNCTION__, oid, ret);
		return ret;
	}
	
	/* if multiple set is required, just appended JSON to multiJobj */
	if(multiJobj){
		tmpObj = obj;
		obj = NULL;
		obj = zcfgFeJsonMultiObjAppend(oid, objIid, multiJobj, tmpObj);
	}

	/* set(update) value to target object */
	if(obj){
		paramList = tr98Obj[handler].parameter;
		while(paramList->name){
			/* get parameter value from tr098 */
			paramValue = json_object_object_get(tr98Jobj, paramList->name);

			/* write it to tr181 json object */
			if(paramValue != NULL) {
				json_object_object_add(obj, paramList->name, JSON_OBJ_COPY(paramValue));
			}

			paramList++;
			continue;
		}

		/* is not multiple set, jsut set object immediately after update parameter value */
		if(!multiJobj){
			if((ret = zcfgFeObjJsonSet(oid, objIid, obj, NULL)) != ZCFG_SUCCESS ) {
				zcfgLog(ZCFG_LOG_ERR, "%s : Set object(oid %d) Fail with ret=%d\n", __FUNCTION__, oid, ret);
			}
			zcfgFeJsonObjFree(obj);
			return ret;
		}
		zcfgFeJsonObjFree(tmpObj);
	
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t voiceNotify(char *tr98ObjName, char *tr181ParamName, struct json_object *tr181ParamVal, int handler, struct json_object **tr98NotifyInfo)
{
	bool found = false;
	char tr98Notify[256] = "";
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	if(*tr98NotifyInfo == NULL) {
		*tr98NotifyInfo = json_object_new_object();	
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		if(strcmp(tr181ParamName, paramList->name) == 0) {
			found = true;
			sprintf(tr98Notify, "%s.%s", tr98ObjName, paramList->name);
			break;
		}

		paramList++;
	}

	if(found) {
		json_object_object_add(*tr98NotifyInfo, tr98Notify, JSON_OBJ_COPY(tr181ParamVal));
	}

	return ZCFG_SUCCESS;
}

int getVoiceAttrGet(zcfg_offset_t oid, int handler, char *paramName){
	int attrValue = ZCFG_NO_SUCH_PARAMETER;
	tr98Parameter_t *paramList = NULL;

	/*fill up tr98 devInfo object*/
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*find the matched parameter*/
		if(strcmp(paramList->name, paramName)){
			paramList++;
			continue;
		}

		attrValue = zcfgFeParamAttrGetByName(oid, paramList->name);
		if(attrValue < 0 ) {
			attrValue = 0;
			break;
		}

		break;
	}

	return attrValue;
}

zcfgRet_t getVoiceAttrSet(zcfg_offset_t oid, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	int attrValue = 0;
	tr98Parameter_t *paramList = NULL;

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*find the matched parameter*/
		if(strcmp(paramList->name, paramName)){
			paramList++;
			continue;
		}
		
		attrValue = zcfgFeParamAttrGetByName(oid, paramList->name);
		if(attrValue < 0) {
			ret = ZCFG_INVALID_ARGUMENTS;
			break;
		}

		/*Write new parameter attribute from tr98 object to tr181 objects*/
		attrValue = zcfgFeNotifyAttrValSet(attrValue, newNotify);
		if( (ret = zcfgFeMultiParamAttrAppend(oid, multiAttrJobj, paramList->name, attrValue)) != ZCFG_SUCCESS){
			
			zcfgLog(ZCFG_LOG_ERR, "%s(): set %d %s attribute fail\n", __FUNCTION__, oid, paramList->name);
		}

		break;

	} /*Edn while*/
	
	return ret;
}

zcfgRet_t voiceSrvGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t srvIid;
	

	IID_INIT(srvIid);
	srvIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu", &srvIid.idx[srvIid.level - 1]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_SRV, &srvIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_SRV with ret=%d", __FUNCTION__, ret);
		return ret;
	}
	
	return ZCFG_SUCCESS;
}


int voiceSrvAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_SRV, handler, paramName);
}

zcfgRet_t voiceSrvAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_SRV, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceCapbGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t capbIid;
	

	IID_INIT(capbIid);
	capbIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.Capabilities", &capbIid.idx[capbIid.level - 1]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_CAPB, &capbIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_CAPB with ret=%d", __FUNCTION__, ret);
		return ret;
	}
	
	return ZCFG_SUCCESS;
}

int voiceCapbAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_CAPB, handler, paramName);
}

zcfgRet_t voiceCapbAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_CAPB, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceCommonGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t commIid;
	

	IID_INIT(commIid);
	commIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.X_ZyXEL_COM_Common", &commIid.idx[commIid.level - 1]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_COMMON, &commIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_COMMON with ret=%d", __FUNCTION__, ret);
		return ret;
	}
	
	return ZCFG_SUCCESS;
}

zcfgRet_t voiceCommonSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t commIid;

	IID_INIT(commIid);
	commIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.X_ZyXEL_COM_Common", &commIid.idx[commIid.level - 1]);

	if((ret = setVoiceConfig(RDM_OID_VOICE_COMMON, &commIid, handler, tr98Jobj, multiJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to set config to tr181 for object RDM_OID_VOICE_COMMON with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

#if 0
int voiceCommonAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_COMMON, handler, paramName);
}

zcfgRet_t voiceCommonAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_COMMON, handler, paramName, newNotify, multiAttrJobj);
}
#endif

zcfgRet_t voiceCapbSipGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t capbSipIid;

	IID_INIT(capbSipIid);
	capbSipIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.Capabilities.SIP", &capbSipIid.idx[capbSipIid.level - 1]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_CAPB_SIP, &capbSipIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_CAPB_SIP with ret=%d", __FUNCTION__, ret);
		return ret;
	}
	return ZCFG_SUCCESS;
}

int voiceCapbSipAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_CAPB_SIP, handler, paramName);
}

zcfgRet_t voiceCapbSipAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_CAPB_SIP, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceCapbCodecGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t capbCodecIid;

	IID_INIT(capbCodecIid);
	capbCodecIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.Capabilities.Codec.%hhu", 
		&capbCodecIid.idx[0], &capbCodecIid.idx[1]);
	
	if((ret = getVoiceConfig(RDM_OID_VOICE_CAPB_CODEC, &capbCodecIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_CAPB_CODEC with ret=%d", __FUNCTION__, ret);
		return ret;
	}
	return ZCFG_SUCCESS;
}

int voiceCapbCodecAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_CAPB_CODEC, handler, paramName);
}

zcfgRet_t voiceCapbCodecAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_CAPB_CODEC, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceProfGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t profIid;

	IID_INIT(profIid);
	profIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu", 
		&profIid.idx[0], &profIid.idx[1]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_PROF, &profIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_PROF with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceProfSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t profIid;

	IID_INIT(profIid);
	profIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu", 
		&profIid.idx[0], &profIid.idx[1]);

	if((ret = setVoiceConfig(RDM_OID_VOICE_PROF, &profIid, handler, tr98Jobj, multiJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to set config to tr181 for object RDM_OID_VOICE_PROF with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceProfAdd(char *tr98FullPathName, int *idx){
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t profIid;

	IID_INIT(profIid);
	profIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.", &profIid.idx[0]);
	
	if((ret = zcfgFeObjJsonAdd(RDM_OID_VOICE_PROF, &profIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to add voice profile instance with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	*idx = profIid.idx[profIid.level - 1];
	
	return ZCFG_SUCCESS;
}

zcfgRet_t voiceProfDel(char *tr98FullPathName){
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t profIid;

	IID_INIT(profIid);
	profIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu", 
		&profIid.idx[0], &profIid.idx[1]);

	if((ret = zcfgFeObjJsonDel(RDM_OID_VOICE_PROF, &profIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to delete profile instance with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}
	
	return ZCFG_SUCCESS;
}

int voiceProfAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_PROF, handler, paramName);
}

zcfgRet_t voiceProfAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_PROF, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceProfSipGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t profSipIid;

	IID_INIT(profSipIid);
	profSipIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.SIP", 
		&profSipIid.idx[0], &profSipIid.idx[1]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_PROF_SIP, &profSipIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_PROF_SIP with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceProfSipSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t profSipIid;

	IID_INIT(profSipIid);
	profSipIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.SIP", 
		&profSipIid.idx[0], &profSipIid.idx[1]);

	if((ret = setVoiceConfig(RDM_OID_VOICE_PROF_SIP, &profSipIid, handler, tr98Jobj, multiJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to set config to tr181 for object RDM_OID_VOICE_PROF_SIP with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

int voiceProfSipAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_PROF_SIP, handler, paramName);
}

zcfgRet_t voiceProfSipAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_PROF_SIP, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceLineGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineIid;

	IID_INIT(lineIid);
	lineIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu", 
		&lineIid.idx[0], &lineIid.idx[1], &lineIid.idx[2]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_LINE, &lineIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_LINE with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceLineSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineIid;

	IID_INIT(lineIid);
	lineIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu", 
		&lineIid.idx[0], &lineIid.idx[1], &lineIid.idx[2]);

	if((ret = setVoiceConfig(RDM_OID_VOICE_LINE, &lineIid, handler, tr98Jobj, multiJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to set config to tr181 for object RDM_OID_VOICE_LINE with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceLineAdd(char *tr98FullPathName, int *idx){
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineIid;

	IID_INIT(lineIid);
	lineIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.", 
		&lineIid.idx[0], &lineIid.idx[1]);
	
	if((ret = zcfgFeObjJsonAdd(RDM_OID_VOICE_LINE, &lineIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to add voice line instance with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	*idx = lineIid.idx[lineIid.level - 1];
	
	return ZCFG_SUCCESS;
}

zcfgRet_t voiceLineDel(char *tr98FullPathName){
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineIid;

	IID_INIT(lineIid);
	lineIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu", 
		&lineIid.idx[0], &lineIid.idx[1], &lineIid.idx[2]);

	if((ret = zcfgFeObjJsonDel(RDM_OID_VOICE_LINE, &lineIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to delete line instance with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}
	
	return ZCFG_SUCCESS;
}

int voiceLineAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_LINE, handler, paramName);
}

zcfgRet_t voiceLineAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_LINE, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceLineSipGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineSipIid;

	IID_INIT(lineSipIid);
	lineSipIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu.SIP", 
		&lineSipIid.idx[0], &lineSipIid.idx[1], &lineSipIid.idx[2]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_LINE_SIP, &lineSipIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_LINE_SIP with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceLineSipSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineSipIid;

	IID_INIT(lineSipIid);
	lineSipIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu.SIP", 
		&lineSipIid.idx[0], &lineSipIid.idx[1], &lineSipIid.idx[2]);

	if((ret = setVoiceConfig(RDM_OID_VOICE_LINE_SIP, &lineSipIid, handler, tr98Jobj, multiJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to set config to tr181 for object RDM_OID_VOICE_LINE_SIP with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

int voiceLineSipAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_LINE_SIP, handler, paramName);
}

zcfgRet_t voiceLineSipAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_LINE_SIP, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceLineProcGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineProcIid;

	IID_INIT(lineProcIid);
	lineProcIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu.VoiceProcessing", 
		&lineProcIid.idx[0], &lineProcIid.idx[1], &lineProcIid.idx[2]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_LINE_PROCESSING, &lineProcIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_LINE_PROCESSING with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t voiceLineProcSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineProcIid;

	IID_INIT(lineProcIid);
	lineProcIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu.VoiceProcessing", 
		&lineProcIid.idx[0], &lineProcIid.idx[1], &lineProcIid.idx[2]);

	if((ret = setVoiceConfig(RDM_OID_VOICE_LINE_PROCESSING, &lineProcIid, handler, tr98Jobj, multiJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to set config to tr181 for object RDM_OID_VOICE_LINE_PROCESSING with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

int voiceLineProcAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_LINE_PROCESSING, handler, paramName);
}

zcfgRet_t voiceLineProcAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_LINE_PROCESSING, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceLineCodecGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineCodecIid;

	IID_INIT(lineCodecIid);
	lineCodecIid.level = 3;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu.Codec", 
		&lineCodecIid.idx[0], &lineCodecIid.idx[1], &lineCodecIid.idx[2]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_LINE_CODEC, &lineCodecIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_LINE_CODEC with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

int voiceLineCodecAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_LINE_CODEC, handler, paramName);
}

zcfgRet_t voiceLineCodecAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_LINE_CODEC, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voiceLineCodecListGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t lineCodecListIid;

	IID_INIT(lineCodecListIid);
	lineCodecListIid.level = 4;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.VoiceProfile.%hhu.Line.%hhu.Codec.List.%hhu", 
		&lineCodecListIid.idx[0], &lineCodecListIid.idx[1], &lineCodecListIid.idx[2], &lineCodecListIid.idx[3]);

	if((ret = getVoiceConfig(RDM_OID_VOICE_LINE_CODEC_LIST, &lineCodecListIid, handler, tr98Jobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get config from tr181 for object RDM_OID_VOICE_LINE_CODEC_LIST with ret=%d", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

int voiceLineCodecListAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_LINE_CODEC_LIST, handler, paramName);
}

zcfgRet_t voiceLineCodecListAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_LINE_CODEC_LIST, handler, paramName, newNotify, multiAttrJobj);
}

zcfgRet_t voicePhyIntfGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t phyIntfIid;
	struct json_object *phyIntfObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char lineSelect[128];

	IID_INIT(phyIntfIid);
	phyIntfIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.PhyInterface.%hhu", 
		&phyIntfIid.idx[0], &phyIntfIid.idx[1]);
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_VOICE_PHY_INTF, &phyIntfIid, &phyIntfObj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get voice Phy Intf object ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name){
		/* get parameter value from tr181 */
		paramValue = json_object_object_get(phyIntfObj, paramList->name);

		/* write it to tr098 json object */
		if(paramValue != NULL) {

			/* special case */
			if(!strcmp(paramList->name, "X_ZyXEL_COM_LineSelect")){
				lineSelect[0] = '\0';
				sprintf(lineSelect, "InternetGatewayDevice.%s", json_object_get_string(paramValue) + strlen("Device."));
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(lineSelect));
				paramList++;
				continue;
			}
			
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
		}

		paramList++;
		continue;
	}

	zcfgFeJsonObjFree(phyIntfObj);

	return ZCFG_SUCCESS;
}

zcfgRet_t voicePhyIntfSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t phyIntfIid;
	struct json_object *phyIntfObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char lineSelect[128];

	IID_INIT(phyIntfIid);
	phyIntfIid.level = 2;
	sscanf(tr98FullPathName, "InternetGatewayDevice.Services.VoiceService.%hhu.PhyInterface.%hhu", 
		&phyIntfIid.idx[0], &phyIntfIid.idx[1]);
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_VOICE_PHY_INTF, &phyIntfIid, &phyIntfObj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get voice Phy Intf object ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	/* if multiple set is required, just appended JSON to multiJobj */
	if(multiJobj){
		tmpObj = phyIntfObj;
		phyIntfObj = NULL;
		phyIntfObj = zcfgFeJsonMultiObjAppend(RDM_OID_VOICE_PHY_INTF, &phyIntfIid, multiJobj, tmpObj);
	}

	/* set(update) value to target object */
	if(phyIntfObj){
		paramList = tr98Obj[handler].parameter;
		while(paramList->name){
			/* get parameter value from tr098 */
			paramValue = json_object_object_get(tr98Jobj, paramList->name);

			/* write it to tr181 json object */
			if(paramValue != NULL) {
				/* special case */
				if(!strcmp(paramList->name, "X_ZyXEL_COM_LineSelect")){
					lineSelect[0] = '\0';
					sprintf(lineSelect, "Device.%s", json_object_get_string(paramValue) + strlen("InternetGatewayDevice."));
					json_object_object_add(phyIntfObj, paramList->name, json_object_new_string(lineSelect));
				}
				else{
					json_object_object_add(phyIntfObj, paramList->name, JSON_OBJ_COPY(paramValue));
				}
			}

			paramList++;
			continue;
		}

		/* is not multiple set, jsut set object immediately after update parameter value */
		if(!multiJobj){
			if((ret = zcfgFeObjJsonSet(RDM_OID_VOICE_PHY_INTF, &phyIntfIid, phyIntfObj, NULL)) != ZCFG_SUCCESS ) {
				zcfgLog(ZCFG_LOG_ERR, "%s : Set object RDM_OID_VOICE_PHY_INTF Fail with ret=%d\n", __FUNCTION__, ret);
			}
			zcfgFeJsonObjFree(phyIntfObj);
			return ret;
		}
		zcfgFeJsonObjFree(tmpObj);
	
	}

	return ZCFG_SUCCESS;
}


int voicePhyIntfAttrGet(char *tr98FullPathName, int handler, char *paramName)
{
	return getVoiceAttrGet(RDM_OID_VOICE_PHY_INTF, handler, paramName);
}

zcfgRet_t voicePhyIntfAttrSet(char *tr98FullPathName, int handler, char *paramName, int newNotify, struct json_object *multiAttrJobj)
{
	return getVoiceAttrSet(RDM_OID_VOICE_PHY_INTF, handler, paramName, newNotify, multiAttrJobj);
}


