/*Parameter*/
extern tr98Parameter_t para_Schedule[];

/*Handler Function*/
extern zcfgRet_t scheduleObjGet(char *, int, struct json_object **);
extern zcfgRet_t scheduleObjSet(char *, int , struct json_object *, struct json_object *);
extern zcfgRet_t scheduleObjAdd(char *, int *);
extern zcfgRet_t scheduleObjDel(char *);

