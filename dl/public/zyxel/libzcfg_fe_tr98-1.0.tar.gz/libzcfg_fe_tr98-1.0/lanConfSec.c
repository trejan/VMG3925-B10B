#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "lanConfSec_parameter.h"

extern tr98Object_t tr98Obj[];

/* InternetGatewayDevice.LANConfigSecurity. */
zcfgRet_t lanConfSecObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char lanConfSecObjName[128] = "Device.LANConfigSecurity";
	uint32_t  lanConfSecOid = 0;
	objIndex_t lanConfSecIid;
	struct json_object *lanConfSecObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("Enter %s\n", __FUNCTION__);
	IID_INIT(lanConfSecIid);
	lanConfSecOid = zcfgFeObjNameToObjId(lanConfSecObjName, &lanConfSecIid);

	if((ret = zcfgFeObjJsonGet(lanConfSecOid, &lanConfSecIid, &lanConfSecObj)) != ZCFG_SUCCESS)
		return ret;
		

	/*fill up tr98 lanConfSec object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(lanConfSecObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(lanConfSecObj);

	return ZCFG_SUCCESS;

}
/* InternetGatewayDevice.LANConfigSecurity. */


/* InternetGatewayDevice.LANConfigSecurity */
zcfgRet_t lanConfSecObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char lanConfSecObjName[128] = "Device.LANConfigSecurity";
	uint32_t  lanConfSecOid = 0;
	objIndex_t lanConfSecIid;
	struct json_object *lanConfSecObj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("Enter %s\n", __FUNCTION__);

	IID_INIT(lanConfSecIid);
	lanConfSecOid = zcfgFeObjNameToObjId(lanConfSecObjName, &lanConfSecIid);
	if((ret = zcfgFeObjJsonGet(lanConfSecOid, &lanConfSecIid, &lanConfSecObj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = lanConfSecObj;
		lanConfSecObj = NULL;
		lanConfSecObj = zcfgFeJsonMultiObjAppend(RDM_OID_LAN_CONF_SEC, &lanConfSecIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(lanConfSecObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(lanConfSecObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		paramList++;	
	} /*Edn while*/
	
	/*Set Device.LANConfigSecurity*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_LAN_CONF_SEC, &lanConfSecIid, lanConfSecObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(lanConfSecObj);
			return ret;
		}
		json_object_put(lanConfSecObj);
	}


	return ZCFG_SUCCESS;
}

