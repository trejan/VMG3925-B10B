#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "zyExt_parameter.h"

extern tr98Object_t tr98Obj[];

/*
 *   TR98 Object Name : InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.i
 *
 *   Related object in TR181:
 *   Device.X_ZYXEL_EXT.DNSRouteEntry.i
 */
zcfgRet_t zyExtDnsRtObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *dnsRouteJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	/*Get related tr181 objects*/
	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.%hhu", &objIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_DNS_RT_ENTRY, &objIid, &dnsRouteJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(dnsRouteJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;	
	}

	json_object_put(dnsRouteJobj);

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.i
 *
 *   Related object in TR181:
 *   Device.X_ZYXEL_EXT.DNSRouteEntry.i
 */
zcfgRet_t zyExtDnsRtObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *dnsRouteJobj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	/*Get related tr181 objects*/
	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.%hhu", &objIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_DNS_RT_ENTRY, &objIid, &dnsRouteJobj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = dnsRouteJobj;
		dnsRouteJobj = NULL;
		dnsRouteJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DNS_RT_ENTRY, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/	
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(dnsRouteJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(dnsRouteJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DNS_RT_ENTRY, &objIid, dnsRouteJobj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(dnsRouteJobj);
			return ret;
		}
		json_object_put(dnsRouteJobj);
	}

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.i
 *
 *   Related object in TR181:
 *   Device.X_ZYXEL_EXT.DNSRouteEntry.i
 */
zcfgRet_t zyExtDnsRtObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objIid;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	ret = zcfgFeObjStructAdd(RDM_OID_DNS_RT_ENTRY, &objIid, NULL);
	*idx = objIid.idx[0];

	return ret;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.i
 *
 *   Related object in TR181:
 *   Device.X_ZYXEL_EXT.DNSRouteEntry.i
 */
zcfgRet_t zyExtDnsRtObjDel(char *tr98FullPathName)
{
	objIndex_t objIid;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.%hhu", &objIid.idx[0]);

	return zcfgFeObjStructDel(RDM_OID_DNS_RT_ENTRY, &objIid, NULL);;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.X_ZYXEL_EXT.DynamicDNS
 *
 *   Related object in TR181:
 *   Device.X_ZYXEL_EXT.DynamicDNS
 */
 zcfgRet_t zyExtDDnsObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *ddnsJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	/*Get related tr181 objects*/
	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_D_DNS, &objIid, &ddnsJobj)) != ZCFG_SUCCESS)
		return ret;	

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(ddnsJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;	
	}

	json_object_put(ddnsJobj);

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.X_ZYXEL_EXT.DynamicDNS
 *
 *   Related object in TR181:
 *   Device.X_ZYXEL_EXT.DynamicDNS
 */
zcfgRet_t zyExtDDnsObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *ddnsJobj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	/*Get related tr181 objects*/
	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_D_DNS, &objIid, &ddnsJobj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = ddnsJobj;
		ddnsJobj = NULL;
		ddnsJobj = zcfgFeJsonMultiObjAppend(RDM_OID_D_DNS, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/	
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(ddnsJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ddnsJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_D_DNS, &objIid, ddnsJobj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(ddnsJobj);
			return ret;
		}
		json_object_put(ddnsJobj);
	}

	return ZCFG_SUCCESS;
}