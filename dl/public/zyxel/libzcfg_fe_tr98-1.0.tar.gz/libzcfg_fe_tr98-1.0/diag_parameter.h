tr98Parameter_t para_IpPingDiag[] = {
	{ "DiagnosticsState", PARAMETER_ATTR_WRITE, 29, json_type_string},
	{ "Interface", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "Host", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "NumberOfRepetitions", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "Timeout", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "DataBlockSize", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "DSCP", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "SuccessCount", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "FailureCount", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "AverageResponseTime", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "MinimumResponseTime", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "MaximumResponseTime", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_TraceRtDiag[] = {
	{ "DiagnosticsState", PARAMETER_ATTR_WRITE, 29, json_type_string},
	{ "Interface", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "Host", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "NumberOfTries", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "Timeout", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "DataBlockSize", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "DSCP", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "MaxHopCount", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "ResponseTime", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "RouteHopsNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_RtHop[] = {
	{ "HopHost", PARAMETER_ATTR_READONLY, 257, json_type_string},
	{ "HopHostAddress", PARAMETER_ATTR_READONLY, 33, json_type_string},
	{ "HopErrorCode", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "HopRTTimes", PARAMETER_ATTR_READONLY, 17, json_type_string},
	{ NULL, 0, 0}
};

tr98Parameter_t para_PerpDiag[] = {
	{ "DownloadTransports", PARAMETER_ATTR_READONLY, 17, json_type_string},
	{ "UploadTransports", PARAMETER_ATTR_READONLY, 17, json_type_string},
	{ NULL, 0, 0}
};

tr98Parameter_t para_DlDiag[] = {
	{ "DiagnosticsState", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "Interface", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "DownloadURL", PARAMETER_ATTR_WRITE, 257, json_type_string},
	//{ "DownloadTransports", PARAMETER_ATTR_READONLY, 17, json_type_string},
	{ "DSCP", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "EthernetPriority", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "ROMTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "BOMTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "EOMTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "TestBytesReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TotalBytesReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TCPOpenRequestTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "TCPOpenResponseTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ NULL, 0, 0}
};

tr98Parameter_t para_UlDiag[] = {
	{ "DiagnosticsState", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "Interface", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "DownloadURL", PARAMETER_ATTR_WRITE, 257, json_type_string},
	//{ "UploadTransports", PARAMETER_ATTR_READONLY, 17, json_type_string},
	{ "DSCP", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "EthernetPriority", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TestFileLength", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "ROMTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "BOMTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "EOMTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "TotalBytesSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TCPOpenRequestTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ "TCPOpenResponseTime", PARAMETER_ATTR_READONLY, 17, json_type_time},
	{ NULL, 0, 0}
};