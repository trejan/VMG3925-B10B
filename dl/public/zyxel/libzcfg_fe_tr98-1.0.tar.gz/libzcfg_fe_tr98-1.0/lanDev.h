/*Parameter*/
extern tr98Parameter_t para_LanDev[];
extern tr98Parameter_t para_LanHostConfMgmt[];
extern tr98Parameter_t para_IpIntf[];
#ifdef IPV6INTERFACE_PROFILE
extern tr98Parameter_t para_IpIntfV6Addr[];
extern tr98Parameter_t para_IpIntfV6Prefix[];
#endif
#ifdef ROUTERADVERTISEMENT_PROFILE
extern tr98Parameter_t para_IpIntfRouterAdver[];
#endif
#ifdef IPV6SERVER_PROFILE
extern tr98Parameter_t para_IpIntfV6Srv[];
#endif
extern tr98Parameter_t para_DhcpStaticAddr[];
extern tr98Parameter_t para_DhcpOpt[];
extern tr98Parameter_t para_DhcpCondServPool[];
extern tr98Parameter_t para_DhcpCondServPoolDhcpStaticAddr[];
extern tr98Parameter_t para_DhcpCondServPoolDhcpOpt[];
extern tr98Parameter_t para_LanEthIntfConf[];
extern tr98Parameter_t para_LanEthIntfConfStat[];
extern tr98Parameter_t para_LanDevWlanCfg[];
extern tr98Parameter_t para_LanDevWlanCfgWps[];
extern tr98Parameter_t para_WepKey[];
extern tr98Parameter_t para_Psk[];

/*Handler Function*/
extern zcfgRet_t lanDevObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDevObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanDevObjDel(char *tr98FullPathName);

extern zcfgRet_t lanHostConfMgmtObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanHostConfMgmtObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);

extern zcfgRet_t lanIpIntfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanIpIntfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t lanIpIntfObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanIpIntfObjDel(char *tr98FullPathName);

extern zcfgRet_t lanDhcpStaticAddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDhcpStaticAddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t lanDhcpStaticAddrObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanDhcpStaticAddrObjDel(char *tr98FullPathName);

extern zcfgRet_t lanDhcpOptObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDhcpOptObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t lanDhcpOptObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanDhcpOptObjDel(char *tr98FullPathName);

extern zcfgRet_t lanDhcpCondServPoolObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDhcpCondServPoolObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t lanDhcpCondServPoolObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanDhcpCondServPoolObjDel(char *tr98FullPathName);

extern zcfgRet_t lanDhcpCondServPoolStaticAddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDhcpCondServPoolStaticAddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t lanDhcpCondServPoolStaticAddrObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanDhcpCondServPoolStaticAddrObjDel(char *tr98FullPathName);

extern zcfgRet_t lanDhcpCondServPoolOptObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDhcpCondServPoolOptObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t lanDhcpCondServPoolOptObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t lanDhcpCondServPoolOptObjDel(char *tr98FullPathName);

extern zcfgRet_t lanEthIntfConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanEthIntfConfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);

extern zcfgRet_t lanEthIntfConfStatObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);

/*InternetGatewayDevice.LANDevice.i.WLANConfiguration.i*/
extern zcfgRet_t lanDevWlanCfgObjGet(char *, int, struct json_object **);
extern zcfgRet_t lanDevWlanCfgObjSet(char *, int, struct json_object *, struct json_object *);

/*InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.WPS*/
extern zcfgRet_t lanDevWlanCfgWpsObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDevWlanCfgWpsObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);

/*InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.PreSharedKey.i*/
extern zcfgRet_t lanDevWlanCfgPskObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t lanDevWlanCfgPskObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);


/*InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Address.i*/
extern zcfgRet_t lanIpIntfV6AddrObjGet(char *, int, struct json_object **);
extern zcfgRet_t lanIpIntfV6AddrObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t lanIpIntfV6AddrObjAdd(char *, int *);
extern zcfgRet_t lanIpIntfV6AddrObjDel(char *);

/*InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Prefix.i*/
extern zcfgRet_t lanIpIntfV6PrefixObjGet(char *, int, struct json_object **);
extern zcfgRet_t lanIpIntfV6PrefixObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t lanIpIntfV6PrefixObjAdd(char *, int *);
extern zcfgRet_t lanIpIntfV6PrefixObjDel(char *);

/*InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_RouterAdvertisement.*/
extern zcfgRet_t lanIpIntfRouterAdverObjGet(char *, int, struct json_object **);
extern zcfgRet_t lanIpIntfRouterAdverObjSet(char *, int, struct json_object *, struct json_object *);

/*InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_DHCPv6Server.*/
extern zcfgRet_t lanIpIntfV6SrvObjGet(char *, int, struct json_object **);
extern zcfgRet_t lanIpIntfV6SrvObjSet(char *, int, struct json_object *, struct json_object *);


