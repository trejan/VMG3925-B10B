/*All TR98 Full Path Name*/
#define TR98_IGD								"InternetGatewayDevice"
#define TR98_SERVICE                              "InternetGatewayDevice.Services"
#define TR98_VOICE_SRV                            "InternetGatewayDevice.Services.VoiceService.i"
#define TR98_VOICE_CAPB                           "InternetGatewayDevice.Services.VoiceService.i.Capabilities"
#define TR98_VOICE_CAPB_SIP                       "InternetGatewayDevice.Services.VoiceService.i.Capabilities.SIP"
#define TR98_VOICE_CAPB_MGCP                      "InternetGatewayDevice.Services.VoiceService.i.Capabilities.MGCP"
#define TR98_VOICE_CAPB_H323                      "InternetGatewayDevice.Services.VoiceService.i.Capabilities.H323"
#define TR98_VOICE_CAPB_CODEC                     "InternetGatewayDevice.Services.VoiceService.i.Capabilities.Codec.i"
#define TR98_VOICE_PROF                           "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i"
#define TR98_VOICE_PROF_SRV_PRO_INFO              "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.ServiceProviderInfo"
#define TR98_VOICE_PROF_SIP                       "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.SIP"
#define TR98_VOICE_PROF_SIP_SUBSCRIBE_OBJ         "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.SIP.EventSubscribe.i"
#define TR98_VOICE_PROF_SIP_RESP_MAP_OBJ          "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.SIP.ResponseMap.i"
#define TR98_VOICE_PROF_RTP                       "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.RTP"
#define TR98_VOICE_PROF_RTP_RTCP                  "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.RTP.RTCP"
#define TR98_VOICE_PROF_RTP_SRTP                  "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.RTP.SRTP"
#define TR98_VOICE_PROF_RTP_REDUNDANCY            "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.RTP.Redundancy"
#define TR98_VOICE_PROF_NUM_PLAN                  "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.NumberingPlan"
#define TR98_VOICE_PROF_NUM_PLAN_PREFIX_INFO      "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.NumberingPlan.PrefixInfo.i"
#define TR98_VOICE_PROF_TONE                      "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Tone"
#define TR98_VOICE_PROF_TONE_EVENT                "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Tone.Event.i"
#define TR98_VOICE_PROF_TONE_DESCRIPTION          "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Tone.Description.i"
#define TR98_VOICE_PROF_TONE_PATTERN              "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Tone.Pattern.i"
#define TR98_VOICE_PROF_FAX_T38                   "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.FaxT38"
#define TR98_VOICE_LINE                           "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i"
#define TR98_VOICE_LINE_SIP                       "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.SIP"
#define TR98_VOICE_LINE_SIP_EVENT_SUBS            "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.SIP.EventSubscribe.i"
#define TR98_VOICE_LINE_RINGER                    "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Ringer"
#define TR98_VOICE_LINE_RINGER_EVENT              "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Ringer.Event.i"
#define TR98_VOICE_LINE_RINGER_DESCRIPTION        "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Ringer.Description.i"
#define TR98_VOICE_LINE_RINGER_PATTERN            "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Ringer.Pattern.i"
#define TR98_VOICE_LINE_CALLING_FEATURE           "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.CallingFeatures"
#define TR98_VOICE_LINE_PROCESSING                "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.VoiceProcessing"
#define TR98_VOICE_LINE_CODEC                     "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Codec"
#define TR98_VOICE_LINE_CODEC_LIST                "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Codec.List.i"
#define TR98_VOICE_LINE_SESSION                   "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Session.i"
#define TR98_VOICE_LINE_STATS                     "InternetGatewayDevice.Services.VoiceService.i.VoiceProfile.i.Line.i.Stats"
#define TR98_VOICE_PHY_INTF                       "InternetGatewayDevice.Services.VoiceService.i.PhyInterface.i"
#define TR98_VOICE_PSTN                           "InternetGatewayDevice.Services.VoiceService.i.X_ZyXEL_COM_PSTN.i"
#define TR98_VOICE_COMMON                         "InternetGatewayDevice.Services.VoiceService.i.X_ZyXEL_COM_Common"
#define TR98_VOICE_PHONE_BOOK                     "InternetGatewayDevice.Services.VoiceService.i.X_ZyXEL_COM_VoicePhoneBook.i"
#define TR98_VOICE_FXO                            "InternetGatewayDevice.Services.VoiceService.i.X_ZyXEL_COM_FXO"
#define TR98_VOICE_FXO_PORT                       "InternetGatewayDevice.Services.VoiceService.i.X_ZyXEL_COM_FXO.Port.i"
#define TR98_CAPB                     "InternetGatewayDevice.Capabilities"
#define TR98_PERF_DIAG                "InternetGatewayDevice.Capabilities.PerformanceDiagnostic"
#define TR98_DEV_INFO                 "InternetGatewayDevice.DeviceInfo"
#define TR98_VEND_CONF_FILE           "InternetGatewayDevice.DeviceInfo.VendorConfigFile.i"
#define TR98_DEV_CONF                 "InternetGatewayDevice.DeviceConfig"
#define TR98_MGMT_SRV                 "InternetGatewayDevice.ManagementServer"
#define TR98_MGAB_DEV                 "InternetGatewayDevice.ManagementServer.ManageableDevice.i"
#define TR98_TIME                     "InternetGatewayDevice.Time"
#define TR98_USR_INTF                 "InternetGatewayDevice.UserInterface"
#define TR98_CAPT_PORTAL              "InternetGatewayDevice.CaptivePortal"
#define TR98_L3_FWD                   "InternetGatewayDevice.Layer3Forwarding"
#define TR98_FWD                      "InternetGatewayDevice.Layer3Forwarding.Forwarding.i"
#define TR98_L2_BR                    "InternetGatewayDevice.Layer2Bridging"
#define TR98_BR                       "InternetGatewayDevice.Layer2Bridging.Bridge.i"
#define TR98_PORT                     "InternetGatewayDevice.Layer2Bridging.Bridge.i.Port.i"
#define TR98_VLAN                     "InternetGatewayDevice.Layer2Bridging.Bridge.i.VLAN.i"
#define TR98_FILTER                   "InternetGatewayDevice.Layer2Bridging.Filter.i"
#define TR98_MARK                     "InternetGatewayDevice.Layer2Bridging.Marking.i"
#define TR98_AVAI_INTF                "InternetGatewayDevice.Layer2Bridging.AvailableInterface.i"
#define TR98_QUE_MGMT                 "InternetGatewayDevice.QueueManagement"
#define TR98_CLS                      "InternetGatewayDevice.QueueManagement.Classification.i"
#define TR98_APP                      "InternetGatewayDevice.QueueManagement.App.i"
#define TR98_FLOW                     "InternetGatewayDevice.QueueManagement.Flow.i"
#define TR98_POLICER                  "InternetGatewayDevice.QueueManagement.Policer.i"
#define TR98_QUE                      "InternetGatewayDevice.QueueManagement.Queue.i"
#define TR98_SHAPER					  "InternetGatewayDevice.QueueManagement.X_ZYXEL_Shaper.i"
#define TR98_QUE_STAT                 "InternetGatewayDevice.QueueManagement.QueueStats.i"
#define TR98_LAN_CONF_SEC             "InternetGatewayDevice.LANConfigSecurity"
#define TR98_IP_PING_DIAG             "InternetGatewayDevice.IPPingDiagnostics"
#define TR98_TRA_RT_DIAG              "InternetGatewayDevice.TraceRouteDiagnostics"
#define TR98_RT_HOP                   "InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.i"
#define TR98_DL_DIAG                  "InternetGatewayDevice.DownloadDiagnostics"
#define TR98_UL_DIAG                  "InternetGatewayDevice.UploadDiagnostics"
#define TR98_UDP_ECHO_CONF            "InternetGatewayDevice.UDPEchoConfig"
#define TR98_LAN_DEV                  "InternetGatewayDevice.LANDevice.i"
#define TR98_LAN_HOST_CONF_MGMT       "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement"
#define TR98_IP_INTF                  "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i"
#ifdef IPV6INTERFACE_PROFILE
#define TR98_IP_INTF_IPV6ADDR         "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Address.i"
#define TR98_IP_INTF_IPV6PREFIX       "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Prefix.i"
#endif
#ifdef ROUTERADVERTISEMENT_PROFILE
#define TR98_IP_INTF_ROUTERADVER      "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_RouterAdvertisement"
#endif
#ifdef IPV6SERVER_PROFILE
#define TR98_IP_INTF_DHCPV6SRV        "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_DHCPv6Server"
#endif
#define TR98_DHCP_STATIC_ADDR         "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPStaticAddress.i"
#define TR98_DHCP_OPT                 "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPOption.i"
#define TR98_DHCP_COND_SERVPOOL       "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i"
#define TR98_SERVPOOL_DHCP_STATICADDR "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i.DHCPStaticAddress.i"
#define TR98_SERVPOOL_DHCP_OPT        "InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i.DHCPOption.i"
#define TR98_LAN_ETH_INTF_CONF        "InternetGatewayDevice.LANDevice.i.LANEthernetInterfaceConfig.i"
#define TR98_LAN_ETH_INTF_CONF_STAT   "InternetGatewayDevice.LANDevice.i.LANEthernetInterfaceConfig.i.Stats"
#define TR98_LAN_USB_INTF_CONF        "InternetGatewayDevice.LANDevice.i.LANUSBInterfaceConfig.i"
#define TR98_LAN_USB_INTF_CONF_STAT   "InternetGatewayDevice.LANDevice.i.LANUSBInterfaceConfig.i.Stats"
#define TR98_LAN_DEV_WLAN_CFG         "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i"
#define TR98_WLAN_CFG_STAT            "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.Stats"
#define TR98_WPS                      "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.WPS"
#define TR98_REG                      "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.WPS.Registrar.i"
#define TR98_ASSOC_DEV                "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.AssociatedDevice.i"
#define TR98_WEP_KEY                  "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.WEPKey.i"
#define TR98_PSK                      "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.PreSharedKey.i"
#define TR98_AP_WMM_PARAM             "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.APWMMParameter.i"
#define TR98_STA_WMM_PARAM            "InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.STAWMMParameter.i"
#define TR98_HOSTS                    "InternetGatewayDevice.LANDevice.i.Hosts.i"
#define TR98_HOST                     "InternetGatewayDevice.LANDevice.i.Hosts.i.Host.i"
#define TR98_LAN_INTF                 "InternetGatewayDevice.LANInterfaces"
#define TR98_LAN_INTF_ETH_INTF_CONF   "InternetGatewayDevice.LANInterfaces.LANEthernetInterfaceConfig.i"
#define TR98_USB_INTF_CONF            "InternetGatewayDevice.LANInterfaces.USBInterfaceConfig.i"
#define TR98_LAN_INTF_WLAN_CFG        "InternetGatewayDevice.LANInterfaces.WLANConfiguration.i"
#define TR98_WAN_DEV                  "InternetGatewayDevice.WANDevice.i"
#define TR98_WAN_COMM_INTF_CONF       "InternetGatewayDevice.WANDevice.i.WANCommonInterfaceConfig"
#define TR98_WAN_COMM_INTF_CONNECT    "InternetGatewayDevice.WANDevice.i.WANCommonInterfaceConfig.Connection.i"
#define TR98_WAN_DSL_INTF_CONF        "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig"
#define TR98_WAN_DSL_INTF_TEST_PARAM  "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.TestParams"
#define TR98_WAN_DSL_INTF_CONF_STAT   "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.Stats"
#define TR98_TTL                      "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.Stats.Total"
#define TR98_ST                       "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.Stats.Showtime"
#define TR98_LST_SHOWTIME             "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.Stats.LastShowtime"
#define TR98_CURRENT_DAY              "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.Stats.CurrentDay"
#define TR98_QTR_HR                   "InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.Stats.QuarterHour"
#define TR98_WAN_ETH_INTF_CONF        "InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig"
#define TR98_WAN_ETH_INTF_CONF_STAT   "InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig.Stats"
#define TR98_WAN_DSL_CONN_MGMT        "InternetGatewayDevice.WANDevice.i.WANDSLConnectionManagement"
#define TR98_WAN_DSL_CONN_SRVC        "InternetGatewayDevice.WANDevice.i.WANDSLConnectionManagement.ConnectionService.i"
#define TR98_WAN_DSL_DIAG             "InternetGatewayDevice.WANDevice.i.WANDSLDiagnostics"
#define TR98_WAN_CONN_DEV             "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i"
#define TR98_WAN_DSL_LINK_CONF        "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANDSLLinkConfig"
#define TR98_WAN_ATM_F5_LO_DIAG       "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANATMF5LoopbackDiagnostics"
#define TR98_WAN_ATM_F4_LO_DIAG       "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.X_ZYXEL_WANATMF4LoopbackDiagnostics"
#define TR98_WAN_PTM_LINK_CONF        "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPTMLinkConfig"
#define TR98_WAN_PTM_LINK_CONF_STAT   "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPTMLinkConfig.Stats"
#define TR98_WAN_ETH_LINK_CONF        "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANEthernetLinkConfig"
#define TR98_WAN_POTS_LINK_CONF       "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPOTSLinkConfig"
#define TR98_WAN_IP_CONN              "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i"
#define TR98_DHCP_CLIENT              "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient"
#define TR98_SENT_DHCP_OPT            "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient.SentDHCPOption.i"
#define TR98_REQ_DHCP_OPT             "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient.ReqDHCPOption.i"
#define TR98_WAN_IP_PORT_MAP          "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.PortMapping.i"
#define TR98_WAN_IP_CONN_STAT         "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.Stats"
#ifdef IPV6INTERFACE_PROFILE
#define TR98_WAN_IP_CONN_IPV6ADDR     "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Address.i"
#define TR98_WAN_IP_CONN_IPV6PREFIX	  "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Prefix.i"
#endif
#ifdef DHCPV6CLIENT_PROFILE
#define TR98_WAN_IP_CONN_DHCPV6CLIENT "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_DHCPv6Client"
#endif
#ifdef IPV6RD_PROFILE
#define TR98_WAN_IP_CONN_IPV6RD	      "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6rd"
#endif
#define TR98_WAN_PPP_CONN             "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i"
#define TR98_WAN_PPP_PORT_MAP         "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.PortMapping.i"
#define TR98_WAN_PPP_CONN_STAT        "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.Stats"
#ifdef IPV6INTERFACE_PROFILE
#define TR98_WAN_PPP_CONN_IPV6ADDR     "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Address.i"
#define TR98_WAN_PPP_CONN_IPV6PREFIX   "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Prefix.i"
#endif
#ifdef DHCPV6CLIENT_PROFILE
#define TR98_WAN_PPP_CONN_DHCPV6CLIENT "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_DHCPv6Client"
#endif
#ifdef IPV6RD_PROFILE
#define TR98_WAN_PPP_CONN_IPV6RD       "InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6rd"
#endif
#define TR98_ZYXEL_EXT                "InternetGatewayDevice.X_ZYXEL_EXT"
#define TR98_DNS_RT_ENTRY             "InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.i"
#define TR98_D_DNS                    "InternetGatewayDevice.X_ZYXEL_EXT.DynamicDNS"
#define TR98_FIREWALL                 "InternetGatewayDevice.Firewall"
#define TR98_FIREWALL_LEVEL           "InternetGatewayDevice.Firewall.Level.i"
#define TR98_FIREWALL_CHAIN           "InternetGatewayDevice.Firewall.Chain.i"
#define TR98_FIREWALL_CHAIN_RULE      "InternetGatewayDevice.Firewall.Chain.i.Rule.i"
#define TR98_SCHEDULE                 "InternetGatewayDevice.X_ZYXEL_EXT.Schedule.i"

#define OBSOLETED 1
#define ZYXEL_EXT 1

#define ATTR_INDEX_CREA ATTR_INDEXNODE|OBJECT_ATTR_CREATE

/* TR98 Full Path Name          Attribute	    Parameter List          Get func                 Set func                Add func          Del func         Notify func	Get Attr func		Set Attr func*/
tr98Object_t tr98Obj[] = {
{TR98_IGD,                      0,              para_Root,              rootObjGet,              NULL,                   NULL,             NULL,            NULL},
{TR98_SERVICE,					0,				para_Service,			NULL,					 NULL,					 NULL,			   NULL,			NULL},
{TR98_VOICE_SRV,				ATTR_INDEXNODE,	para_VoiceSrv,			voiceSrvGet,			 NULL,					 NULL,			   NULL, voiceNotify, voiceSrvAttrGet, voiceSrvAttrSet},
{TR98_VOICE_CAPB,				0,				para_VoiceCapb,			voiceCapbGet,			 NULL,					 NULL,			   NULL, voiceNotify, voiceCapbAttrGet, voiceCapbAttrSet},
{TR98_VOICE_CAPB_SIP,			0,				para_VoiceCapbSip,		voiceCapbSipGet,		 NULL,					 NULL,			   NULL, voiceNotify, voiceCapbSipAttrGet, voiceCapbSipAttrSet},
{TR98_VOICE_CAPB_CODEC,			ATTR_INDEXNODE,	para_VoiceCapbCodec,	voiceCapbCodecGet,		 NULL,					 NULL,			   NULL, voiceNotify, voiceCapbCodecAttrGet, voiceCapbCodecAttrSet},
{TR98_VOICE_COMMON,				0,				para_VoiceCommon, 		voiceCommonGet,			 voiceCommonSet, 	NULL, 		NULL, 	NULL},
{TR98_VOICE_PROF,				ATTR_INDEX_CREA,para_VoiceProf,			voiceProfGet,			 voiceProfSet,			 voiceProfAdd,	   voiceProfDel, voiceNotify, voiceProfAttrGet, voiceProfAttrSet},
{TR98_VOICE_PROF_SIP,			0,				para_VoiceProfSip,		voiceProfSipGet,		 voiceProfSipSet,		 NULL,			   NULL, voiceNotify, voiceProfSipAttrGet, voiceProfSipAttrSet},
{TR98_VOICE_LINE,				ATTR_INDEX_CREA,para_VoiceLine,			voiceLineGet,			 voiceLineSet,			 voiceLineAdd,	   voiceLineDel,	voiceNotify, voiceLineAttrGet, voiceLineAttrSet},
{TR98_VOICE_LINE_SIP,			0,				para_VoiceLineSip,		voiceLineSipGet,		 voiceLineSipSet,		 NULL,			   NULL,	voiceNotify, voiceLineSipAttrGet, voiceLineSipAttrSet},
{TR98_VOICE_LINE_PROCESSING,	0,				para_VoiceLineProcessing, voiceLineProcGet,		 voiceLineProcSet,		 NULL,			   NULL,	voiceNotify, voiceLineProcAttrGet, voiceLineProcAttrSet},
{TR98_VOICE_LINE_CODEC,			0, 				para_VoiceLineCodec, 	voiceLineCodecGet,       NULL,					 NULL,			   NULL,	voiceNotify, voiceLineCodecAttrGet, voiceLineCodecAttrSet},
{TR98_VOICE_LINE_CODEC_LIST,	ATTR_INDEXNODE,	para_VoiceLineCodecList, voiceLineCodecListGet,	 NULL,					 NULL,			   NULL,	voiceNotify, voiceLineCodecListAttrGet, voiceLineCodecListAttrSet},
{TR98_VOICE_PHY_INTF,			ATTR_INDEXNODE,	para_VoicePhyIntf,		voicePhyIntfGet,		 voicePhyIntfSet,		 NULL,			   NULL,	voiceNotify, voicePhyIntfAttrGet, voicePhyIntfAttrSet},
{TR98_CAPB,                     0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_PERF_DIAG,                0,              para_PerpDiag,          perfDiagObjGet,          NULL,                   NULL,             NULL,            NULL},
{TR98_DEV_INFO,                 0,              para_DevInfo,           devInfoObjGet,           devInfoObjSet,          NULL,             NULL,            devInfoObjNotify, devInfoObjAttrGet, devInfoObjAttrSet},
{TR98_VEND_CONF_FILE,           ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_DEV_CONF,                 0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_MGMT_SRV,                 0,              para_MgmtSrv,           mgmtSrvObjGet,           mgmtSrvObjSet,          NULL,             NULL,            mgmtSrvObjNotify, mgmtSrvObjAttrGet, mgmtSrvObjAttrSet},
{TR98_MGAB_DEV,                 ATTR_INDEXNODE, para_MgabDev,           mgabDevObjGet,           NULL,                   NULL,             NULL,            NULL},
{TR98_TIME,                     0,              para_Time,              timeObjGet,              timeObjSet,             NULL,             NULL,            NULL},
{TR98_USR_INTF,                 0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_CAPT_PORTAL,              0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_L3_FWD,                   0,              para_L3Fwd,             l3fwdObjGet,             NULL,                   NULL,             NULL,            NULL},
{TR98_FWD,                      ATTR_INDEX_CREA,para_Fwd,               l3fwdFwdTbObjGet,        l3fwdFwdTbObjSet,       l3fwdFwdTbObjAdd, l3fwdFwdTbObjDel,NULL},
{TR98_L2_BR,                    0,              para_L2Br,              l2BridingObjGet,         NULL,                   NULL,             NULL,            NULL},
{TR98_BR,                       ATTR_INDEX_CREA,para_Br,                l2BrObjGet,              l2BrObjSet,             l2BrObjAdd,       l2BrObjDel,      NULL},
{TR98_PORT,                     ATTR_INDEXNODE, para_Port,              NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_VLAN,                     ATTR_INDEXNODE,	para_Vlan,              l2BrVlanObjGet,          l2BrVlanObjSet,                   NULL,             NULL,            NULL},
{TR98_FILTER,                   ATTR_INDEX_CREA,para_Filter,            l2BrFilterObjGet,        l2BrFilterObjSet,       l2BrFilterObjAdd, l2BrFilterObjDel,NULL},
{TR98_MARK,                     ATTR_INDEXNODE, para_Mark,              NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_AVAI_INTF,                ATTR_INDEXNODE, para_AvaiIntf,          l2BrAvailableIntfObjGet, NULL,                   NULL,             NULL,            NULL},
{TR98_QUE_MGMT,                 0,              para_qMgmt,          	qMgmtGet,     			 qMgmtSet,               NULL,             NULL,            NULL},
{TR98_CLS,                      ATTR_INDEX_CREA, para_Cls,          	qMgmtClsGet,			 qMgmtClsSet,            qMgmtClsAdd,      qMgmtClsDel,     NULL},
{TR98_APP,                      ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_FLOW,                     ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_POLICER,                  ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_QUE,                      ATTR_INDEX_CREA, para_Que,              qMgmtQueGet,			 qMgmtQueSet,            qMgmtQueAdd,      qMgmtQueDel,     NULL},
{TR98_SHAPER,					ATTR_INDEX_CREA, para_Shaper,			qMgmtShaperGet,			 qMgmtShaperSet,         qMgmtShaperAdd,   qMgmtShaperDel,     NULL},
{TR98_QUE_STAT,                 ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_CONF_SEC,             0,              para_LanConfSec,        lanConfSecObjGet,        lanConfSecObjSet,       NULL,             NULL,            NULL},
{TR98_IP_PING_DIAG,             0,              para_IpPingDiag,        ipPingDiagObjGet,        ipPingDiagObjSet,       NULL,             NULL,            NULL},
{TR98_TRA_RT_DIAG,              0,              para_TraceRtDiag,       traceRtDiagObjGet,       traceRtDiagObjSet,      NULL,             NULL,            NULL},
{TR98_RT_HOP,                   ATTR_INDEXNODE, para_RtHop,		        routeHopsObjGet,         NULL,                   NULL,             NULL,            NULL},
{TR98_DL_DIAG,                  0,              para_DlDiag,			dlDiagObjGet,            dlDiagObjSet,           NULL,             NULL,            NULL},
{TR98_UL_DIAG,                  0,              para_UlDiag,			ulDiagObjGet,            ulDiagObjSet,           NULL,             NULL,            NULL},
{TR98_UDP_ECHO_CONF,            0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_DEV,                  ATTR_INDEX_CREA,para_LanDev,            lanDevObjGet,            NULL,                   lanDevObjAdd,     lanDevObjDel,    NULL},
{TR98_LAN_HOST_CONF_MGMT,       0,              para_LanHostConfMgmt,   lanHostConfMgmtObjGet,   lanHostConfMgmtObjSet,  NULL,             NULL,            NULL},
{TR98_IP_INTF,                  ATTR_INDEX_CREA,para_IpIntf,		    lanIpIntfObjGet,         lanIpIntfObjSet,        lanIpIntfObjAdd,  lanIpIntfObjDel,	NULL},
#ifdef IPV6INTERFACE_PROFILE
{TR98_IP_INTF_IPV6ADDR,         ATTR_INDEX_CREA,para_IpIntfV6Addr,		lanIpIntfV6AddrObjGet,   lanIpIntfV6AddrObjSet,  lanIpIntfV6AddrObjAdd,  lanIpIntfV6AddrObjDel,	NULL},
{TR98_IP_INTF_IPV6PREFIX,		ATTR_INDEX_CREA,para_IpIntfV6Prefix,	lanIpIntfV6PrefixObjGet, lanIpIntfV6PrefixObjSet,lanIpIntfV6PrefixObjAdd,lanIpIntfV6PrefixObjDel, NULL},
#endif
#ifdef ROUTERADVERTISEMENT_PROFILE
{TR98_IP_INTF_ROUTERADVER,      0,				para_IpIntfRouterAdver, lanIpIntfRouterAdverObjGet, lanIpIntfRouterAdverObjSet,        NULL,  NULL,	NULL},
#endif
#ifdef IPV6SERVER_PROFILE
{TR98_IP_INTF_DHCPV6SRV,        0,				para_IpIntfV6Srv,		lanIpIntfV6SrvObjGet,    lanIpIntfV6SrvObjSet,        NULL,  NULL,	NULL},
#endif
{TR98_DHCP_STATIC_ADDR,         ATTR_INDEX_CREA,para_DhcpStaticAddr,    lanDhcpStaticAddrObjGet, lanDhcpStaticAddrObjSet,lanDhcpStaticAddrObjAdd,lanDhcpStaticAddrObjDel,NULL},
{TR98_DHCP_OPT,                 ATTR_INDEX_CREA,para_DhcpOpt,           lanDhcpOptObjGet,        lanDhcpOptObjSet,       lanDhcpOptObjAdd, lanDhcpOptObjDel,NULL},
{TR98_DHCP_COND_SERVPOOL,       ATTR_INDEXNODE, para_DhcpCondServPool,  NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_SERVPOOL_DHCP_STATICADDR, ATTR_INDEXNODE,	para_DhcpCondServPoolDhcpStaticAddr,NULL,        NULL,                   NULL,             NULL,            NULL},
{TR98_SERVPOOL_DHCP_OPT,        ATTR_INDEXNODE, para_DhcpCondServPoolDhcpOpt,NULL,               NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_ETH_INTF_CONF,        ATTR_INDEXNODE, para_LanEthIntfConf,    lanEthIntfConfObjGet,    lanEthIntfConfObjSet,   NULL,             NULL,            NULL},
{TR98_LAN_ETH_INTF_CONF_STAT,   0,              para_LanEthIntfConfStat,lanEthIntfConfStatObjGet,NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_USB_INTF_CONF,        ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_USB_INTF_CONF_STAT,   0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_DEV_WLAN_CFG,         ATTR_INDEXNODE,	para_LanDevWlanCfg,     lanDevWlanCfgObjGet,     lanDevWlanCfgObjSet,    NULL,             NULL,            NULL},
{TR98_WLAN_CFG_STAT,            0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WPS,                      0,              para_LanDevWlanCfgWps,  lanDevWlanCfgWpsObjGet,  lanDevWlanCfgWpsObjSet, NULL,             NULL,            NULL},
{TR98_REG,                      ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_ASSOC_DEV,                ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WEP_KEY,                  ATTR_INDEXNODE, para_WepKey,            NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_PSK,                      ATTR_INDEXNODE, para_Psk,               lanDevWlanCfgPskObjGet,  lanDevWlanCfgPskObjSet, NULL,             NULL,            NULL},
{TR98_AP_WMM_PARAM,             ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_STA_WMM_PARAM,            ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_HOSTS,                    ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_HOST,                     ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_INTF,                 0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_INTF_ETH_INTF_CONF,   ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_USB_INTF_CONF,            ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LAN_INTF_WLAN_CFG,        ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_DEV,                  ATTR_INDEXNODE,	para_WanDev,            WANDeviceObjGet,         NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_COMM_INTF_CONF,       0,              para_WANCommIfaceCfg,   WANCommIfaceCfgObjGet,   NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_COMM_INTF_CONNECT,    ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_DSL_INTF_CONF,        0,              para_WANDslIfaceCfg,    WANDslIfaceCfgObjGet,    WANDslIfaceCfgObjSet,   NULL,             NULL,            NULL},
{TR98_WAN_DSL_INTF_TEST_PARAM,  0,              para_WANDslIfTestParam, WANDslIfTestParamGet,    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_DSL_INTF_CONF_STAT,   0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_TTL,                      0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_ST,                       0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_LST_SHOWTIME,             0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_CURRENT_DAY,              0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_QTR_HR,                   0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_ETH_INTF_CONF,        0,              para_WANEthIntfConf,    WANEthIfaceCfgObjGet,	 WANEthIfaceCfgObjSet,   NULL,             NULL,            NULL},
{TR98_WAN_ETH_INTF_CONF_STAT,   0,              para_WANEthIntfConfStat,WANEthIfaceCfgStObjGet,  NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_DSL_DIAG,             0,              para_WANDslDiag,        WANDslDiagObjGet,        WANDslDiagObjSet,       NULL,             NULL,            NULL},
{TR98_WAN_CONN_DEV,             ATTR_INDEX_CREA,para_WANConnDev,        WANConnDevObjGet,        NULL,                   WANConnDevObjAdd, WANConnDevObjDel,NULL},
{TR98_WAN_DSL_LINK_CONF,        0,              para_WANDslLinkConf,    WANDslLinkConfObjGet,    WANDslLinkConfObjSet,   NULL,             NULL,            NULL},
{TR98_WAN_ATM_F5_LO_DIAG,       0,              para_WanAtmF5LoDiag,    WANAtmF5LoConfObjGet,    WANAtmF5LoConfObjSet,   NULL,             NULL,            NULL},
{TR98_WAN_ATM_F4_LO_DIAG,		0,				para_WanAtmF4LoDiag,	WANAtmF4LoConfObjGet,	 WANAtmF4LoConfObjSet,	 NULL,			   NULL,			NULL},
{TR98_WAN_PTM_LINK_CONF,        0,              para_WANPtmLinkConf,    WANPtmLinkConfObjGet,    WANPtmLinkConfObjSet,   NULL,             NULL,            NULL},
{TR98_WAN_PTM_LINK_CONF_STAT,   0,              para_WANPtmLinkConfStat,WANPtmLinkConfStObjGet,  NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_ETH_LINK_CONF,        0,              para_WANEthLinkConf,    WANEthLinkConfObjGet,    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_POTS_LINK_CONF,       0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_IP_CONN,              ATTR_INDEX_CREA,para_WANIpConn,         WANIpConnObjGet,         WANIpConnObjSet,        WANIpConnObjAdd,  WANIpConnObjDel, NULL},
{TR98_DHCP_CLIENT,              0,              para_DhcpClient,        DhcpClientObjGet,        NULL,                   NULL,             NULL,            NULL},
{TR98_SENT_DHCP_OPT,            ATTR_INDEX_CREA, para_SentDhcpOpt,      DhcpClientSentOptObjGet, DhcpClientSentOptObjSet,DhcpClientSentOptObjAdd, DhcpClientSentOptObjDel,            NULL},
{TR98_REQ_DHCP_OPT,             ATTR_INDEX_CREA, para_ReqDhcpOpt,       DhcpClientReqOptObjGet,  DhcpClientReqOptObjSet, DhcpClientReqOptObjAdd, DhcpClientReqOptObjDel,            NULL},
{TR98_WAN_IP_PORT_MAP,          ATTR_INDEX_CREA,para_WANIpPortMap,      WANPortMappingGet,       WANPortMappingSet,      WANPortMappingAdd,WANPortMappingDel,NULL},
{TR98_WAN_IP_CONN_STAT,         0,              para_WANIpConnStat,     WANConnStObjGet,         NULL,                   NULL,             NULL,            NULL},
#ifdef IPV6INTERFACE_PROFILE
{TR98_WAN_IP_CONN_IPV6ADDR,     ATTR_INDEX_CREA, para_WANIpv6Addr,      WANIpv6AddrObjGet,        WANIpv6AddrObjSet,     WANIpv6AddrObjAdd, WANIpv6AddrObjDel,            NULL},
{TR98_WAN_IP_CONN_IPV6PREFIX, 	ATTR_INDEX_CREA, para_WANIpv6Prefix, 	WANIpv6PrefixObjGet,	 WANIpv6PrefixObjSet,   WANIpv6PrefixObjAdd, WANIpv6PrefixObjDel,			NULL},
#endif
#ifdef DHCPV6CLIENT_PROFILE
{TR98_WAN_IP_CONN_DHCPV6CLIENT, 0, 				para_WANIpDhcpV6Client,     WANIpv6DhcpV6ObjGet, WANIpv6DhcpV6ObjSet,    NULL,             NULL,            NULL},
#endif
#ifdef IPV6RD_PROFILE
{TR98_WAN_IP_CONN_IPV6RD,       0,              para_WANIpv6Rd,     	WANIpv6RdObjGet,         WANIpv6RdObjSet,        NULL,             NULL,            NULL},
#endif
{TR98_WAN_PPP_CONN,             ATTR_INDEX_CREA,para_WANPppConn,        WANPppConnObjGet,        WANPppConnObjSet,       WANPppConnObjAdd, WANPppConnObjDel,NULL},
{TR98_WAN_PPP_PORT_MAP,         ATTR_INDEX_CREA,para_WANPppPortMap,     WANPortMappingGet,       WANPortMappingSet,      WANPortMappingAdd,WANPortMappingDel,NULL},	
{TR98_WAN_PPP_CONN_STAT,        0,              para_WANPppConnStat,    WANConnStObjGet,         NULL,                   NULL,             NULL,            NULL},
#ifdef IPV6INTERFACE_PROFILE
{TR98_WAN_PPP_CONN_IPV6ADDR,    ATTR_INDEX_CREA, para_WANPppv6Addr,     WANPppv6AddrObjGet,        WANPppv6AddrObjSet,     WANPppv6AddrObjAdd, WANPppv6AddrObjDel,            NULL},
{TR98_WAN_PPP_CONN_IPV6PREFIX, 	ATTR_INDEX_CREA, para_WANPppv6Prefix,	WANPppv6PrefixObjGet,	 WANPppv6PrefixObjSet,   WANPppv6PrefixObjAdd, WANPppv6PrefixObjDel,			NULL},
#endif
#ifdef DHCPV6CLIENT_PROFILE
{TR98_WAN_PPP_CONN_DHCPV6CLIENT, 0, 			para_WANPppDhcpV6Client, WANPppv6DhcpV6ObjGet, WANPppv6DhcpV6ObjSet,    NULL,             NULL,            NULL},
#endif
#ifdef IPV6RD_PROFILE
{TR98_WAN_PPP_CONN_IPV6RD,      0,				para_WANPppv6Rd,        WANPppv6RdObjGet,         WANPppv6RdObjSet,        NULL,             NULL,            NULL},
#endif
{TR98_FIREWALL,                 0,              para_Firewall,          firewallObjGet,          firewallObjSet,         NULL,             NULL,            NULL},
{TR98_FIREWALL_LEVEL,           ATTR_INDEX_CREA,para_FirewallLevel,     firewallLevelObjGet,     firewallLevelObjSet,    firewallLevelObjAdd,firewallLevelObjDel,NULL},
{TR98_FIREWALL_CHAIN,           ATTR_INDEX_CREA,para_FirewallChain,     firewallChainObjGet,     firewallChainObjSet,    firewallChainObjAdd,firewallChainObjDel,NULL},
{TR98_FIREWALL_CHAIN_RULE,      ATTR_INDEX_CREA,para_FirewallChainRule, firewallRuleObjGet,      firewallRuleObjSet,     firewallRuleObjAdd,firewallRuleObjDel,NULL},
#if ZYXEL_EXT
{TR98_ZYXEL_EXT,             	0,				NULL,        			NULL,        			 NULL,       			 NULL, 				NULL,			NULL},
{TR98_DNS_RT_ENTRY,             ATTR_INDEX_CREA,para_DnsRtEntry,        zyExtDnsRtObjGet,        zyExtDnsRtObjSet,       zyExtDnsRtObjAdd, zyExtDnsRtObjDel,NULL},
{TR98_D_DNS,                    0,              para_DDns,              zyExtDDnsObjGet,         zyExtDDnsObjSet,        NULL,             NULL,            NULL},
{TR98_SCHEDULE,                 ATTR_INDEX_CREA,para_Schedule,          scheduleObjGet,          scheduleObjSet,         scheduleObjAdd,   scheduleObjDel,  NULL},
#endif
#if OBSOLETED
#else
{TR98_WAN_DSL_CONN_MGMT,        0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
{TR98_WAN_DSL_CONN_SRVC,        ATTR_INDEXNODE, NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL},
#endif
{NULL,                          0,              NULL,                   NULL,                    NULL,                   NULL,             NULL,            NULL}
};
