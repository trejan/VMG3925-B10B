#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "schedule_parameter.h"

extern tr98Object_t tr98Obj[];


/* InternetGatewayDevice.X_ZYXEL_Schedule */
zcfgRet_t scheduleObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char scheduleObjFormate[128] = "InternetGatewayDevice.X_ZYXEL_EXT.Schedule.%hhu";
	uint32_t  scheduleOid = 0;
	objIndex_t scheduleIid;
	struct json_object *scheduleObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);
	IID_INIT(scheduleIid);
	scheduleIid.level= 1;
	if(sscanf(tr98FullPathName, scheduleObjFormate, scheduleIid.idx) != 1) return ZCFG_INVALID_OBJECT;	
	scheduleOid = RDM_OID_SCHEDULE;
	
	if((ret = zcfgFeObjJsonGet(scheduleOid, &scheduleIid, &scheduleObj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 schedule object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(scheduleObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		/*Not defined in tr181, give it a default value*/
		zcfgLog(ZCFG_LOG_DEBUG, "Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}
	json_object_put(scheduleObj);

	return ZCFG_SUCCESS;
}

zcfgRet_t scheduleObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char scheduleObjFormate[128] = "InternetGatewayDevice.X_ZYXEL_EXT.Schedule.%hhu";
	uint32_t  scheduleOid = 0;
	objIndex_t scheduleIid;
	struct json_object *scheduleObj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	IID_INIT(scheduleIid);
	scheduleIid.level= 1;
	if(sscanf(tr98FullPathName, scheduleObjFormate, scheduleIid.idx) != 1) return ZCFG_INVALID_OBJECT;	
	scheduleOid = RDM_OID_SCHEDULE;

	if((ret = zcfgFeObjJsonGet(scheduleOid, &scheduleIid, &scheduleObj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = scheduleObj;
		scheduleObj = NULL;
		scheduleObj = zcfgFeJsonMultiObjAppend(scheduleOid, &scheduleIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(scheduleObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(scheduleObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		paramList++;	
	} /*Edn while*/
	
	/*Set */
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(scheduleOid, &scheduleIid, scheduleObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(scheduleObj);
			return ret;
		}
		json_object_put(scheduleObj);
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t scheduleObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	uint32_t  scheduleOid = 0;
	objIndex_t scheduleIid;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	IID_INIT(scheduleIid);
	scheduleOid = RDM_OID_SCHEDULE;

	if((ret = zcfgFeObjStructAdd(scheduleOid, &scheduleIid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_DEBUG,"%s : Add X_ZYXEL_Schedule Fail.\n", __FUNCTION__);
		return ret;
	}

	*idx = scheduleIid.idx[0];
	
	return ZCFG_SUCCESS;
}

zcfgRet_t scheduleObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char scheduleObjFormate[128] = "InternetGatewayDevice.X_ZYXEL_EXT.Schedule.%hhu";
	uint32_t  scheduleOid = 0;
	objIndex_t scheduleIid;

	zcfgLog(ZCFG_LOG_DEBUG, "Enter %s\n", __FUNCTION__);

	IID_INIT(scheduleIid);
	scheduleIid.level= 1;
	if(sscanf(tr98FullPathName, scheduleObjFormate, scheduleIid.idx) != 1) return ZCFG_INVALID_OBJECT;	
	scheduleOid = RDM_OID_SCHEDULE;


	ret = zcfgFeObjStructDel(scheduleOid, &scheduleIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_DEBUG, "%s : Delete X_ZYXEL_Schedule.%hhu Fail\n", __FUNCTION__, scheduleIid.idx[0]);
	}

	return ret;
}

