#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "lanDev_parameter.h"

extern tr98Object_t tr98Obj[];

int getNumOfBridge()
{
	objIndex_t objIid;
	int numOfBridge = 0;
	rdm_Bridging_t *bridgingObj = NULL;
	
	IID_INIT(objIid);
	zcfgFeObjStructGet(RDM_OID_BRIDGING, &objIid, (void **)&bridgingObj);
	numOfBridge = bridgingObj->BridgeNumberOfEntries;
	zcfgFeObjStructFree(bridgingObj);
	return numOfBridge;
}

bool isLowestLayerIntf(char*interfacePath, char*ethLinkPath)
{
	objIndex_t objIid;
	rdm_IfaceStack_t *ifaceStack = NULL;
	char brPath[32] = {0};
	char *ptr = NULL;

	IID_INIT(objIid);
	while(zcfgFeObjStructGetNext(RDM_OID_IFACE_STACK, &objIid, (void **)&ifaceStack) == ZCFG_SUCCESS){			
		if(strcmp(ifaceStack->HigherLayer, ethLinkPath) == 0){
			sprintf(brPath, "%s", ifaceStack->LowerLayer);			
			ptr = strstr(brPath, ".Port.1");
			*ptr = '\0';				
			zcfgFeObjStructFree(ifaceStack);
			break;
		}
		zcfgFeObjStructFree(ifaceStack);
	}

	IID_INIT(objIid);
	while(zcfgFeObjStructGetNext(RDM_OID_IFACE_STACK, &objIid, (void **)&ifaceStack) == ZCFG_SUCCESS){
		if((strcmp(ifaceStack->LowerLayer, interfacePath) == 0) && (strstr(ifaceStack->HigherLayer, brPath) !=NULL)){
			zcfgFeObjStructFree(ifaceStack);
			return true;
		}			
		zcfgFeObjStructFree(ifaceStack);
	}

	return false;
}

static zcfgRet_t ethLinkAdd(char *ethLinkPathName, char *lowerLayer)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	rdm_EthLink_t *ethLinkObj = NULL;

	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_ETH_LINK, &objIid, NULL)) != ZCFG_SUCCESS){
		return ret;
	}

	sprintf(ethLinkPathName, "Ethernet.Link.%d", objIid.idx[0]);
	
	/*Set LowerLayer for Ethernet.Link*/
	if((ret = zcfgFeObjStructGet(RDM_OID_ETH_LINK, &objIid, (void **)&ethLinkObj)) == ZCFG_SUCCESS){
		ethLinkObj->Enable= true;
		strcpy(ethLinkObj->LowerLayers, lowerLayer);
		if((ret = zcfgFeObjStructSet(RDM_OID_ETH_LINK, &objIid, (void *)ethLinkObj, NULL)) != ZCFG_SUCCESS){
			printf("Set Ethernet.Link LowerLayers Fail\n");
		}
		zcfgFeObjStructFree(ethLinkObj);
	}
	else
		return ret;
	
	return ret;	
}

/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i

    Related object in TR181:
    Device.Ethernet.Link.i
*/
zcfgRet_t lanDevObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid, ethIntfIid;
	char mappingPathName[128] = {0};
	char ethIntfPathName[32] = {0};
	rdm_IfaceStack_t *ifaceStack = NULL;
	rdm_EthIface_t *ethIntfObj = NULL;
	int numberOfEthIntf = 0;
	int numberOfWlanIntf = 0;
	int numberOfUsbIntf = 0;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
		/* mappingPathName will be Ethernet.Link.i */
		printf("TR181 object %s\n", mappingPathName);
	}
	
	IID_INIT(objIid);
	IID_INIT(ethIntfIid);
	while(zcfgFeObjStructGetNext(RDM_OID_ETH_IFACE, &ethIntfIid, (void **)&ethIntfObj) == ZCFG_SUCCESS){	
		sprintf(ethIntfPathName, "Ethernet.Interface.%d", ethIntfIid.idx[0]);	
		if(isLowestLayerIntf(ethIntfPathName, mappingPathName)){
			if(!ethIntfObj->Upstream)
				numberOfEthIntf++;
		}
		zcfgFeObjStructFree(ethIntfObj);
	}
	
	while(zcfgFeObjStructGetNext(RDM_OID_IFACE_STACK, &objIid, (void **)&ifaceStack) == ZCFG_SUCCESS){	
		/*scan of wireless lan interface number*/
		if(strstr(ifaceStack->HigherLayer, "Bridging.Bridge") != NULL){
			if (strstr(ifaceStack->LowerLayer, "WiFi.SSID") != NULL)
				numberOfWlanIntf++;
		}
		
		/*scan of usb interface number*/	
		zcfgFeObjStructFree(ifaceStack);
	}

	/*fill up tr98 LANDevice object*/
	*tr98Jobj = json_object_new_object();
	json_object_object_add(*tr98Jobj, "LANEthernetInterfaceNumberOfEntries", json_object_new_int(numberOfEthIntf));
	json_object_object_add(*tr98Jobj, "LANUSBInterfaceNumberOfEntries", json_object_new_int(numberOfUsbIntf));
	json_object_object_add(*tr98Jobj, "LANWLANConfigurationNumberOfEntries", json_object_new_int(numberOfWlanIntf));
	
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDevObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char ethLinkPathName[32] = {0};
	char lowerLayerPathName[32] = {0};
	int numOfBridge =0;
		
	numOfBridge = getNumOfBridge();	
	sprintf(lowerLayerPathName, "Bridging.Bridge.%d.Port.1", numOfBridge);

	/*add Device.Ethernet.Link.i*/
	if((ret = ethLinkAdd(ethLinkPathName, lowerLayerPathName)) != ZCFG_SUCCESS) {
		return ret;
	}
	
	*idx = numOfBridge;
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDevObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char mappingPathName[32] = {0};
	uint32_t  oid = 0;
	objIndex_t objIid;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS) {
		return ret;
	}
		
	IID_INIT(objIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	oid = zcfgFeObjNameToObjId(tr181Obj, &objIid);

	ret = zcfgFeObjJsonDel(oid, &objIid, NULL);
	if(ret == ZCFG_SUCCESS) {
		printf("Delete Object Success\n");
	}
	else {
		printf("Delete Object Fail\n");	
	}

	return ret;
}

/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement

    Related object in TR181:
    Device.Ethernet.Link.i
    Device.DHCPv4.Server
    Device.DHCPv4.Relay
    Device.DHCPv4.Server.Pool.i
    Device.IP.Interface.i
*/
zcfgRet_t lanHostConfMgmtObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char mappingPathName[128] = {0};
	char ipIntfPathName[128] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint32_t  ethLinkOid, ipIntfOid= 0;
	uint32_t  ipIntfNum = 0;
	objIndex_t ethLinkIid, ipIntfIid, dhcpServPoolIid, dhcpRelayIid, objIid;
	struct json_object *ethLinkJobj = NULL;
	struct json_object *dhcpServPoolJobj = NULL;
	struct json_object *macAddr = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	rdm_IpIface_t *ipIntfObj = NULL;
	rdm_Dhcpv4SrvPool_t *dhcpServPoolObj = NULL;
	rdm_Dhcpv4Relay_t *dhcpRelayObj = NULL;
	rdm_Dhcpv4RelayFwd_t *dhcpRelayFwdObj = NULL;
	char paramName[64] = {0};
	bool dhcpRelay = false;
	uint8_t dhcpServPoolNum = 0;
	uint8_t flag = 0;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".LANHostConfigManagement");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i */
	printf("tr98TmpName %s\n", tr98TmpName);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else{
       	/* mappingPathName will be Ethernet.Link.i */
		printf("TR181 object %s\n", mappingPathName);
       }

	/*to get value of parameter "MACAddress" of tr98 LANHostConfigManagement object*/
	IID_INIT(ethLinkIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ethLinkOid = zcfgFeObjNameToObjId(tr181Obj, &ethLinkIid);
	if((ret = zcfgFeObjJsonGet(ethLinkOid, &ethLinkIid, &ethLinkJobj)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s : No such object '.Ethernet.Link.i'\n", __FUNCTION__);
		return ret;
	}
	else	
		macAddr = json_object_object_get(ethLinkJobj, "MACAddress");
		
	IID_INIT(ipIntfIid);
	while(zcfgFeObjStructGetNext(RDM_OID_IP_IFACE, &ipIntfIid, (void **)&ipIntfObj) == ZCFG_SUCCESS){
		if (strcmp(ipIntfObj->LowerLayers, mappingPathName) == 0){
			sprintf(ipIntfPathName, "IP.Interface.%d", ipIntfIid.idx[0]);
			ipIntfNum = ipIntfObj->IPv4AddressNumberOfEntries;
			zcfgFeObjStructFree(ipIntfObj);
			break;
		}
		else
			zcfgFeObjStructFree(ipIntfObj);
	}

	if(ipIntfNum == 0){
		zcfgLog(ZCFG_LOG_ERR, "%s : No such object 'IP.Interface.i'\n", __FUNCTION__);
		return ret;
	}

	/*to get value of parameter "DHCPRelay" of tr98 LANHostConfigManagement object*/
	IID_INIT(dhcpRelayIid);
	if((ret = zcfgFeObjStructGet(RDM_OID_DHCPV4_RELAY, &dhcpRelayIid, (void **)&dhcpRelayObj)) == ZCFG_SUCCESS){
		if(dhcpRelayObj->Enable == true){
			if(zcfgFeObjStructGetNext(RDM_OID_DHCPV4_RELAY_FWD, &dhcpRelayIid, (void **)&dhcpRelayFwdObj) != ZCFG_SUCCESS){
				zcfgLog(ZCFG_LOG_ERR, "%s : No such object 'DHCPv4.Relay.Forwarding.i'\n", __FUNCTION__);
				return ret;
			}
			else{
				if (strcmp(dhcpRelayFwdObj->Interface, ipIntfPathName)==0){
					dhcpRelay = dhcpRelayFwdObj->Enable;		
					zcfgFeObjStructFree(dhcpRelayFwdObj);
				}
				else
					dhcpRelay = false;
			}	
		}
		
		zcfgFeObjStructFree(dhcpRelayObj);
	}

	/*to get value of parameter "DHCPConditionalPoolNumberOfEntries" of tr98 LANHostConfigManagement object*/
	IID_INIT(objIid);
	IID_INIT(ipIntfIid);
	IID_INIT(dhcpServPoolIid);
	while(zcfgFeObjStructGetNext(RDM_OID_DHCPV4_SRV_POOL, &objIid, (void **)&dhcpServPoolObj) == ZCFG_SUCCESS){
		sprintf(tr181Obj, "%s", dhcpServPoolObj->Interface);
		ipIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ipIntfIid);
		if((ret = zcfgFeObjStructGet(RDM_OID_IP_IFACE, &ipIntfIid, (void **)&ipIntfObj)) == ZCFG_SUCCESS) {
			if(strcmp(ipIntfObj->LowerLayers, mappingPathName)==0){
				if(flag == 0){
					dhcpServPoolNum++;
					dhcpServPoolIid = objIid;
					flag = 1;
				}
				else
					dhcpServPoolNum++;				
			}
			zcfgFeObjStructFree(ipIntfObj);
		}		
		zcfgFeObjStructFree(dhcpServPoolObj);
	}
	
	if(dhcpServPoolNum == 0){	
		zcfgLog(ZCFG_LOG_ERR, "%s : No such object 'DHCPv4.Server.Pool.i'\n", __FUNCTION__);
		return ret;
	}

	if((ret = zcfgFeObjJsonGet(RDM_OID_DHCPV4_SRV_POOL, &dhcpServPoolIid, &dhcpServPoolJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 LANHostConfigManagement object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(dhcpServPoolJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(strstr(paramList->name, "LeaseTime") != NULL){
			sprintf(paramName, "%s", "LeaseTime");
			paramValue = json_object_object_get(dhcpServPoolJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}
		
		if(strstr(paramList->name, "Enable") != NULL){
			sprintf(paramName, "%s", "Enable");
			paramValue = json_object_object_get(dhcpServPoolJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}

		if(strstr(paramList->name, "StaticAddressNumberOfEntries") != NULL){
			sprintf(paramName, "%s", "StaticAddressNumberOfEntries");
			paramValue = json_object_object_get(dhcpServPoolJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}

		if(strstr(paramList->name, "OptionNumberOfEntries") != NULL){
			sprintf(paramName, "%s", "OptionNumberOfEntries");
			paramValue = json_object_object_get(dhcpServPoolJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}
			
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	/*fill up the rest parameters*/
	json_object_object_add(*tr98Jobj, "MACAddress", JSON_OBJ_COPY(macAddr));
	json_object_object_add(*tr98Jobj, "DHCPServerConfigurable", json_object_new_boolean(true));
	json_object_object_add(*tr98Jobj, "IPInterfaceNumberOfEntries", json_object_new_int(ipIntfNum));
	json_object_object_add(*tr98Jobj, "DHCPConditionalPoolNumberOfEntries", json_object_new_int(dhcpServPoolNum-1));
	if(dhcpRelay == true)
		json_object_object_add(*tr98Jobj, "DHCPRelay", json_object_new_boolean(true));
	else
		json_object_object_add(*tr98Jobj, "DHCPRelay", json_object_new_boolean(false));
	
	json_object_put(ethLinkJobj);
	json_object_put(dhcpServPoolJobj);
	return ZCFG_SUCCESS;	
	
}

zcfgRet_t lanHostConfMgmtObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char ipIntfPathName[128] = {0};
	char higherLayerPathName[24] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	objIndex_t dhcpServPoolIid;
	struct json_object *dhcpServPoolJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	rdm_Dhcpv4SrvPool_t *dhcpServPoolObj = NULL;
	int flag = 0;


	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".LANHostConfigManagement");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i */
	printf("tr98TmpName %s\n", tr98TmpName);
	
       if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else{
       	/* mappingPathName will be Ethernet.Link.i */
		printf("TR181 object %s\n", mappingPathName);
       }

	if(zcfgFeTr181IfaceStackHigherLayerGet(mappingPathName, higherLayerPathName) == ZCFG_SUCCESS)
		sprintf(ipIntfPathName, "%s", higherLayerPathName);
	
	IID_INIT(dhcpServPoolIid);
	while(zcfgFeObjStructGetNext(RDM_OID_DHCPV4_SRV_POOL, &dhcpServPoolIid, (void **)&dhcpServPoolObj) == ZCFG_SUCCESS){
		if (strcmp(dhcpServPoolObj->Interface, ipIntfPathName) == 0){
			flag++;
			zcfgFeObjStructFree(dhcpServPoolObj);
			break;
		}
		else
			zcfgFeObjStructFree(dhcpServPoolObj);
	}	

	if(flag == 0){
		zcfgLog(ZCFG_LOG_ERR, "%s : No such object 'DHCPv4.Server.Pool.i'\n", __FUNCTION__);
		return  ZCFG_INTERNAL_ERROR;
	}

	if((ret = zcfgFeObjJsonGet(RDM_OID_DHCPV4_SRV_POOL, &dhcpServPoolIid, &dhcpServPoolJobj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = dhcpServPoolJobj;
		dhcpServPoolJobj = NULL;
		dhcpServPoolJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV4_SRV_POOL, &dhcpServPoolIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from Config to Device.DHCPv4.Server.Pool.i*/
			tr181ParamValue = json_object_object_get(dhcpServPoolJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(dhcpServPoolJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			
			/*special case*/
			if(strstr(paramList->name, "Enable") != NULL){
				json_object_object_add(dhcpServPoolJobj, "Enable", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			
			if(strstr(paramList->name, "LeaseTime") != NULL){
				json_object_object_add(dhcpServPoolJobj, "LeaseTime", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		paramList++;	
	} /*Edn while*/

	/*Set Device.DHCPv4.Server.Pool.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV4_SRV_POOL, &dhcpServPoolIid, dhcpServPoolJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv4.Server.Pool.i Fail\n", __FUNCTION__);
			json_object_put(dhcpServPoolJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.DHCPv4.Server.Pool.i Success\n", __FUNCTION__);
		}
		json_object_put(dhcpServPoolJobj);
	}
	return ZCFG_SUCCESS;
}

/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i

    Related object in TR181:
    Device.IP.Interface.i
    Device.IP.Interface.i.IPv4Address.i
*/
zcfgRet_t lanIpIntfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  ipIntfOid = 0;
	objIndex_t ipIntfIid, ipIntfv4AddrIid;
	struct json_object *ipIntfJobj = NULL;
	struct json_object *ipIntfv4AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char paramName[64] = {0};
	objIndex_t dnsSrvIid;
	struct json_object *dnsSrvJobj = NULL;
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char typeBuf[20] = {0};

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
       	/* mappingPathName will be IP.Interface.i */
		printf("TR181 object %s\n", mappingPathName);
	}

	IID_INIT(ipIntfIid);
	IID_INIT(ipIntfv4AddrIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ipIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ipIntfIid);
	if((ret = zcfgFeObjJsonGet(ipIntfOid, &ipIntfIid, &ipIntfJobj)) != ZCFG_SUCCESS)
		return ret;

	if((ret = zcfgFeSubInObjJsonGetNext(RDM_OID_IP_IFACE_V4_ADDR, &ipIntfIid, &ipIntfv4AddrIid, &ipIntfv4AddrJobj)) != ZCFG_SUCCESS)
		return ret;

	/*DNSServer*/
	IID_INIT(dnsSrvIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, &dnsSrvJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Type")));
		if(!strcmp(mappingPathName, ifBuf) && !strcmp("DHCPv6", typeBuf))
			break;
		else {
			json_object_put(dnsSrvJobj);
			dnsSrvJobj = NULL;
		}
	}


	/*fill up tr98 LANHostConfigManagement object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipIntfJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));

			paramValue = json_object_object_get(ipIntfv4AddrJobj, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(ipIntfv4AddrJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(strstr(paramList->name, "IPAddress") != NULL){
			sprintf(paramName, "%s", "IPAddress");
			paramValue = json_object_object_get(ipIntfv4AddrJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}
		
		if(strstr(paramList->name, "SubnetMask") != NULL){
			sprintf(paramName, "%s", "SubnetMask");
			paramValue = json_object_object_get(ipIntfv4AddrJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;	
			}
		}

		if(strstr(paramList->name, "AddressingType") != NULL){
			sprintf(paramName, "%s", "AddressingType");
			paramValue = json_object_object_get(ipIntfv4AddrJobj, paramName);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

#ifdef IPV6INTERFACE_PROFILE		
	if(!strcmp(paramList->name, "X_ZYXEL_IPv6Enable")) {
			paramValue = json_object_object_get(ipIntfJobj, "IPv6Enable");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Status")) {
			paramValue = json_object_object_get(ipIntfJobj, "IPv6Status");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6AddressNumberOfEntries")) {
			paramValue = json_object_object_get(ipIntfJobj, "IPv6AddressNumberOfEntries");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6PrefixNumberOfEntries")) {
			paramValue = json_object_object_get(ipIntfJobj, "IPv6PrefixNumberOfEntries");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSEnabled") == 0){
			if(dnsSrvJobj){
				paramValue = json_object_object_get(dnsSrvJobj, "Enable");
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			}
			else{	
				//json_object_object_add(*tr98Jobj, paramList->name, json_object_new_boolean(0));
			}
			paramList++;	
			continue;
		}
		else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSServers") == 0){
			if(dnsSrvJobj){
				paramValue = json_object_object_get(dnsSrvJobj, "DNSServer");
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			}
			else{
				//json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			paramList++;	
			continue;
		}

#endif

		
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}
	
	json_object_put(ipIntfJobj);
	json_object_put(ipIntfv4AddrJobj);
	if(dnsSrvJobj){
		json_object_put(dnsSrvJobj);
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t lanIpIntfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  ipIntfOid = 0;
	objIndex_t ipIntfIid, ipIntfv4AddrIid;
	struct json_object *ipIntfJobj = NULL;
	struct json_object *ipIntfv4AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	objIndex_t dnsSrvIid;
	struct json_object *dnsSrvJobj = NULL;
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char typeBuf[20] = {0};

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else {
       	/* mappingPathName will be IP.Interface.i*/
		printf("TR181 object %s\n", mappingPathName);
	}

	IID_INIT(ipIntfIid);
	IID_INIT(ipIntfv4AddrIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ipIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ipIntfIid);
	if((ret = zcfgFeObjJsonGet(ipIntfOid, &ipIntfIid, &ipIntfJobj)) != ZCFG_SUCCESS)
		return ret; 

	
	if(multiJobj){
		tmpObj = ipIntfJobj;
		ipIntfJobj = NULL;
		ipIntfJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE, &ipIntfIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
	}

	if((ret = zcfgFeSubInObjJsonGetNext(RDM_OID_IP_IFACE_V4_ADDR, &ipIntfIid, &ipIntfv4AddrIid, &ipIntfv4AddrJobj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = ipIntfv4AddrJobj;
		ipIntfv4AddrJobj = NULL;
		ipIntfv4AddrJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V4_ADDR, &ipIntfv4AddrIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
	}

	/*DNSServer*/
	IID_INIT(dnsSrvIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, &dnsSrvJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Type")));
		if(!strcmp(mappingPathName, ifBuf) && !strcmp("DHCPv6", typeBuf))
			break;
		else {
			json_object_put(dnsSrvJobj);
			dnsSrvJobj = NULL;
		}
	}

	
	if(multiJobj){
		if(dnsSrvJobj){
			tmpObj = dnsSrvJobj;
			dnsSrvJobj = NULL;
			dnsSrvJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, multiJobj, tmpObj);			
			json_object_put(tmpObj);
		}
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			/*Write value from Config to Device.DHCPv4.Server.Pool.i*/
			tr181ParamValue = json_object_object_get(ipIntfJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipIntfJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				
				tr181ParamValue = json_object_object_get(ipIntfv4AddrJobj, paramList->name);
				if(tr181ParamValue != NULL) {
					json_object_object_add(ipIntfv4AddrJobj, paramList->name, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
				
				paramList++;
				continue;
			}
			
			tr181ParamValue = json_object_object_get(ipIntfv4AddrJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipIntfv4AddrJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			
			/*special case*/
			if(strstr(paramList->name, "IPAddress") != NULL){
				json_object_object_add(ipIntfv4AddrJobj, "IPAddress", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			
			if(strstr(paramList->name, "SubnetMask") != NULL){
				json_object_object_add(ipIntfv4AddrJobj, "SubnetMask", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			
			if(strstr(paramList->name, "AddressingType") != NULL){
				json_object_object_add(ipIntfv4AddrJobj, "AddressingType", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}			
#ifdef IPV6INTERFACE_PROFILE		
			if(!strcmp(paramList->name, "X_ZYXEL_IPv6Enable")) {
				json_object_object_add(ipIntfJobj, "IPv6Enable", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSEnabled") == 0){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "Enable", JSON_OBJ_COPY(paramValue));
					paramList++;	
					continue;
				}
			}
			else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSServers") == 0){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "DNSServers", JSON_OBJ_COPY(paramValue));
					paramList++;	
					continue;
				}
			}	


#endif				
		}

		paramList++;	
	} /*Edn while*/

	/*Set Device.IP.Interface.i*/
	if(multiJobj){
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIntfIid, ipIntfJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.i Fail\n", __FUNCTION__);
			json_object_put(ipIntfJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.IP.Interface.i Success\n", __FUNCTION__);
		}

		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V4_ADDR, &ipIntfv4AddrIid, ipIntfv4AddrJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.i.IPv4Address.i Fail\n", __FUNCTION__);
			json_object_put(ipIntfv4AddrJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.IP.Interface.i.IPv4Address.i Success\n", __FUNCTION__);
		}
		json_object_put(ipIntfJobj);
		json_object_put(ipIntfv4AddrJobj);
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t lanIpIntfObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char lowerLayerPathName[32] = {0};
	char ifName[8] = {0};
	char tmpChar[4] ={0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	objIndex_t objIid;
	char *ptr = NULL;
	rdm_IpIface_t *ipIntfObj = NULL;
	uint8_t numOfInstance = 0;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".LANHostConfigManagement");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
       	/* mappingPathName will be Ethernet.Link.i */
		printf("TR181 object %s\n", mappingPathName);
	}

	/*get the bridge number*/
	zcfgFeTr181IfaceStackLowerLayerGet(mappingPathName, lowerLayerPathName);
	ptr = strstr(lowerLayerPathName, ".Port.1");
	*ptr = '\0';	
	ptr = strrchr(lowerLayerPathName, '.');
	strcpy(tmpChar, ptr+1);
	numOfInstance = atoi(tmpChar);
	sprintf(ifName, "br%d", numOfInstance-1);

	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	/*set LowerLayer for IP.Interface.i*/
	if((ret = zcfgFeObjStructGet(RDM_OID_IP_IFACE, &objIid, (void **)&ipIntfObj)) == ZCFG_SUCCESS){
		ipIntfObj->Enable = true;
		ipIntfObj->IPv4Enable = true;
		strcpy(ipIntfObj->X_ZYXEL_IfName, ifName);
		strcpy(ipIntfObj->LowerLayers, mappingPathName);
		if((ret = zcfgFeObjStructSet(RDM_OID_IP_IFACE, &objIid, (void *)ipIntfObj, NULL)) != ZCFG_SUCCESS) {
			printf("Set IP.Interface LowerLayers Fail\n");
			zcfgFeObjStructFree(ipIntfObj);
			return ret;
		}

		zcfgFeObjStructFree(ipIntfObj);
	}
	else {
		return ret;
	}

	/*add object Device.IP.Interface.i.IPv4Address.i */
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V4_ADDR, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	*idx = objIid.idx[1];
	return ZCFG_SUCCESS;	
}

zcfgRet_t lanIpIntfObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  ipIntfOid = 0;
	objIndex_t ipIntfIid;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
       	/* mappingPathName will be IP.Interface.i.IPv4Address.i */
		printf("TR181 object %s\n", mappingPathName);
	}

	IID_INIT(ipIntfIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ipIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ipIntfIid);

	ret = zcfgFeObjJsonDel(ipIntfOid, &ipIntfIid, NULL);
	if(ret == ZCFG_SUCCESS) {
		printf("Delete Object Success\n");
	}
	else {
		printf("Delete Object Fail\n");
	}

	return ret;
}


/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPStaticAddress.i

    Related object in TR181:
    Device.DHCPv4.Server.Pool.i.StaticAddress.i
*/
zcfgRet_t lanDhcpStaticAddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  staticAddrOid = 0;
	objIndex_t staticAddrIid;
	struct json_object *staticAddrJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
       	/* mappingPathName will be DHCPv4.Server.Pool.i.StaticAddress.i */
		printf("TR181 object %s\n", mappingPathName);
	}

	IID_INIT(staticAddrIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	staticAddrOid = zcfgFeObjNameToObjId(tr181Obj, &staticAddrIid);
	if((ret = zcfgFeObjJsonGet(staticAddrOid, &staticAddrIid, &staticAddrJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 DHCPStaticAddress object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(staticAddrJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(staticAddrJobj);	
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpStaticAddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  staticAddrOid = 0;
	objIndex_t staticAddrIid;
	struct json_object *staticAddrJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
       	/* mappingPathName will be DHCPv4.Server.Pool.i.StaticAddress.i */
		printf("TR181 object %s\n", mappingPathName);
	}

	IID_INIT(staticAddrIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	staticAddrOid = zcfgFeObjNameToObjId(tr181Obj, &staticAddrIid);
	if((ret = zcfgFeObjJsonGet(staticAddrOid, &staticAddrIid, &staticAddrJobj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = staticAddrJobj;
		staticAddrJobj = NULL;
		staticAddrJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV4_SRV_POOL_STATIC_ADDR, &staticAddrIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			/*Write value from Config to Device.DHCPv4.Server.Pool.i.StaticAddress.i*/
			tr181ParamValue = json_object_object_get(staticAddrJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(staticAddrJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}		
		}

		paramList++;	
	} /*Edn while*/

	/*Set Device.DHCPv4.Server.Pool.i.StaticAddress.i */
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV4_SRV_POOL_STATIC_ADDR, &staticAddrIid, staticAddrJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv4.Server.Pool.i.StaticAddress.i Fail\n", __FUNCTION__);
			json_object_put(staticAddrJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.DHCPv4.Server.Pool.i.StaticAddress.i Success\n", __FUNCTION__);
		}
		json_object_put(staticAddrJobj);
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpStaticAddrObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char mappingPathName[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	objIndex_t objIid, ipIntfIid;
	char *ptr = NULL;
	uint32_t  ipIntfOid = 0;
	rdm_IpIface_t *ipIntfObj = NULL;
	rdm_Dhcpv4SrvPool_t *dhcpServPoolObj = NULL;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".LANHostConfigManagement");
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	/*add object ' Device.DHCPv4.Server.Pool.i'*/
	IID_INIT(objIid);
	IID_INIT(ipIntfIid);
	while(zcfgFeObjStructGetNext(RDM_OID_DHCPV4_SRV_POOL, &objIid, (void **)&dhcpServPoolObj) == ZCFG_SUCCESS){
		sprintf(tr181Obj, "Device.%s", dhcpServPoolObj->Interface);
		ipIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ipIntfIid);
		if((ret = zcfgFeObjStructGet(RDM_OID_IP_IFACE, &ipIntfIid, (void **)&ipIntfObj)) == ZCFG_SUCCESS){
			if(!strcmp(ipIntfObj->LowerLayers, mappingPathName)){
				zcfgFeObjStructFree(dhcpServPoolObj);
				zcfgFeObjStructFree(ipIntfObj);
				break;
			}
			else
				zcfgFeObjStructFree(ipIntfObj);
		}		
		zcfgFeObjStructFree(dhcpServPoolObj);
	}

	/*add object ' Device.DHCPv4.Server.Pool.i.StaticAddress.i '*/
	if((ret = zcfgFeObjStructAdd(RDM_OID_DHCPV4_SRV_POOL_STATIC_ADDR, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}

	*idx = objIid.idx[1];
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpStaticAddrObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  staticAddrOid = 0;
	objIndex_t staticAddrIid;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}
	else{
       	/* mappingPathName will be DHCPv4.Server.Pool.i.StaticAddress.i */
		printf("TR181 object %s\n", mappingPathName);
	}

	IID_INIT(staticAddrIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	staticAddrOid = zcfgFeObjNameToObjId(tr181Obj, &staticAddrIid);

	ret = zcfgFeObjJsonDel(staticAddrOid, &staticAddrIid, NULL);
	if(ret == ZCFG_SUCCESS) {
		printf("Delete Object Success\n");
	}
	else {
		printf("Delete Object Fail\n");
	}

	return ret;
}


/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPOption.i

    Related object in TR181:
    Device.DHCPv4.Server.Pool.i.Option.i
*/
zcfgRet_t lanDhcpOptObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  dhcpOptOid = 0;
	objIndex_t dhcpOptIid;
	struct json_object *dhcpOptJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	IID_INIT(dhcpOptIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	dhcpOptOid = zcfgFeObjNameToObjId(tr181Obj, &dhcpOptIid);
	if((ret = zcfgFeObjJsonGet(dhcpOptOid, &dhcpOptIid, &dhcpOptJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 DHCPOption.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(dhcpOptJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(dhcpOptJobj);	
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpOptObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  dhcpOptOid = 0;
	objIndex_t dhcpOptIid;
	struct json_object *dhcpOptJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	IID_INIT(dhcpOptIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	dhcpOptOid = zcfgFeObjNameToObjId(tr181Obj, &dhcpOptIid);
	if((ret = zcfgFeObjJsonGet(dhcpOptOid, &dhcpOptIid, &dhcpOptJobj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = dhcpOptJobj;
		dhcpOptJobj = NULL;
		dhcpOptJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV4_SRV_POOL_OPT, &dhcpOptIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			/*Write value from Config to Device.DHCPv4.Server.Pool.i.Option.i*/
			tr181ParamValue = json_object_object_get(dhcpOptJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(dhcpOptJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}		
		}

		paramList++;	
	} /*Edn while*/

	/*Set DHCPv4.Server.Pool.i.Option.i */
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV4_SRV_POOL_OPT, &dhcpOptIid, dhcpOptJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv4.Server.Pool.i.StaticAddress.i Fail\n", __FUNCTION__);
			json_object_put(dhcpOptJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.DHCPv4.Server.Pool.i.StaticAddress.i Success\n", __FUNCTION__);
		}
		json_object_put(dhcpOptJobj);
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpOptObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t objIid, ipIntfIid;
	char *ptr = NULL;
	uint32_t  ipIntfOid = 0;
	rdm_IpIface_t *ipIntfObj = NULL;
	rdm_Dhcpv4SrvPool_t *dhcpServPoolObj = NULL;
	rdm_Dhcpv4SrvPoolOpt_t *dhcpOptObj = NULL;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".LANHostConfigManagement");
	*ptr = '\0';

	/*add object ' Device.DHCPv4.Server.Pool.i '*/
	IID_INIT(objIid);
	IID_INIT(ipIntfIid);
	while(zcfgFeObjStructGetNext(RDM_OID_DHCPV4_SRV_POOL, &objIid, (void **)&dhcpServPoolObj) == ZCFG_SUCCESS){
		sprintf(tr181Obj, "Device.%s", dhcpServPoolObj->Interface);
		ipIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ipIntfIid);
		if((ret = zcfgFeObjStructGet(RDM_OID_IP_IFACE, &ipIntfIid, (void **)&ipIntfObj)) == ZCFG_SUCCESS) {
			if(!strcmp(ipIntfObj->LowerLayers, tr98TmpName)){
				zcfgFeObjStructFree(dhcpServPoolObj);
				zcfgFeObjStructFree(ipIntfObj);
				break;
			}
			else
				zcfgFeObjStructFree(ipIntfObj);
		}		
		zcfgFeObjStructFree(dhcpServPoolObj);
	}

	/*add object ' Device.DHCPv4.Server.Pool.i.Option.i '*/
	if((ret = zcfgFeObjStructAdd(RDM_OID_DHCPV4_SRV_POOL_OPT, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	if((ret = zcfgFeObjStructGet(RDM_OID_DHCPV4_SRV_POOL_OPT, &objIid, (void **)&dhcpOptObj)) == ZCFG_SUCCESS){
		dhcpOptObj->Enable = true;
	
		if((ret = zcfgFeObjStructSet(RDM_OID_DHCPV4_SRV_POOL_OPT, &objIid, (void *)dhcpOptObj, NULL)) != ZCFG_SUCCESS) {
				printf("Set dhcpCondServPoolStaticAddrObj Fail\n");
				zcfgFeObjStructFree(dhcpOptObj);
				return ret;
		}

		zcfgFeObjStructFree(dhcpOptObj);
	}
	else{
		printf("Get LANDevice Fail!!\n");
		return ret;
	}
	
	*idx = objIid.idx[1];
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpOptObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  dhcpOptOid = 0;
	objIndex_t dhcpOptIid;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	IID_INIT(dhcpOptIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	dhcpOptOid = zcfgFeObjNameToObjId(tr181Obj, &dhcpOptIid);

	ret = zcfgFeObjJsonDel(dhcpOptOid, &dhcpOptIid, NULL);
	if(ret == ZCFG_SUCCESS) {
		printf("Delete Object Success\n");
	}
	else {
		printf("Delete Object Fail\n");	
	}

	return ret;
}

#if 0
/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i

    Related object in TR181:
    Device.DHCPv4.Server.Pool.i
*/
zcfgRet_t lanDhcpCondServPoolObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{

	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{

	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t objIid;
	char *ptr = NULL;
	rdm_Dhcpv4SrvPool_t *dhcpCondServPoolObj = NULL;

       printf("Enter %s\n", __FUNCTION__);
        
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".LANHostConfigManagement");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i */
	printf("tr98TmpName %s\n", tr98TmpName);


	//X_ZYXEL_LanDeviceInterface is no longer in use
	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_DHCPV4_SRV_POOL, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	if((ret = zcfgFeObjStructGet(RDM_OID_DHCPV4_SRV_POOL, &objIid, (void **)&dhcpCondServPoolObj)) == ZCFG_SUCCESS){
		sprintf(dhcpCondServPoolObj->X_ZYXEL_LanDeviceInterface,"%s",tr98TmpName);
	
		if((ret = zcfgFeObjStructSet(RDM_OID_DHCPV4_SRV_POOL, &objIid, (void *)dhcpCondServPoolObj, NULL)) != ZCFG_SUCCESS) {
				printf("Set DHCPConditionalServingPool Fail\n");
				zcfgFeObjStructFree(dhcpCondServPoolObj);
				return ret;
		}

		zcfgFeObjStructFree(dhcpCondServPoolObj);
	}
	else{
		printf("Get LANDevice Fail!!\n");
		return ret;
	}

	*idx = objIid.idx[0];
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolObjDel(char *tr98FullPathName)
{

	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i.DHCPStaticAddress.i

    Related object in TR181:
    Device.DHCPv4.Server.Pool.i.StaticAddress.i
*/
zcfgRet_t lanDhcpCondServPoolStaticAddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{

	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolStaticAddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{

	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolStaticAddrObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	objIndex_t objIid;
	uint32_t  oid = 0;
	char *ptr = NULL;

       printf("Enter %s\n", __FUNCTION__);
        
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".DHCPStaticAddress");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i */
	printf("tr98TmpName %s\n", tr98TmpName);
		        
       if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else{
		/* mappingPathName will be DHCPv4.Server.Pool.i */
		printf("TR181 object %s\n", mappingPathName);
       }

	sprintf(tr181Obj, "Device.%s", mappingPathName);
	IID_INIT(objIid);
	oid = zcfgFeObjNameToObjId(tr181Obj, &objIid);
	if((ret = zcfgFeObjStructAdd(oid, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	*idx = objIid.idx[1];
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolStaticAddrObjDel(char *tr98FullPathName)
{

	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i.DHCPOption.i

    Related object in TR181:
    Device.DHCPv4.Server.Pool.i.Option.i
*/
zcfgRet_t lanDhcpCondServPoolOptObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{

	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolOptObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{

	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolOptObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	objIndex_t objIid;
	uint32_t  oid = 0;
	char *ptr = NULL;

       printf("Enter %s\n", __FUNCTION__);
        
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".DHCPOption");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.DHCPConditionalServingPool.i */
	printf("tr98TmpName %s\n", tr98TmpName);
		        
       if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
       }
	else{
		/* mappingPathName will be DHCPv4.Server.Pool.i */
		printf("TR181 object %s\n", mappingPathName);
       }

	sprintf(tr181Obj, "Device.%s", mappingPathName);
	IID_INIT(objIid);
	oid = zcfgFeObjNameToObjId(tr181Obj, &objIid);
	if((ret = zcfgFeObjStructAdd(oid, &objIid, NULL)) != ZCFG_SUCCESS){
		printf("Add Instance Fail!!\n");
		return ret;
	}
	
	*idx = objIid.idx[1];
	return ZCFG_SUCCESS;
}

zcfgRet_t lanDhcpCondServPoolOptObjDel(char *tr98FullPathName)
{

	return ZCFG_SUCCESS;
}
#endif

/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANEthernetInterfaceConfig.i

    Related object in TR181:
    Device.Ethernet.Interface.i
*/
extern zcfgRet_t lanEthIntfConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  ethIntfOid = 0;
	objIndex_t ethIntfIid;
	struct json_object *ethIntfJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	
	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	IID_INIT(ethIntfIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ethIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ethIntfIid);
	if((ret = zcfgFeObjJsonGet(ethIntfOid, &ethIntfIid, &ethIntfJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 LANEthernetInterfaceConfig object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ethIntfJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(ethIntfJobj);	
	return ZCFG_SUCCESS;
}

extern zcfgRet_t lanEthIntfConfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr181Obj[128] = {0};
	uint32_t  ethIntfOid = 0;
	objIndex_t ethIntfIid;
	struct json_object *ethIntfJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	IID_INIT(ethIntfIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ethIntfOid = zcfgFeObjNameToObjId(tr181Obj, &ethIntfIid);
	if((ret = zcfgFeObjJsonGet(ethIntfOid, &ethIntfIid, &ethIntfJobj)) != ZCFG_SUCCESS)
		return ret;
	if(multiJobj){
		tmpObj = ethIntfJobj;
		ethIntfJobj = NULL;
		ethIntfJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ETH_IFACE, &ethIntfIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		printf("Parameter Name %s\n", paramList->name);
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL){
			/*Write value from Config to Device.Ethernet.Interface.i*/
			tr181ParamValue = json_object_object_get(ethIntfJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ethIntfJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}		
		}

		paramList++;	
	} /*Edn while*/

	/*Set Device.Ethernet.Interface.i */
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_ETH_IFACE, &ethIntfIid, ethIntfJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.Ethernet.Interface.i Fail\n", __FUNCTION__);
			json_object_put(ethIntfJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.Ethernet.Interface.i Success\n", __FUNCTION__);
		}
		json_object_put(ethIntfJobj);
	}
	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANEthernetInterfaceConfig.i.Stats

    Related object in TR181:
    Device.Ethernet.Interface.i.Stats
*/
extern zcfgRet_t lanEthIntfConfStatObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char mappingPathName[128] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr181Obj[128] = {0};
	uint32_t  ethIntfStatOid = 0;
	objIndex_t ethIntfStatIid;
	struct json_object *ethIntfStatJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".Stats");
	*ptr = '\0';
	
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, mappingPathName)) != ZCFG_SUCCESS){
		printf("98 to 181 Mapping Fail!!\n");
		return ret;
	}

	IID_INIT(ethIntfStatIid);
	sprintf(tr181Obj, "Device.%s", mappingPathName);
	ethIntfStatOid = zcfgFeObjNameToObjId(tr181Obj, &ethIntfStatIid);
	if((ret = zcfgFeObjJsonGet(ethIntfStatOid, &ethIntfStatIid, &ethIntfStatJobj)) != ZCFG_SUCCESS)
		return ret;
	
	/*fill up tr98 LANEthernetInterfaceConfig.i.Stats object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ethIntfStatJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(ethIntfStatJobj);	
	return ZCFG_SUCCESS;
}
/*   TR98 Object Name : InternetGatewayDevice.LANDevice.i.WLANConfiguration.i
 *
 *   Related object in TR181:
 *
 *   Device.WiFi.Radio.i
 *   Device.WiFi.SSID.i
 *   Device.WiFi.AccessPoint.i
 *   Device.WiFi.AccessPoint.i.Security
 */
zcfgRet_t lanDevWlanCfgObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char wifiSsid[32] = {0};
	char wifiRadio[32] = {0};
	char ssidRef[32] = {0};
	objIndex_t ssidIid, radioIid, apIid;
	struct json_object *radioJobj = NULL;
	struct json_object *ssidJobj = NULL;
	struct json_object *apJobj = NULL;
	struct json_object *apSecJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, wifiSsid) != ZCFG_SUCCESS) {
		/*  The instance number of WLANConfiguration.i will be continuous because of the tr98 to tr181 mapping table. 
		 *  Therefore, just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WLANConfiguration object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}

	/*mapping InternetGatewayDevice.LANDevice.1.WLANConfiguration.i to Device.WiFi.SSID.i*/
	IID_INIT(ssidIid);
	ssidIid.level = 1;
	sscanf(wifiSsid, "WiFi.SSID.%hhu", &ssidIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_SSID, &ssidIid, &ssidJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.SSID Fail\n", __FUNCTION__);
		return ret;
	}

	strcpy(wifiRadio, json_object_get_string(json_object_object_get(ssidJobj, "LowerLayers")));
	IID_INIT(radioIid);
	radioIid.level = 1;
	sscanf(wifiRadio, "WiFi.Radio.%hhu", &radioIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_RADIO, &radioIid, &radioJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.Radio Fail\n", __FUNCTION__);
		json_object_put(ssidJobj);
		return ret;
	}

	IID_INIT(apIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_WIFI_ACCESS_POINT, &apIid, &apJobj)) == ZCFG_SUCCESS) {
		strcpy(ssidRef, json_object_get_string(json_object_object_get(apJobj, "SSIDReference")));
		if(!strcmp(ssidRef, wifiSsid))
			break;
		else
			json_object_put(apJobj);
	}

	if(apJobj == NULL) {
		apJobj = json_object_new_object();
		apSecJobj = json_object_new_object();
	}
	else {
		if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, &apSecJobj)) != ZCFG_SUCCESS) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);
			json_object_put(radioJobj);
			json_object_put(ssidJobj);
			json_object_put(apJobj);
			return ret;
		}		
	}

	/*fill up tr98 LANEthernetInterfaceConfig object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ssidJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(radioJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(apJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(apSecJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(!strcmp(paramList->name, "RadioEnabled")) {
			paramValue = json_object_object_get(radioJobj, "Enable");
		}
		else if(!strcmp(paramList->name, "PeerBSSID")) {
			paramValue = json_object_new_string("");
		}
		else if(!strcmp(paramList->name, "WMMSupported")) {
			paramValue = json_object_object_get(apJobj, "WMMCapability");
		}
		else if(!strcmp(paramList->name, "UAPSDSupported")) {
			paramValue = json_object_object_get(apJobj, "UAPSDCapability");
		}
		else if(!strcmp(paramList->name, "LocationDescription")) {
			paramValue = json_object_new_string("");
		}
		else if(!strcmp(paramList->name, "MACAddressControlEnabled")) {
			paramValue = json_object_new_boolean(false);
		}
		else if(!strcmp(paramList->name, "Standard")) {
			paramValue = json_object_object_get(radioJobj, "SupportedStandards");
		}
		else if(!strcmp(paramList->name, "WEPKeyIndex")) {
			paramValue = json_object_new_int(1);
		}
		else if(!strcmp(paramList->name, "WPAEncryptionModes") || !strcmp(paramList->name, "IEEE11iEncryptionModes")) {
			paramValue = json_object_new_string("TKIPandAESEncryption");
		}
		else if(!strcmp(paramList->name, "WPAAuthenticationMode")) {
			paramValue = json_object_object_get(apSecJobj, "ModeEnabled");
			if(paramValue != NULL) {
				if(!strcmp(json_object_get_string(paramValue), "WPA-Personal") 
					|| !strcmp(json_object_get_string(paramValue), "WPA-WPA2-Personal") ) {
					paramValue = json_object_new_string("PSKAuthentication");
				}	
				else if(!strcmp(json_object_get_string(paramValue), "WPA-Enterprise")
					|| !strcmp(json_object_get_string(paramValue), "WPA-WPA2-Enterprise")){
					paramValue = json_object_new_string("EAPAuthentication");
				}
				else {
					paramValue = json_object_new_string("");
				}
			}
		}
		else if(!strcmp(paramList->name, "IEEE11iAuthenticationMode")) {
			paramValue = json_object_object_get(apSecJobj, "ModeEnabled");
			if(paramValue != NULL) {
				if(!strcmp(json_object_get_string(paramValue), "WPA2-Personal") 
					|| !strcmp(json_object_get_string(paramValue), "WPA-WPA2-Personal") ) {
					paramValue = json_object_new_string("PSKAuthentication");
				}	
				else if(!strcmp(json_object_get_string(paramValue), "WPA2-Enterprise")
					|| !strcmp(json_object_get_string(paramValue), "WPA-WPA2-Enterprise")){
					paramValue = json_object_new_string("EAPAuthentication");
				}
				else {
					paramValue = json_object_new_string("");
				}
			}
		}
		else if(!strcmp(paramList->name, "BeaconType")) {
			paramValue = json_object_object_get(apSecJobj, "ModeEnabled");
			if(paramValue != NULL) {
				if(strstr(json_object_get_string(paramValue), "WPA-WPA2") != NULL) {
					paramValue = json_object_new_string("WPAand11i");
				}				
				else if(strstr(json_object_get_string(paramValue), "WPA2") != NULL) {
					paramValue = json_object_new_string("11i");
				}
				else if(strstr(json_object_get_string(paramValue), "WPA") != NULL) {
					paramValue = json_object_new_string("WPA");
				}
				else {
					paramValue = json_object_new_string("Basic");
				}
			}
		}
		else if(!strcmp(paramList->name, "BasicEncryptionModes")) {
			paramValue = json_object_object_get(apSecJobj, "ModeEnabled");
			if(!strcmp(json_object_get_string(paramValue), "WEP-64") || !strcmp(json_object_get_string(paramValue), "WEP-128")) {
				paramValue = json_object_new_string("WEPEncryption");
			}
			else {
				paramValue = json_object_new_string("None");
			}
		}
		else if(!strcmp(paramList->name, "WEPEncryptionLevel")) {
			char wepEncryp[32] = {0};

			paramValue = json_object_object_get(apSecJobj, "ModesSupported");
			if(strstr(json_object_get_string(paramValue), "WEP-64") != NULL) {
				strcat(wepEncryp, "40-bit");
			}

			if(strstr(json_object_get_string(paramValue), "WEP-128") != NULL) {
				if(strlen(wepEncryp) != 0)
					strcat(wepEncryp, ",");

				strcat(wepEncryp, "104-bit");
			}

			paramValue = json_object_new_string(wepEncryp);
		}

		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		paramValue = NULL;
		/*End of special case*/

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(radioJobj);
	json_object_put(ssidJobj);	
	json_object_put(apJobj);
	json_object_put(apSecJobj);

	return ZCFG_SUCCESS;
}

static void wifiSecuritySet(struct json_object *apSecJobj, struct json_object *tr98Jobj, struct json_object *beaconType, int wepKeyLen)
{
	char type[12] = {0};
	struct json_object *tr98ParamValue = NULL;

	strcpy(type, json_object_get_string(beaconType));

	if(!strcmp(type, "Basic")) {
		tr98ParamValue = json_object_object_get(tr98Jobj, "BasicEncryptionModes");
		if(!strcmp(json_object_get_string(tr98ParamValue), "None")) {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("None")));
		}
		else {
			if(wepKeyLen == 5 || wepKeyLen == 10)
				json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WEP-64")));
			else if(wepKeyLen == 0 || wepKeyLen == 13 || wepKeyLen == 26)
				json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WEP-128")));
		}
	}
	else if(!strcmp(type, "WPA")) {
		tr98ParamValue = json_object_object_get(tr98Jobj, "WPAAuthenticationMode");

		if(!strcmp(json_object_get_string(tr98ParamValue), "EAPAuthentication")) {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WPA-Enterprise")));
		}
		else {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WPA-Personal")));
		}
	}
	else if(!strcmp(type, "11i")) {
		tr98ParamValue = json_object_object_get(tr98Jobj, "IEEE11iAuthenticationMode");

		if(!strcmp(json_object_get_string(tr98ParamValue), "EAPAuthentication")) {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WPA2-Enterprise")));
		}
		else {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WPA2-Personal")));
		}
	}
	else if(!strcmp(type, "WPAand11i")) {
		tr98ParamValue = json_object_object_get(tr98Jobj, "IEEE11iAuthenticationMode");

		if(!strcmp(json_object_get_string(tr98ParamValue), "EAPAuthentication")) {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WPA-WPA2-Enterprise")));
		}
		else {
			json_object_object_add(apSecJobj, "ModeEnabled", JSON_OBJ_COPY(json_object_new_string("WPA-WPA2-Personal")));
		}				
	}	
}
/*   TR98 Object Name : InternetGatewayDevice.LANDevice.i.WLANConfiguration.i
 *
 *   Related object in TR181:
 *
 *   Device.WiFi.Radio.i
 *   Device.WiFi.SSID.i
 *   Device.WiFi.AccessPoint.i
 *   Device.WiFi.AccessPoint.i.Security
 */
zcfgRet_t lanDevWlanCfgObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	char wifiSsid[32] = {0};
	char wifiRadio[32] = {0};
	char ssidRef[32] = {0};
	objIndex_t ssidIid, radioIid, apIid;
	struct json_object *radioJobj = NULL;
	struct json_object *ssidJobj = NULL, *ssidJobjBak = NULL;
	struct json_object *apJobj = NULL, *apJobjBak = NULL;
	struct json_object *apSecJobj = NULL, *apSecJobjBak = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tr98ParamValue = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	int wepKeyLen = 0;
	struct json_object *wepKey = NULL;

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, wifiSsid) != ZCFG_SUCCESS) {
		/*  The instance number of WLANConfiguration.i will be continuous because of the tr98 to tr181 mapping table. 
		 *  Therefore, just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WLANConfiguration object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}

	/*mapping InternetGatewayDevice.LANDevice.1.WLANConfiguration.i to Device.WiFi.SSID.i*/
	IID_INIT(ssidIid);
	ssidIid.level = 1;
	sscanf(wifiSsid, "WiFi.SSID.%hhu", &ssidIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_SSID, &ssidIid, &ssidJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.SSID Fail\n", __FUNCTION__);
		return ret;
	}

	strcpy(wifiRadio, json_object_get_string(json_object_object_get(ssidJobj, "LowerLayers")));
	IID_INIT(radioIid);
	radioIid.level = 1;
	sscanf(wifiRadio, "WiFi.Radio.%hhu", &radioIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_RADIO, &radioIid, &radioJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.Radio Fail\n", __FUNCTION__);
		json_object_put(ssidJobj);
		return ret;
	}

	IID_INIT(apIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_WIFI_ACCESS_POINT, &apIid, &apJobj)) == ZCFG_SUCCESS) {
		strcpy(ssidRef, json_object_get_string(json_object_object_get(apJobj, "SSIDReference")));
		if(!strcmp(ssidRef, wifiSsid))
			break;
		else {
			json_object_put(apJobj);
			apJobj = NULL;
		}
	}

	if(ret == ZCFG_NO_MORE_INSTANCE)
		apJobj = NULL;

	if(apJobj != NULL) {
		if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, &apSecJobj)) != ZCFG_SUCCESS) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);
			json_object_put(radioJobj);
			json_object_put(ssidJobj);
			json_object_put(apJobj);
			return ret;
		}

		/*Backup for recover*/
		apJobjBak = json_tokener_parse(json_object_to_json_string(apJobj));
		apSecJobjBak = json_tokener_parse(json_object_to_json_string(apSecJobj));

		wepKey = json_object_object_get(apSecJobj, "WEPKey");
		wepKeyLen = strlen(json_object_get_string(wepKey));		
	}

	if(multiJobj){
		tmpObj = radioJobj;
		radioJobj = NULL;
		radioJobj = zcfgFeJsonMultiObjAppend(RDM_OID_WIFI_RADIO, &radioIid, multiJobj, tmpObj);
		json_object_put(tmpObj);

		tmpObj = ssidJobj;
		ssidJobj = NULL;
		ssidJobj = zcfgFeJsonMultiObjAppend(RDM_OID_WIFI_SSID, &ssidIid, multiJobj, tmpObj);
		json_object_put(tmpObj);

		if(apJobj != NULL) {
			tmpObj = apJobj;
			apJobj = NULL;
			apJobj = zcfgFeJsonMultiObjAppend(RDM_OID_WIFI_ACCESS_POINT, &apIid, multiJobj, tmpObj);
			json_object_put(tmpObj);

			tmpObj = apSecJobj;
			apSecJobj = NULL;
			apSecJobj = zcfgFeJsonMultiObjAppend(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, multiJobj, tmpObj);
			json_object_put(tmpObj);
		}
	}

	/*Backup for recover*/
	ssidJobjBak = json_tokener_parse(json_object_to_json_string(ssidJobj));

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(ssidJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ssidJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(radioJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(radioJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		if(apJobj != NULL) {
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				tr181ParamValue = json_object_object_get(apJobj, paramList->name);
				if(tr181ParamValue != NULL) {
					json_object_object_add(apJobj, paramList->name, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}

			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				tr181ParamValue = json_object_object_get(apSecJobj, paramList->name);
				if(tr181ParamValue != NULL) {
					json_object_object_add(apSecJobj, paramList->name, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}

			/*special case*/
			if(!strcmp(paramList->name, "BeaconType")) {
				tr98ParamValue = json_object_object_get(tr98Jobj, paramList->name);
				wifiSecuritySet(apSecJobj, tr98Jobj, tr98ParamValue, wepKeyLen);
			}
			/*End of special case*/
		}

		paramList++;
	} /*Edn while*/

	/* Set Device.WiFi.Radio.i
	 *     Device.WiFi.SSID.i
	 *     Device.WiFi.AccessPoint.i
	 *     Device.WiFi.AccessPoint.i.Security
	 */
	if(multiJobj == NULL){
		if((ret = zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT, &apIid, apJobj, NULL)) != ZCFG_SUCCESS ) {
			goto finish;
		}

		if((ret = zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, apSecJobj, NULL)) != ZCFG_SUCCESS ) {
			if(zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT, &apIid, apJobjBak, NULL) != ZCFG_SUCCESS)
				zcfgLog(ZCFG_LOG_ERR, "%s : Recover WiFi.AccessPoint.i Fail\n", __FUNCTION__);
			goto finish;
		}
		
		if((ret = zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_SSID, &ssidIid, ssidJobj, NULL)) != ZCFG_SUCCESS ) {

			if(zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT, &apIid, apJobjBak, NULL) != ZCFG_SUCCESS)
				zcfgLog(ZCFG_LOG_ERR, "%s : Recover WiFi.AccessPoint.i Fail\n", __FUNCTION__);

			if(zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, apSecJobjBak, NULL) != ZCFG_SUCCESS)
				zcfgLog(ZCFG_LOG_ERR, "%s : Recover WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);
						
			goto finish;
		}

		if((ret = zcfgFeObjJsonSet(RDM_OID_WIFI_RADIO, &radioIid, radioJobj, NULL)) != ZCFG_SUCCESS ) {

			if(zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT, &apIid, apJobjBak, NULL) != ZCFG_SUCCESS)
				zcfgLog(ZCFG_LOG_ERR, "%s : Recover WiFi.AccessPoint.i Fail\n", __FUNCTION__);

			if(zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, apSecJobjBak, NULL) != ZCFG_SUCCESS)
				zcfgLog(ZCFG_LOG_ERR, "%s : Recover WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);

			if(zcfgFeObjJsonSetWithoutApply(RDM_OID_WIFI_SSID, &ssidIid, ssidJobjBak, NULL) != ZCFG_SUCCESS)
				zcfgLog(ZCFG_LOG_ERR, "%s : Recover WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);

			goto finish;
		}
	}

finish:
	if(multiJobj == NULL){
		json_object_put(radioJobj);
		json_object_put(ssidJobj);
		json_object_put(apJobj);
		json_object_put(apSecJobj);
		json_object_put(ssidJobjBak);
		json_object_put(apJobjBak);
		json_object_put(apSecJobjBak);
	}

	return ret;
}
/*   TR98 Object Name : InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.WPS
 *
 *   Related object in TR181:
 *
 *   Device.WiFi.AccessPoint.i.WPS
 */
zcfgRet_t lanDevWlanCfgWpsObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char wifiSsid[32] = {0};
	char ssidRef[32] = {0};
	objIndex_t apIid;
	struct json_object *apJobj = NULL, *apWpsJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WPS");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i.WLANConfiguration.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wifiSsid)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(apIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_WIFI_ACCESS_POINT, &apIid, &apJobj)) == ZCFG_SUCCESS) {
		strcpy(ssidRef, json_object_get_string(json_object_object_get(apJobj, "SSIDReference")));
		if(!strcmp(ssidRef, wifiSsid))
			break;
		else {
			json_object_put(apJobj);
			apJobj = NULL;
		}
	}

	if(ret == ZCFG_NO_MORE_INSTANCE)
		return ret;

	if(apJobj != NULL) {
		if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_ACCESS_POINT_WPS, &apIid, &apWpsJobj)) != ZCFG_SUCCESS) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.AccessPoint.i.WPS Fail\n", __FUNCTION__);
			json_object_put(apJobj);
			return ret;
		}
		json_object_put(apJobj);
	}

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(apWpsJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		if(!strcmp(paramList->name, "UUID")) {
			paramValue = json_object_object_get(apWpsJobj, "X_ZYXEL_WPS_UUID");
		}
		else if(!strcmp(paramList->name, "DevicePassword")) {
			paramValue = json_object_object_get(apWpsJobj, "X_ZYXEL_WPS_DevicePin");
		}

		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(apWpsJobj);

	return ZCFG_SUCCESS;
}
/*   TR98 Object Name : InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.WPS
 *
 *   Related object in TR181:
 *
 *   Device.WiFi.AccessPoint.i.WPS
 */
zcfgRet_t lanDevWlanCfgWpsObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char wifiSsid[32] = {0};
	char ssidRef[32] = {0};
	objIndex_t apIid;
	struct json_object *apJobj = NULL, *apWpsJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;	

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".PreSharedKey");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i.WLANConfiguration.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wifiSsid)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(apIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_WIFI_ACCESS_POINT, &apIid, &apJobj)) == ZCFG_SUCCESS) {
		strcpy(ssidRef, json_object_get_string(json_object_object_get(apJobj, "SSIDReference")));
		if(!strcmp(ssidRef, wifiSsid))
			break;
		else {
			json_object_put(apJobj);
			apJobj = NULL;
		}
	}

	if(ret == ZCFG_NO_MORE_INSTANCE)
		return ret;

	if(apJobj != NULL) {
		if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_ACCESS_POINT_WPS, &apIid, &apWpsJobj)) != ZCFG_SUCCESS) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);
			json_object_put(apJobj);
			return ret;
		}
		json_object_put(apJobj);		
	}

	if(multiJobj){
		tmpObj = apWpsJobj;
		apWpsJobj = NULL;
		apWpsJobj = zcfgFeJsonMultiObjAppend(RDM_OID_WIFI_ACCESS_POINT_WPS, &apIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(apWpsJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(apWpsJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;	
	}

	/*Set Device.WiFi.AccessPoint.i.Security*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_WIFI_ACCESS_POINT_WPS, &apIid, apWpsJobj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(apWpsJobj);
			return ret;
		}

		json_object_put(apWpsJobj);
	}

	return ZCFG_SUCCESS;
}
/*   TR98 Object Name : InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.PreSharedKey.i
 *
 *   Related object in TR181:
 *
 *   WiFi.AccessPoint.i.Security
 */
zcfgRet_t lanDevWlanCfgPskObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	int idx = 0;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char wifiSsid[32] = {0};
	char ssidRef[32] = {0};
	objIndex_t apIid;
	struct json_object *apJobj = NULL, *apSecJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;	

	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.PreSharedKey.%d", &idx);

	/*There should be only one PreSharedKey Object*/
	if(idx > 1)
		return ZCFG_NO_MORE_INSTANCE;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".PreSharedKey");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i.WLANConfiguration.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wifiSsid)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(apIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_WIFI_ACCESS_POINT, &apIid, &apJobj)) == ZCFG_SUCCESS) {
		strcpy(ssidRef, json_object_get_string(json_object_object_get(apJobj, "SSIDReference")));
		if(!strcmp(ssidRef, wifiSsid))
			break;
		else {
			json_object_put(apJobj);
			apJobj = NULL;
		}
	}

	if(ret == ZCFG_NO_MORE_INSTANCE)
		return ret;

	if(apJobj != NULL) {
		if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, &apSecJobj)) != ZCFG_SUCCESS) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);
			json_object_put(apJobj);
			return ret;
		}
		json_object_put(apJobj);
	}

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(apSecJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(json_object_new_string("")));

		paramList++;
	}

	json_object_put(apSecJobj);

	return ZCFG_SUCCESS;
}
/*   TR98 Object Name : InternetGatewayDevice.LANDevice.i.WLANConfiguration.i.PreSharedKey.i
 *
 *   Related object in TR181:
 *
 *   WiFi.AccessPoint.i.Security
 */
zcfgRet_t lanDevWlanCfgPskObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	int idx = 0;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char wifiSsid[32] = {0};
	char ssidRef[32] = {0};
	objIndex_t apIid;
	struct json_object *apJobj = NULL, *apSecJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;	

	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.PreSharedKey.%d", &idx);

	/*There should be only one PreSharedKey Object*/
	if(idx > 1)
		return ZCFG_NO_MORE_INSTANCE;

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".PreSharedKey");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.LANDevice.i.WLANConfiguration.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wifiSsid)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(apIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_WIFI_ACCESS_POINT, &apIid, &apJobj)) == ZCFG_SUCCESS) {
		strcpy(ssidRef, json_object_get_string(json_object_object_get(apJobj, "SSIDReference")));
		if(!strcmp(ssidRef, wifiSsid))
			break;
		else {
			json_object_put(apJobj);
			apJobj = NULL;
		}
	}

	if(ret == ZCFG_NO_MORE_INSTANCE)
		return ret;

	if(apJobj != NULL) {
		if((ret = zcfgFeObjJsonGet(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, &apSecJobj)) != ZCFG_SUCCESS) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Get WiFi.AccessPoint.i.Security Fail\n", __FUNCTION__);
			json_object_put(apJobj);
			return ret;
		}
		json_object_put(apJobj);		
	}

	if(multiJobj){
		tmpObj = apSecJobj;
		apSecJobj = NULL;
		apSecJobj = zcfgFeJsonMultiObjAppend(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(apSecJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(apSecJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;	
	}

	/*Set Device.WiFi.AccessPoint.i.Security*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_WIFI_ACCESS_POINT_SEC, &apIid, apSecJobj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(apSecJobj);
			return ret;
		}

		json_object_put(apSecJobj);
	}

	return ZCFG_SUCCESS;
}


/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t lanIpIntfV6AddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6AddrIid;
	struct json_object *ipv6AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);

	*ptr = '\0';
	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*	The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *	just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *	this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	IID_INIT(ipv6AddrIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6AddrIid.idx[0]);
	ipv6AddrIid.level = 2;
	ipv6AddrIid.idx[1] = ipv6Instance;
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, &ipv6AddrJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		return ret;
	}

	
	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6AddrJobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "Prefix") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe181To98MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix),"%s.X_ZYXEL_IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6AddrJobj);

	return ZCFG_SUCCESS;	
}
/*	
 *	 TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Address.i.
 *
 *	 Related object in TR181:
 *	 Device.IP.Interface.i
 *	 Device.IP.Interface.i.IPv6Address.i.
 */

zcfgRet_t lanIpIntfV6AddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6AddrIid;
	struct json_object *ipv6AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipv6AddrIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6AddrIid.idx[0]);
	ipv6AddrIid.level = 2;
	ipv6AddrIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, &ipv6AddrJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		return ret;
	}


	if(multiJobj){
		tmpObj = ipv6AddrJobj;
		ipv6AddrJobj = NULL;
		ipv6AddrJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/ 	
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*special case*/
			if(strcmp( paramList->name, "Prefix") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".X_ZYXEL_IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe98To181MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(ipv6AddrJobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}			
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6AddrJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6AddrJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/

		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){		
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, ipv6AddrJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
			json_object_put(ipv6AddrJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		}
		json_object_put(ipv6AddrJobj);
	}

	return ret;
}


/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t lanIpIntfV6AddrObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objV6Iid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ipIface[32] = {0};
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}




	IID_INIT(objV6Iid);
	objV6Iid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &objV6Iid.idx[0]);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V6_ADDR, &objV6Iid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Add IP.Interface.%d.IPv6Address Fail.\n", __FUNCTION__, objV6Iid.idx[0]);
		return ret;
	}

	*idx = objV6Iid.idx[1];
	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t lanIpIntfV6AddrObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint8_t ipv6Instance = 0;
	char ipIface[32] = {0};
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}


	IID_INIT(objIid);
	objIid.level = 2;
	sscanf(ipIface, "IP.Interface.%hhu", &objIid.idx[0]);
	objIid.idx[1] = ipv6Instance;

	ret = zcfgFeObjStructDel(RDM_OID_IP_IFACE_V6_ADDR, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, objIid.idx[0], objIid.idx[1]);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t lanIpIntfV6PrefixObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6PrefixIid;
	struct json_object *ipv6PrefixJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);

	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	IID_INIT(ipv6PrefixIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6PrefixIid.idx[0]);
	ipv6PrefixIid.level = 2;
	ipv6PrefixIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, &ipv6PrefixJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		return ret;
	}

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6PrefixJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6PrefixJobj);

	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */

zcfgRet_t lanIpIntfV6PrefixObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6PrefixIid;
	struct json_object *ipv6PrefixJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipv6PrefixIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6PrefixIid.idx[0]);
	ipv6PrefixIid.level = 2;
	ipv6PrefixIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, &ipv6PrefixJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		return ret;
	}


	if(multiJobj){
		tmpObj = ipv6PrefixJobj;
		ipv6PrefixJobj = NULL;
		ipv6PrefixJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6PrefixJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6PrefixJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, ipv6PrefixJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
			json_object_put(ipv6PrefixJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		}
		json_object_put(ipv6PrefixJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t lanIpIntfV6PrefixObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objV6Iid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ipIface[32] = {0};
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}



	IID_INIT(objV6Iid);
	objV6Iid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &objV6Iid.idx[0]);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V6_PREFIX, &objV6Iid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Add IP.Interface.%d.IPv6Prefix Fail.\n", __FUNCTION__, objV6Iid.idx[0]);
		return ret;
	}

	*idx = objV6Iid.idx[1];
	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t lanIpIntfV6PrefixObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint8_t ipv6Instance = 0;
	char ipIface[32] = {0};
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}


	IID_INIT(objIid);
	objIid.level = 2;
	sscanf(ipIface, "IP.Interface.%hhu", &objIid.idx[0]);
	objIid.idx[1] = ipv6Instance;

	ret = zcfgFeObjStructDel(RDM_OID_IP_IFACE_V6_PREFIX, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, objIid.idx[0], objIid.idx[1]);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_RouterAdvertisement.
 *
 *   Related object in TR181:
 *   Device.RouterAdvertisement.
 *   Device.RouterAdvertisement.InterfaceSetting.i.
 */
zcfgRet_t lanIpIntfRouterAdverObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ifsetIid;
	struct json_object *ifsetJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_RouterAdvertisement");
	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	
	IID_INIT(ifsetIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_RT_ADV_INTF_SET, &ifsetIid, &ifsetJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(ifsetJobj, "Interface")));
		if(!strcmp(ipIface, ifBuf))
			break;
		else {
			json_object_put(ifsetJobj);
			ifsetJobj = NULL;
		}
	}

	if(ifsetJobj == NULL)
		return ret;

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ifsetJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ifsetJobj);

	return ZCFG_SUCCESS;	
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_RouterAdvertisement.
 *
 *   Related object in TR181:
 *   Device.RouterAdvertisement.
 *   Device.RouterAdvertisement.InterfaceSetting.i.
 */
zcfgRet_t lanIpIntfRouterAdverObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ifsetIid;
	struct json_object *ifsetJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_RouterAdvertisement");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ifsetIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_RT_ADV_INTF_SET, &ifsetIid, &ifsetJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(ifsetJobj, "Interface")));
		if(!strcmp(ipIface, ifBuf))
			break;
		else {
			json_object_put(ifsetJobj);
			ifsetJobj = NULL;
		}
	}

	if(ifsetJobj == NULL)
		return ret;


	if(multiJobj){
		tmpObj = ifsetJobj;
		ifsetJobj = NULL;
		ifsetJobj = zcfgFeJsonMultiObjAppend(RDM_OID_RT_ADV_INTF_SET, &ifsetIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ifsetJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ifsetJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_RT_ADV_INTF_SET, &ifsetIid, ifsetJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.RouterAdvertisement.InterfaceSetting.%d Fail\n", __FUNCTION__, ifsetIid.idx[0]);
			json_object_put(ifsetJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.RouterAdvertisement.InterfaceSetting.%d Fail\n", __FUNCTION__, ifsetIid.idx[0]);
		}
		json_object_put(ifsetJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_DHCPv6Server.
 *
 *   Related object in TR181:
 *   Device.RouterAdvertisement.
 *   Device.RouterAdvertisement.InterfaceSetting.i.
 */
zcfgRet_t lanIpIntfV6SrvObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixBuf[TR98_MAX_OBJ_NAME_LENGTH*8] = {0};
	objIndex_t srvpoolIid;
	struct json_object *srvpoolJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	uint8_t prefixInstance = 0;
	char *token = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_DHCPv6Server");
	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	
	IID_INIT(srvpoolIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DHCPV6_SRV_POOL, &srvpoolIid, &srvpoolJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(srvpoolJobj, "Interface")));
		if(!strcmp(ipIface, ifBuf))
			break;
		else {
			json_object_put(srvpoolJobj);
			srvpoolJobj = NULL;
		}
	}

	if(srvpoolJobj == NULL)
		return ret;

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(srvpoolJobj, paramList->name);
		if(paramValue != NULL) {
			/*special case*/
			if(strcmp( paramList->name, "IANAPrefixes") == 0){//transfer
				strcpy(prefixBuf, json_object_get_string(paramValue));
				token = strtok(prefixBuf, ",");
				while(token){
					strcpy(prefixObjName, token);
					ptr = strstr(prefixObjName, ".IPv6Prefix");
					if(ptr){
						sscanf(ptr, ".IPv6Prefix.%hhu", &prefixInstance);
						*ptr = '\0';
						if(zcfgFe181To98MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
							if(strlen(tr98Prefix) >0)
								snprintf(tr98Prefix, sizeof(tr98Prefix),"%s,%s.X_ZYXEL_IPv6Prefix.%d", tr98Prefix, ipIface, prefixInstance);
							else
								snprintf(tr98Prefix, sizeof(tr98Prefix),"%s.X_ZYXEL_IPv6Prefix.%d", ipIface, prefixInstance);
						}
					}			
					token = strtok(NULL, ",");
				}
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98Prefix));
				paramList++;
				continue;
			}

			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(srvpoolJobj);

	return ZCFG_SUCCESS;	
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.LANDevice.i.LANHostConfigManagement.IPInterface.i.X_ZYXEL_DHCPv6Server.
 *
 *   Related object in TR181:
 *   Device.DHCPv6.Server.
 *   Device.DHCPv6.Server.Pool.i.
 */
zcfgRet_t lanIpIntfV6SrvObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t srvpoolIid;
	struct json_object *srvpoolJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_DHCPv6Server");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(srvpoolIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DHCPV6_SRV_POOL, &srvpoolIid, &srvpoolJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(srvpoolJobj, "Interface")));
		if(!strcmp(ipIface, ifBuf))
			break;
		else {
			json_object_put(srvpoolJobj);
			srvpoolJobj = NULL;
		}
	}

	if(srvpoolJobj == NULL)
		return ret;


	if(multiJobj){
		tmpObj = srvpoolJobj;
		srvpoolJobj = NULL;
		srvpoolJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV6_SRV_POOL, &srvpoolIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*special case*/
			if(strcmp( paramList->name, "IANAPrefixes") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".X_ZYXEL_IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe98To181MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(srvpoolJobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}		
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(srvpoolJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(srvpoolJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV6_SRV_POOL, &srvpoolIid, srvpoolJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv6.Server.Pool.%d Fail\n", __FUNCTION__, srvpoolIid.idx[0]);
			json_object_put(srvpoolJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv6.Server.Pool.%d Fail\n", __FUNCTION__, srvpoolIid.idx[0]);
		}
		json_object_put(srvpoolJobj);
	}

	return ret;
}

