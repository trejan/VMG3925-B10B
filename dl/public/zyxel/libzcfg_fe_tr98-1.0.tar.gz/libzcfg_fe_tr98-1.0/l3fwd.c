#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "l3fwd_parameter.h"

extern tr98Object_t tr98Obj[];

/*
 *   TR98 Object Name : InternetGatewayDevice.Layer3Forwarding
 *
 *   Related object in TR181:
 *   Device.Routing.Router.1
 */
zcfgRet_t l3fwdObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	objIndex_t objIid;
	char iface[32] = {0};
	char lowerLayer[32] = {0};
	rdm_RoutingRouter_t *routerObj = NULL;
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	/*mapping InternetGatewayDevice.Layer3Forwarding to Device.Routing.Router.1*/
	IID_INIT(objIid);
	objIid.level = 1;
	objIid.idx[0] = 1;

	if(zcfgFeObjStructGet(RDM_OID_ROUTING_ROUTER, &objIid, (void **)&routerObj) != ZCFG_SUCCESS ) {
		printf("%s : Get Routing.Router.1 Fail\n", __FUNCTION__);
		return ZCFG_INTERNAL_ERROR;
	}


	zcfgFeTr181IfaceStackLowerLayerGet(routerObj->X_ZYXEL_ActiveDefaultGateway, lowerLayer);
	if(strstr(lowerLayer, "PPP.Interface") != NULL) {
		strcpy(iface, lowerLayer);
	}
	else {
		/*IP.Interface*/
		strcpy(iface, routerObj->X_ZYXEL_ActiveDefaultGateway);
	}

	zcfgFe181To98MappingNameGet(iface, tr98ObjName);

	*tr98Jobj = json_object_new_object();
	json_object_object_add(*tr98Jobj, "DefaultConnectionService", json_object_new_string(tr98ObjName));
	json_object_object_add(*tr98Jobj, "ForwardNumberOfEntries", json_object_new_int(routerObj->IPv4ForwardingNumberOfEntries));

	zcfgFeObjStructFree(routerObj);

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.Layer3Forwarding.Forwarding.i
 *
 *   Related object in TR181:
 *   Device.Routing.Router.1.IPv4Forwarding.i
 */
zcfgRet_t l3fwdFwdTbObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	uint8_t idx = 0;
	objIndex_t objIid;
	struct json_object *ipv4FwdObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char devIpIface[48] = {0};
	char iface[40] = {0};
	char lowerLayer[32] = {0};
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	sscanf(tr98FullPathName, "InternetGatewayDevice.Layer3Forwarding.Forwarding.%hhu", &idx);

	/*mapping InternetGatewayDevice.Layer3Forwarding to Device.Routing.Router.1*/
	IID_INIT(objIid);
	objIid.level = 2;
	objIid.idx[0] = 1;
	objIid.idx[1] = idx;

	if((ret = zcfgFeObjJsonGet(RDM_OID_ROUTING_ROUTER_V4_FWD, &objIid, &ipv4FwdObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*special case*/
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(ipv4FwdObj, paramList->name);
			strcpy(devIpIface, json_object_get_string(paramValue));
			sscanf(devIpIface, "Device.%s", iface);

			zcfgFeTr181IfaceStackLowerLayerGet(iface, lowerLayer);
			if(strstr(lowerLayer, "PPP.Interface") != NULL) {
				strcpy(iface, lowerLayer);
			}

			zcfgFe181To98MappingNameGet(iface, tr98ObjName);
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98ObjName));

			paramList++;
			continue;
		}

		paramValue = json_object_object_get(ipv4FwdObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(!strcmp(paramList->name, "SourceIPAddress") || !strcmp(paramList->name, "SourceSubnetMask")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "MTU")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(1540));
			paramList++;
			continue;
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}

	json_object_put(ipv4FwdObj);

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.Layer3Forwarding.Forwarding.i
 *
 *   Related object in TR181:
 *   Device.Routing.Router.1.IPv4Forwarding.i
 */
zcfgRet_t l3fwdFwdTbObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	uint8_t idx = 0;
	objIndex_t objIid;
	struct json_object *ipv4FwdObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char iface[40] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char higherLayer[32] = {0};
	char devIpIface[48] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	sscanf(tr98FullPathName, "InternetGatewayDevice.Layer3Forwarding.Forwarding.%hhu", &idx);

	/*mapping InternetGatewayDevice.Layer3Forwarding to Device.Routing.Router.1*/
	IID_INIT(objIid);
	objIid.level = 2;
	objIid.idx[0] = 1;
	objIid.idx[1] = idx;

	if((ret = zcfgFeObjJsonGet(RDM_OID_ROUTING_ROUTER_V4_FWD, &objIid, &ipv4FwdObj)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(multiJobj){
		tmpObj = ipv4FwdObj;
		ipv4FwdObj = NULL;
		ipv4FwdObj = zcfgFeJsonMultiObjAppend(RDM_OID_ROUTING_ROUTER_V4_FWD, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				strcpy(tr98ConnObjName, json_object_get_string(paramValue));
				if(zcfgFe98To181MappingNameGet(tr98ConnObjName, iface) != ZCFG_SUCCESS) {
					json_object_object_add(ipv4FwdObj, paramList->name, json_object_new_string(""));
				}
				else {
					if(strstr(iface, "PPP.Interface") != NULL) {
						zcfgFeTr181IfaceStackHigherLayerGet(iface, higherLayer);
						strcpy(iface, higherLayer);
					}
					
					sprintf(devIpIface, "Device.%s", iface);
					json_object_object_add(ipv4FwdObj, paramList->name, json_object_new_string(devIpIface));
				}
			}
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(ipv4FwdObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv4FwdObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	/*Set Device.Routing.Router.1.IPv4Forwarding.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_ROUTING_ROUTER_V4_FWD, &objIid, ipv4FwdObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(ipv4FwdObj);
			return ret;
		}
		json_object_put(ipv4FwdObj);
	}

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.Layer3Forwarding.Forwarding.i
 *
 *   Related object in TR181:
 *   Device.Routing.Router.1.IPv4Forwarding.i
 */
zcfgRet_t l3fwdFwdTbObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objIid;

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	objIid.level = 1;
	objIid.idx[0] = 1;

	if((ret = zcfgFeObjStructAdd(RDM_OID_ROUTING_ROUTER_V4_FWD, &objIid, NULL)) != ZCFG_SUCCESS) {
		printf("%s : Add Instance Fail!!\n", __FUNCTION__);
		return ret;
	}

	*idx = objIid.idx[1];

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.Layer3Forwarding.Forwarding.i
 *
 *   Related object in TR181:
 *   Device.Routing.Router.1.IPv4Forwarding.i
 */
zcfgRet_t l3fwdFwdTbObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	uint8_t idx = 0;
	objIndex_t objIid;

	printf("%s : Enter\n", __FUNCTION__);
	
	sscanf(tr98FullPathName, "InternetGatewayDevice.Layer3Forwarding.Forwarding.%hhu", &idx);

	IID_INIT(objIid);
	objIid.level = 2;
	objIid.idx[0] = 1;	
	objIid.idx[1] = idx;

	ret = zcfgFeObjJsonDel(RDM_OID_ROUTING_ROUTER_V4_FWD, &objIid, NULL);
	if(ret != ZCFG_SUCCESS) {
		printf("%s : Delete Object Fail\n", __FUNCTION__);	
	}
	
	return ret;
}