tr98Parameter_t para_L3Fwd[] = {
	{ "DefaultConnectionService", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "ForwardNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};
	
tr98Parameter_t para_Fwd[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Status", PARAMETER_ATTR_READONLY, 10, json_type_string},
	{ "StaticRoute", PARAMETER_ATTR_READONLY, 0, json_type_boolean},
	{ "Type", PARAMETER_ATTR_WRITE, 9, json_type_string},
	{ "DestIPAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "DestSubnetMask", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "SourceIPAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "SourceSubnetMask", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "ForwardingPolicy", PARAMETER_ATTR_WRITE, 0, json_type_int},
	{ "GatewayIPAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "Interface", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "ForwardingMetric", PARAMETER_ATTR_WRITE, 0, json_type_int},
	{ "MTU", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};

