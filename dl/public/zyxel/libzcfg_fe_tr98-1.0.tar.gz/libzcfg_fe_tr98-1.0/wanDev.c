#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "zcfg_net.h"
#include "wanDev_parameter.h"

#include "wanDev_api.h"

extern tr98Object_t tr98Obj[];

extern zcfgRet_t zcfgFeTr181IfaceStackHigherLayerGet(char *, char *);

zcfgRet_t WANIpConnObjDel(char *);
zcfgRet_t WANPppConnObjDel(char *);

/* InternetGatewayDevice.WANDevice.i */
zcfgRet_t WANDeviceObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char wanConnDevName[128] = {0};
	int count = 0;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, tr181Obj) != ZCFG_SUCCESS) {
		/*  The instance number of WANDevice.i will be continuous because of the tr98 to tr181 mapping table. 
		 *  Therefore, just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANDevice object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}

	sprintf(wanConnDevName, "%s.WANConnectionDevice.%d", tr98FullPathName, (count+1));

	while((ret = zcfgFe98To181MappingNameGet(wanConnDevName, tr181Obj)) == ZCFG_SUCCESS) {
		count++;
		sprintf(wanConnDevName, "%s.WANConnectionDevice.%d", tr98FullPathName, (count+1));
	}

	*tr98Jobj = json_object_new_object();
	json_object_object_add(*tr98Jobj, "WANConnectionNumberOfEntries", json_object_new_int(count));

	return ZCFG_SUCCESS;
}
/* InternetGatewayDevice.WANDevice.1.WANDSLDiagnostics */
zcfgRet_t WANDslDiagObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	objIndex_t objIid;
	rdm_DslDiagAdslLineTest_t *DslDiagObj = NULL;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	if(strstr(tr98FullPathName, ".WANDevice.1.") != NULL)
	{
		strcpy(tr98TmpName, tr98FullPathName);
		ptr = strstr(tr98TmpName, ".WANDSLDiagnostics");
		*ptr = '\0';
		/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
		if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, tr181Obj)) != ZCFG_SUCCESS) {
			/*No such object*/
			return ret;
		}
		*tr98Jobj = json_object_new_object();
		
		IID_INIT(objIid);

		if((ret = zcfgFeObjStructGet(RDM_OID_DSL_DIAG_ADSL_LINE_TEST, &objIid, (void **)&DslDiagObj)) == ZCFG_SUCCESS){
			json_object_object_add(*tr98Jobj, "LoopDiagnosticsState", json_object_new_string(DslDiagObj->DiagnosticsState));
			json_object_object_add(*tr98Jobj, "ACTPSDds", json_object_new_int(DslDiagObj->ACTPSDds));
			json_object_object_add(*tr98Jobj, "ACTPSDus", json_object_new_int(DslDiagObj->ACTPSDus));
			json_object_object_add(*tr98Jobj, "ACTATPds", json_object_new_int(DslDiagObj->ACTATPds));
			json_object_object_add(*tr98Jobj, "ACTATPus", json_object_new_int(DslDiagObj->ACTATPus));
			json_object_object_add(*tr98Jobj, "HLINSCds", json_object_new_int(DslDiagObj->HLINSCds));
			json_object_object_add(*tr98Jobj, "HLINSCus", json_object_new_int(DslDiagObj->HLINSCus));
			json_object_object_add(*tr98Jobj, "HLINGds", json_object_new_int(DslDiagObj->HLINGds));
			json_object_object_add(*tr98Jobj, "HLINGus", json_object_new_int(DslDiagObj->HLINGus));
			json_object_object_add(*tr98Jobj, "HLOGGds", json_object_new_int(DslDiagObj->HLOGGds));
			json_object_object_add(*tr98Jobj, "HLOGGus", json_object_new_int(DslDiagObj->HLOGGus));
			json_object_object_add(*tr98Jobj, "HLOGpsds", json_object_new_string(DslDiagObj->HLOGpsds));
			json_object_object_add(*tr98Jobj, "HLOGpsus", json_object_new_string(DslDiagObj->HLOGpsus));
			json_object_object_add(*tr98Jobj, "HLOGMTds", json_object_new_int(DslDiagObj->HLOGMTds));
			json_object_object_add(*tr98Jobj, "HLOGMTus", json_object_new_int(DslDiagObj->HLOGMTus));
			json_object_object_add(*tr98Jobj, "LATNpbds", json_object_new_string(DslDiagObj->LATNpbds));
			json_object_object_add(*tr98Jobj, "LATNpbus", json_object_new_string(DslDiagObj->LATNpbus));
			json_object_object_add(*tr98Jobj, "SATNds", json_object_new_string(DslDiagObj->SATNds));
			json_object_object_add(*tr98Jobj, "SATNus", json_object_new_string(DslDiagObj->SATNus));
			json_object_object_add(*tr98Jobj, "HLINpsds", json_object_new_string(DslDiagObj->HLINpsds));
			json_object_object_add(*tr98Jobj, "HLINpsus", json_object_new_string(DslDiagObj->HLINpsus));
			json_object_object_add(*tr98Jobj, "QLNGds", json_object_new_int(DslDiagObj->QLNGds));
			json_object_object_add(*tr98Jobj, "QLNGus", json_object_new_int(DslDiagObj->QLNGus));
			json_object_object_add(*tr98Jobj, "QLNpsds", json_object_new_string(DslDiagObj->QLNpsds));
			json_object_object_add(*tr98Jobj, "QLNpsus", json_object_new_string(DslDiagObj->QLNpsus));
			json_object_object_add(*tr98Jobj, "QLNMTds", json_object_new_int(DslDiagObj->QLNMTds));
			json_object_object_add(*tr98Jobj, "QLNMTus", json_object_new_int(DslDiagObj->QLNMTus));
			json_object_object_add(*tr98Jobj, "SNRGds", json_object_new_int(DslDiagObj->SNRGds));
			json_object_object_add(*tr98Jobj, "SNRGus", json_object_new_int(DslDiagObj->SNRGus));
			json_object_object_add(*tr98Jobj, "SNRpsds", json_object_new_string(DslDiagObj->SNRpsds));
			json_object_object_add(*tr98Jobj, "SNRpsus", json_object_new_string(DslDiagObj->SNRpsus));
			json_object_object_add(*tr98Jobj, "SNRMTds", json_object_new_int(DslDiagObj->SNRMTds));
			json_object_object_add(*tr98Jobj, "SNRMTus", json_object_new_int(DslDiagObj->SNRMTus));
			json_object_object_add(*tr98Jobj, "BITSpsds", json_object_new_string(DslDiagObj->BITSpsds));
			json_object_object_add(*tr98Jobj, "BITSpsus", json_object_new_string(DslDiagObj->BITSpsus));
//			json_object_object_add(*tr98Jobj, "GAINSpsds", json_object_new_string(DslDiagObj->GAINSpsds));
			zcfgFeObjStructFree(DslDiagObj);
		}
	}
	return ZCFG_SUCCESS;
}

zcfgRet_t WANDslDiagObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	objIndex_t objIid;
	rdm_DslDiagAdslLineTest_t *DslDiagObj = NULL;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	if(strstr(tr98FullPathName, ".WANDevice.1.") != NULL)
	{
		strcpy(tr98TmpName, tr98FullPathName);
		ptr = strstr(tr98TmpName, ".WANDSLDiagnostics");
		*ptr = '\0';
		
		/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
		if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, tr181Obj)) != ZCFG_SUCCESS) {
			/*No such object*/
			return ret;
		}
		
		IID_INIT(objIid);

		if((ret = zcfgFeObjJsonGet(RDM_OID_DSL_DIAG_ADSL_LINE_TEST, &objIid, (void **)&DslDiagObj)) == ZCFG_SUCCESS){
			json_object_object_add(DslDiagObj, "DiagnosticsState", JSON_OBJ_COPY(json_object_object_get(tr98Jobj, "LoopDiagnosticsState")));

			if((ret = zcfgFeObjJsonSet(RDM_OID_DSL_DIAG_ADSL_LINE_TEST, &objIid, DslDiagObj, NULL)) != ZCFG_SUCCESS ) {
				zcfgLog(ZCFG_LOG_ERR, "%s : Set DSL.Diagnostics Fail\n", __FUNCTION__);
				zcfgFeJsonObjFree(DslDiagObj);
				return ret;
			}
			else {
				zcfgLog(ZCFG_LOG_DEBUG, "%s : Set DSL.Diagnostics Success\n", __FUNCTION__);
			}
			zcfgFeJsonObjFree(DslDiagObj);
		}
	}
	return ZCFG_SUCCESS;
}


/* InternetGatewayDevice.WANDevice.i.WANCommonInterfaceConfig */
zcfgRet_t WANCommIfaceCfgObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char tr181ObjPath[32] = {0};
	char higherLayerPath[128] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	objIndex_t objIid;
	objIndex_t ipAddrIid;
	bool enableForInternet = false;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANCommonInterfaceConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, tr181Obj)) != ZCFG_SUCCESS) {
		/*No such object*/
		return ret;
	}

	*tr98Jobj = json_object_new_object();

	strcpy(tr181ObjPath, tr181Obj);
	/*specical case to get parameter "EnabledForInternet"*/
	while((ret = zcfgFeTr181IfaceStackHigherLayerGet(tr181ObjPath, higherLayerPath)) == ZCFG_SUCCESS) {
		if(strstr(higherLayerPath, "IP.Interface") != NULL) {
			rdm_IpIface_t *ipIntfObj = NULL;
			rdm_IpIfaceV4Addr_t *v4AddrObj = NULL;
			rdm_IpIfaceV6Addr_t *v6AddrObj = NULL;
			IID_INIT(objIid);
			IID_INIT(ipAddrIid);
			objIid.level = 1;
			sscanf(higherLayerPath, "IP.Interface.%hhu", &objIid.idx[0]);
			if((ret = zcfgFeObjStructGet(RDM_OID_IP_IFACE, &objIid, (void **)&ipIntfObj)) == ZCFG_SUCCESS){
	
				if(ipIntfObj->IPv4Enable){				
					if((ret = zcfgFeSubInStructGetNext(RDM_OID_IP_IFACE_V4_ADDR, &objIid,&ipAddrIid, (void **)&v4AddrObj)) == ZCFG_SUCCESS){						
						if(!strcmp(v4AddrObj->Status, TR181_ENABLED))
							enableForInternet = true;
						else
							enableForInternet = false;
						
						zcfgFeObjStructFree(v4AddrObj);					
					}
				}
				else if(ipIntfObj->IPv6Enable){			
					if((ret = zcfgFeSubInStructGetNext(RDM_OID_IP_IFACE_V6_ADDR, &objIid,&ipAddrIid, (void **)&v6AddrObj)) == ZCFG_SUCCESS){
						if(strcmp(v6AddrObj->Status, TR181_ENABLED))
							enableForInternet = true;
						else
							enableForInternet = false;

						zcfgFeObjStructFree(v6AddrObj);
					}
				}
				
				json_object_object_add(*tr98Jobj, "EnabledForInternet" ,json_object_new_boolean(enableForInternet));
			}

			zcfgFeObjStructFree(ipIntfObj);
			break;
		}

		strcpy(tr181ObjPath, higherLayerPath);
	}
	
	/*Hard coding*/
	json_object_object_add(*tr98Jobj, "WANAccessProvider", json_object_new_string(""));
	json_object_object_add(*tr98Jobj, "MaximumActiveConnections", json_object_new_int(0));
	json_object_object_add(*tr98Jobj, "NumberOfActiveConnections", json_object_new_int(0));
	/*Init value*/
	json_object_object_add(*tr98Jobj, "PhysicalLinkStatus", json_object_new_string("Unavailable"));
	IID_INIT(objIid);
	objIid.level = 1;

	if(strstr(tr181Obj, "DSL") != NULL) {
		rdm_DslChannel_t *dslChannel = NULL;
		rdm_DslChannelSt_t *dslChannelSt = NULL;
		
		json_object_object_add(*tr98Jobj, "WANAccessType", json_object_new_string("DSL"));
		sscanf(tr181Obj, "DSL.Channel.%hhu", &objIid.idx[0]);
		if(zcfgFeObjStructGet(RDM_OID_DSL_CHANNEL, &objIid, (void **)&dslChannel) == ZCFG_SUCCESS) {
			json_object_object_add(*tr98Jobj, "Layer1UpstreamMaxBitRate", json_object_new_int(dslChannel->UpstreamCurrRate));
			json_object_object_add(*tr98Jobj, "Layer1DownstreamMaxBitRate", json_object_new_int(dslChannel->DownstreamCurrRate));

			if(!strcmp(dslChannel->Status, "Up") || !strcmp(dslChannel->Status, "Down")) {
				json_object_object_add(*tr98Jobj, "PhysicalLinkStatus", json_object_new_string(dslChannel->Status));
			}

			zcfgFeObjStructFree(dslChannel);
		}

		if(zcfgFeObjStructGet(RDM_OID_DSL_CHANNEL_ST, &objIid, (void **)&dslChannelSt) == ZCFG_SUCCESS) {
			json_object_object_add(*tr98Jobj, "TotalBytesSent", json_object_new_int(dslChannelSt->BytesSent));
			json_object_object_add(*tr98Jobj, "TotalBytesReceived", json_object_new_int(dslChannelSt->BytesReceived));
			json_object_object_add(*tr98Jobj, "TotalPacketsSent", json_object_new_int(dslChannelSt->PacketsSent));
			json_object_object_add(*tr98Jobj, "TotalPacketsReceived", json_object_new_int(dslChannelSt->PacketsReceived));
			zcfgFeObjStructFree(dslChannelSt);
		}
	}
	else if(strstr(tr181Obj, "Ethernet") != NULL) {
		rdm_EthIface_t *ethIface = NULL;
		rdm_EthIntfSt_t *ethIfaceSt = NULL;
		
		json_object_object_add(*tr98Jobj, "WANAccessType", json_object_new_string("Ethernet"));
		sscanf(tr181Obj, "Ethernet.Interface.%hhu", &objIid.idx[0]);

		if(zcfgFeObjStructGet(RDM_OID_ETH_IFACE, &objIid, (void **)&ethIface) == ZCFG_SUCCESS) {
			json_object_object_add(*tr98Jobj, "Layer1UpstreamMaxBitRate", json_object_new_int(ethIface->MaxBitRate));
			json_object_object_add(*tr98Jobj, "Layer1DownstreamMaxBitRate", json_object_new_int(ethIface->MaxBitRate));

			if(!strcmp(ethIface->Status, "Up") || !strcmp(ethIface->Status, "Down")) {
				json_object_object_add(*tr98Jobj, "PhysicalLinkStatus", json_object_new_string(ethIface->Status));
			}

			zcfgFeObjStructFree(ethIface);
		}

		if(zcfgFeObjStructGet(RDM_OID_ETH_INTF_ST, &objIid, (void **)&ethIfaceSt) == ZCFG_SUCCESS) {
			json_object_object_add(*tr98Jobj, "TotalBytesSent", json_object_new_int(ethIfaceSt->BytesSent));
			json_object_object_add(*tr98Jobj, "TotalBytesReceived", json_object_new_int(ethIfaceSt->BytesReceived));
			json_object_object_add(*tr98Jobj, "TotalPacketsSent", json_object_new_int(ethIfaceSt->PacketsSent));
			json_object_object_add(*tr98Jobj, "TotalPacketsReceived", json_object_new_int(ethIfaceSt->PacketsReceived));
			zcfgFeObjStructFree(ethIfaceSt);
		}
	}
	else {
		zcfgLog(ZCFG_LOG_ERR, "Unknown Object %s\n", tr181Obj);
		return ZCFG_INTERNAL_ERROR;
	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig
 *
 *   Related object in TR181:
 *   Device.DSL.Line.i
 *   Device.DSL.Line.i.Stats
 *   Device.DSL.Channel.i
 */
zcfgRet_t WANDslIfaceCfgObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char dslChannelObj[32] = {0};
	char dslLineObj[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char paramName[64] = {0};
	char *ptr = NULL;
	uint32_t  dslChannelOid = 0, dslLineOid = 0;
	objIndex_t dslChannelIid, dslLineIid;
	struct json_object *dslChannel = NULL, *dslLine = NULL, *dslLineSt = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANDSLInterfaceConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, dslChannelObj)) == ZCFG_SUCCESS) {
		if(strstr(dslChannelObj, "DSL") == NULL) {
			zcfgLog(ZCFG_LOG_WARNING, "%s : Not a DSL Interface\n", __FUNCTION__);
			return ZCFG_NO_SUCH_OBJECT;
		}

		IID_INIT(dslChannelIid);
		sprintf(tr181Obj, "Device.%s", dslChannelObj);
		dslChannelOid = zcfgFeObjNameToObjId(tr181Obj, &dslChannelIid);
		
		if((ret = zcfgFeObjJsonGet(dslChannelOid, &dslChannelIid, &dslChannel)) != ZCFG_SUCCESS)
			return ret;

		strcpy(dslLineObj, json_object_get_string(json_object_object_get(dslChannel, "LowerLayers")));

		sprintf(tr181Obj, "Device.%s", dslLineObj);
		IID_INIT(dslLineIid);
		dslLineOid = zcfgFeObjNameToObjId(tr181Obj, &dslLineIid);

		ret = zcfgFeObjJsonGet(dslLineOid, &dslLineIid, &dslLine);

		ret = zcfgFeObjJsonGet(RDM_OID_DSL_CHANNEL_ST, &dslLineIid, &dslLineSt);

		/*fill up tr98 WANDSLInterfaceConfig object*/
		*tr98Jobj = json_object_new_object();
		paramList = tr98Obj[handler].parameter;
		while(paramList->name != NULL) {
			paramValue = json_object_object_get(dslLine, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			paramValue = json_object_object_get(dslChannel, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			paramValue = json_object_object_get(dslLineSt, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
			if(strstr(paramList->name, "ATU") != NULL) {
				strcpy(paramName, paramList->name);
				paramName[0] = 'X';
				paramValue = json_object_object_get(dslLine, paramName);
				if(paramValue != NULL) {
					json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;	
				}
			}
			
			/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;
		}

		json_object_put(dslChannel);
		json_object_put(dslLine);
		json_object_put(dslLineSt);
	}
	else {
		return ret;	
	}

	return ZCFG_SUCCESS;
}
/*   
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig
 *
 *   Related object in TR181:
 *   Device.DSL.Channel.i
 */
zcfgRet_t WANDslIfaceCfgObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char dslChannelObj[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	objIndex_t objIid;
	struct json_object *dslChannel = NULL;
	struct json_object *tmpObj = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANDSLInterfaceConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, dslChannelObj)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(dslChannelObj, "DSL") == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Not a DSL Interface\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	IID_INIT(objIid);
	sscanf(dslChannelObj, "DSL.Channel.%hhu", &objIid.idx[0]);
	objIid.level = 1;

	if((ret = zcfgFeObjJsonGet(RDM_OID_DSL_CHANNEL, &objIid, &dslChannel)) == ZCFG_SUCCESS) {
		if(multiJobj){
			tmpObj = dslChannel;
			dslChannel = NULL;
			dslChannel = zcfgFeJsonMultiObjAppend(RDM_OID_DSL_CHANNEL, &objIid, multiJobj, tmpObj);
		}
		json_object_object_add(dslChannel, "Enable", JSON_OBJ_COPY(json_object_object_get(tr98Jobj, "Enable")));

		if(multiJobj){
			json_object_put(tmpObj);
		}
		else {
			if((ret = zcfgFeObjJsonSet(RDM_OID_DSL_CHANNEL, &objIid, dslChannel, NULL)) != ZCFG_SUCCESS ) {
				zcfgLog(ZCFG_LOG_ERR, "%s : Set DSL.Channel Fail\n", __FUNCTION__);
				json_object_put(dslChannel);
				return ret;
			}
			else {
				zcfgLog(ZCFG_LOG_DEBUG, "%s : Set DSL.Channel Success\n", __FUNCTION__);
			}
			json_object_put(dslChannel);
		}

	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANDSLInterfaceConfig.TestParams 
 *
 *   Related object in TR181:
 *   Device.DSL.Line.i.TestParams
 */
zcfgRet_t WANDslIfTestParamGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr181ObjName[32] = {0};
	tr98Parameter_t *paramList = NULL;
	objIndex_t dslChIid, dslLineIid;
	rdm_DslChannel_t *dslChObj = NULL;
	struct json_object *dslTestParamJobj = NULL;
	struct json_object *paramValue = NULL;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	/*find tr181 mapping object*/
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANDSLInterfaceConfig.TestParams");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, tr181ObjName)) != ZCFG_SUCCESS) {
		/*No such object*/
		return ret;
	}
		
	if(strstr(tr181ObjName, "DSL") == NULL) {
		zcfgLog(ZCFG_LOG_WARNING, "%s : Not a DSL Interface\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	IID_INIT(dslChIid);
	sscanf(tr181ObjName, "DSL.Channel.%hhu", &dslChIid.idx[0]);
	dslChIid.level = 1;

	if((ret = zcfgFeObjStructGet(RDM_OID_DSL_CHANNEL, &dslChIid, (void **)&dslChObj)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(dslLineIid);
	sscanf(dslChObj->LowerLayers, "DSL.Line.%hhu", &dslLineIid.idx[0]);
	dslLineIid.level = 1;

	zcfgFeObjStructFree(dslChObj);

	if((ret = zcfgFeObjJsonGet(RDM_OID_DSL_LINE_TEST_PARAMS, &dslLineIid, &dslTestParamJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(dslTestParamJobj, paramList->name);

		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;	
	}

	json_object_put(dslTestParamJobj);

	return ZCFG_SUCCESS;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig
 *
 *  Related object in TR181:
 *  Device.Ethernet.Interface.i
 */
zcfgRet_t WANEthIfaceCfgObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char ethIfaceObj[32] = {0};
	uint32_t  ethIfaceOid = 0;
	objIndex_t ethIfaceIid;
	struct json_object *ethIfaceJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANEthernetInterfaceConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ethIfaceObj)) == ZCFG_SUCCESS) {
		if(strstr(ethIfaceObj, "Ethernet") == NULL) {
			printf("%s : Not an Ethernet Interface\n", __FUNCTION__);
			return ZCFG_NO_SUCH_OBJECT;
		}

		IID_INIT(ethIfaceIid);
		sprintf(tr181Obj, "Device.%s", ethIfaceObj);
		ethIfaceOid = zcfgFeObjNameToObjId(tr181Obj, &ethIfaceIid);

		if((ret = zcfgFeObjJsonGet(ethIfaceOid, &ethIfaceIid, &ethIfaceJobj)) != ZCFG_SUCCESS)
			return ret;
		
		//printf("Ethernet Interface %s\n", json_object_to_json_string(ethIfaceJobj));

		/*fill up tr98 WANEthernetInterfaceConfig object*/
		*tr98Jobj = json_object_new_object();
		paramList = tr98Obj[handler].parameter;
		while(paramList->name != NULL) {
			paramValue = json_object_object_get(ethIfaceJobj, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			
			/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;
		}

		json_object_put(ethIfaceJobj);
	}

	return ZCFG_SUCCESS;	
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig

    Related object in TR181:
    Device.Ethernet.Interface.i
 */
zcfgRet_t WANEthIfaceCfgObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ethIfaceName[32] = {0};
	char *ptr = NULL;
	objIndex_t ethIfaceIid;
	tr98Parameter_t *paramList = NULL;
	struct json_object *ethIfaceJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	/*find tr181 mapping object*/
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANEthernetInterfaceConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ethIfaceName)) == ZCFG_SUCCESS) {
		if(strstr(ethIfaceName, "Ethernet") == NULL) {
			printf("%s : Not an Ethernet Interface\n", __FUNCTION__);
			return ZCFG_NO_SUCH_OBJECT;
		}

		IID_INIT(ethIfaceIid);
		sscanf(ethIfaceName, "Ethernet.Interface.%hhu", &ethIfaceIid.idx[0]);
		ethIfaceIid.level = 1;

		if((ret = zcfgFeObjJsonGet(RDM_OID_ETH_IFACE, &ethIfaceIid, &ethIfaceJobj)) != ZCFG_SUCCESS)
			return ret;		

		if(multiJobj){
			tmpObj = ethIfaceJobj;
			ethIfaceJobj = NULL;
			ethIfaceJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ROUTING_ROUTER_V4_FWD, &ethIfaceIid, multiJobj, tmpObj);
		}

		paramList = tr98Obj[handler].parameter;
		while(paramList->name != NULL) {
			/*Write new parameter value from tr98 object to tr181 objects*/	
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				tr181ParamValue = json_object_object_get(ethIfaceJobj, paramList->name);
				if(tr181ParamValue != NULL) {
					json_object_object_add(ethIfaceJobj, paramList->name, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;	
		}

		if(multiJobj){
			json_object_put(tmpObj);
		}
		else{
			if((ret = zcfgFeObjJsonSet(RDM_OID_ETH_IFACE, &ethIfaceIid, ethIfaceJobj, NULL)) != ZCFG_SUCCESS ) {
				json_object_put(ethIfaceJobj);
				return ret;
			}
			json_object_put(ethIfaceJobj);
		}
	}

	return ZCFG_SUCCESS;
}

/*  InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig.Stats

    Related object in TR181:
    Device.Ethernet.Interface.i.Stats.
 */
zcfgRet_t WANEthIfaceCfgStObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ethIfaceName[32] = {0};
	char *ptr = NULL;
	objIndex_t objIid;
	rdm_EthIntfSt_t *ethIfaceSt = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANEthernetInterfaceConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ethIfaceName)) != ZCFG_SUCCESS) {
		/*No such object*/
		return ret;
	}

	if(strstr(ethIfaceName, "Ethernet") == NULL) {
		printf("%s : Not an Ethernet Interface\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	*tr98Jobj = json_object_new_object();

	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(ethIfaceName, "Ethernet.Interface.%hhu", &objIid.idx[0]);

	if(zcfgFeObjStructGet(RDM_OID_ETH_INTF_ST, &objIid, (void **)&ethIfaceSt) == ZCFG_SUCCESS) {
		json_object_object_add(*tr98Jobj, "BytesSent", json_object_new_int(ethIfaceSt->BytesSent));
		json_object_object_add(*tr98Jobj, "BytesReceived", json_object_new_int(ethIfaceSt->BytesReceived));
		json_object_object_add(*tr98Jobj, "PacketsSent", json_object_new_int(ethIfaceSt->PacketsSent));
		json_object_object_add(*tr98Jobj, "PacketsReceived", json_object_new_int(ethIfaceSt->PacketsReceived));
		zcfgFeObjStructFree(ethIfaceSt);
	}

	return ZCFG_SUCCESS;
}

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
zcfgRet_t WANConnDevObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{	
	zcfgRet_t ret;
	char tr181Obj[32] = {0};
	char wanIpConnName[128] = {0};
	char wanPppConnName[128] = {0};
	int count = 0;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	/*Check if WANConnectionDevice.i exists or not*/
	if(zcfgFe98To181MappingNameGet(tr98FullPathName, tr181Obj) != ZCFG_SUCCESS) {
		/*  The instance number of WANConnectionDevice.i will be continuous because of the tr98 to tr181 mapping table. 
		 *  Therefore, just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANConnectionDevice object.
		 */	
		return ZCFG_NO_MORE_INSTANCE;
	}

	sprintf(wanIpConnName, "%s.WANIPConnection.%d", tr98FullPathName, (count+1));
	while((ret = zcfgFe98To181MappingNameGet(wanIpConnName, tr181Obj)) == ZCFG_SUCCESS) {
		count++;
		sprintf(wanIpConnName, "%s.WANIPConnection.%d", tr98FullPathName, (count+1));
	}

	*tr98Jobj = json_object_new_object();
	json_object_object_add(*tr98Jobj, "WANIPConnectionNumberOfEntries", json_object_new_int(count));
	
	count = 0;
	sprintf(wanPppConnName, "%s.WANPPPConnection.%d", tr98FullPathName, (count+1));
	while((ret = zcfgFe98To181MappingNameGet(wanPppConnName, tr181Obj)) == ZCFG_SUCCESS) {
		count++;
		sprintf(wanPppConnName, "%s.WANPPPConnection.%d", tr98FullPathName, (count+1));
	}

	json_object_object_add(*tr98Jobj, "WANPPPConnectionNumberOfEntries", json_object_new_int(count));

	return ZCFG_SUCCESS;
}
/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
zcfgRet_t WANConnDevObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char tr181Obj[48] = {0};
	char wanIntfObj[48] = {0};
	char wanObjName[32] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	uint32_t  wanIntfOid = 0;
	objIndex_t wanIntfIid;
	objIndex_t objIid;
	char *ptr = NULL;
	rdm_DslChannel_t *dslChannelObj = NULL;
	rdm_AtmLink_t *atmLinkObj = NULL;
	rdm_PtmLink_t *ptmLinkObj = NULL;
	rdm_EthLink_t *ethLinkObj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANConnectionDevice");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanIntfObj)) != ZCFG_SUCCESS) {
		return ret;
	}
        	
	/* wanIntfObj will be DSL.Channel.i or Ethernet.Interface.i */
	IID_INIT(wanIntfIid);
	IID_INIT(objIid);
	sprintf(tr181Obj, "Device.%s", wanIntfObj);
	wanIntfOid = zcfgFeObjNameToObjId(tr181Obj, &wanIntfIid);
		
	if(strstr(wanIntfObj, "DSL") != NULL) { // DSL WAN
		if((ret = zcfgFeObjStructGet(wanIntfOid, &wanIntfIid, (void **)&dslChannelObj)) != ZCFG_SUCCESS)
			return ret;

		if(strstr(dslChannelObj->LinkEncapsulationUsed, "ATM") != NULL) {
			printf("%s : Add ATM Link\n", __FUNCTION__);
			if((ret = zcfgFeObjStructAdd(RDM_OID_ATM_LINK, &objIid, NULL)) != ZCFG_SUCCESS) {
				printf("Add Instance Fail!!\n");
				return ret;
			}
			/*Set LowerLayer for ATM.Link*/
			if((ret = zcfgFeObjStructGet(RDM_OID_ATM_LINK, &objIid, (void **)&atmLinkObj)) == ZCFG_SUCCESS) {
				//atmLinkObj->Enable = true;
				strcpy(atmLinkObj->LowerLayers, wanIntfObj);
				if((ret = zcfgFeObjStructSet(RDM_OID_ATM_LINK, &objIid, (void *)atmLinkObj, NULL)) != ZCFG_SUCCESS) {
					printf("Set ATM.Link LowerLayers Fail\n");
				}

				zcfgFeObjStructFree(atmLinkObj);
			}
			else {
				return ret;
			}

			/*We consider only one ATM phy interface*/
			*idx = objIid.idx[0];
		}
		else if(strstr(dslChannelObj->LinkEncapsulationUsed, "PTM") != NULL) {
			/*Check if PTM WAN Connection Device exists or not*/
			strcat(tr98TmpName, ".WANConnectionDevice.1");
			if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanObjName)) == ZCFG_SUCCESS) {
				printf("%s : Can't add more than one WANConnectionDevice under WANDevice with PTM type\n", __FUNCTION__);
				return ZCFG_INTERNAL_ERROR;
			}

			printf("%s : Add PTM Link\n", __FUNCTION__);
			if((ret = zcfgFeObjStructAdd(RDM_OID_PTM_LINK, &objIid, NULL)) != ZCFG_SUCCESS) {
				printf("Add Instance Fail!!\n");
				return ret;
			}
			/*Set LowerLayer for PTM.Link*/
			if((ret = zcfgFeObjStructGet(RDM_OID_PTM_LINK, &objIid, (void **)&ptmLinkObj)) == ZCFG_SUCCESS) {
				//ptmLinkObj->Enable = true;
				strcpy(ptmLinkObj->LowerLayers, wanIntfObj);
				if((ret = zcfgFeObjStructSet(RDM_OID_PTM_LINK, &objIid, (void *)ptmLinkObj, NULL)) != ZCFG_SUCCESS) {
					printf("%s : Set PTM.Link LowerLayers Fail\n", __FUNCTION__);
				}

				zcfgFeObjStructFree(ptmLinkObj);
			}
			else {
				return ret;
			}

			/*Hard coding here, only one WANConnectionDevice.i will exist under InternetGatewayDevice.WANDevice.i if type is PTM*/
			*idx = 1;
		}
		else {
			printf("%s : Unknown Link Encapsulation Type\n", __FUNCTION__);
		}
	
		zcfgFeObjStructFree(dslChannelObj);
	}
	else if(strstr(wanIntfObj, "Ethernet") != NULL) { // Ethernet WAN
		/*Check if Ethernet WAN Connection Device exists or not*/
		strcat(tr98TmpName, ".WANConnectionDevice.1");
		if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanObjName)) == ZCFG_SUCCESS) {
			printf("%s : Can't add more than one WANConnectionDevice under WANDevice with Ethernet type\n", __FUNCTION__);
			return ZCFG_INTERNAL_ERROR;
		}

		printf("%s : Add Ethernet Link\n", __FUNCTION__);
		if((ret = zcfgFeObjStructAdd(RDM_OID_ETH_LINK, &objIid, NULL)) != ZCFG_SUCCESS) {
			printf("%s : Add Ethernet Link Fail!!\n", __FUNCTION__);
			return ret;
		}

		/*Set LowerLayer for Ethernet.Link*/
		if((ret = zcfgFeObjStructGet(RDM_OID_ETH_LINK, &objIid, (void **)&ethLinkObj)) == ZCFG_SUCCESS) {
			ethLinkObj->Enable = true;
			strcpy(ethLinkObj->LowerLayers, wanIntfObj);
			if((ret = zcfgFeObjStructSet(RDM_OID_ETH_LINK, &objIid, (void *)ethLinkObj, NULL)) != ZCFG_SUCCESS) {
				printf("%s : Set Ethernet.Link LowerLayers Fail\n", __FUNCTION__);
			}

			zcfgFeObjStructFree(ethLinkObj);
		}

		/*Hard coding here, only one WANConnectionDevice.i will exist under InternetGatewayDevice.WANDevice.i if type is Ethernet*/
		*idx = 1;
	}

	return ret;
}
/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
zcfgRet_t WANConnDevObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char tr181Obj[48] = {0};
	char wanLinkPathName[32] = {0};
	char wanIpConnName[128] = {0};
	char wanPppConnName[128] = {0};
	uint32_t  wanLinkOid = 0, ipcount = 0, pppcount = 0, c = 0;
	objIndex_t wanLinkIid;
	struct json_object *tr98Jobj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	/*Check if WANConnectionDevice.i exists or not*/
	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, wanLinkPathName)) != ZCFG_SUCCESS) {
		return ret;
	}

	if((ret = WANConnDevObjGet(tr98FullPathName, 0, &tr98Jobj)) != ZCFG_SUCCESS) {
		return ret;
	}

	ipcount = json_object_get_int(json_object_object_get(tr98Jobj, "WANIPConnectionNumberOfEntries"));
	pppcount = json_object_get_int(json_object_object_get(tr98Jobj, "WANPPPConnectionNumberOfEntries"));

	json_object_put(tr98Jobj);

	/*Delete WANIPConnection*/
	for(c = 1; c <= ipcount; c++) {
		sprintf(wanIpConnName, "%s.WANIPConnection.1", tr98FullPathName);
		if(WANIpConnObjDel(wanIpConnName) != ZCFG_SUCCESS) {
			printf("%s : Delete %s fail\n", __FUNCTION__, wanIpConnName);
			return ZCFG_INTERNAL_ERROR;
		}
	}

	/*Delete WANPPPConnection*/
	for(c = 1; c <= pppcount; c++) {
		sprintf(wanPppConnName, "%s.WANPPPConnection.1", tr98FullPathName);
		if(WANPppConnObjDel(wanPppConnName) != ZCFG_SUCCESS) {
			printf("%s : Delete %s fail\n", __FUNCTION__, wanPppConnName);
			return ZCFG_INTERNAL_ERROR;
		}
		else {
			printf("%s : Delete %s Success\n", __FUNCTION__, wanPppConnName);
		}
	}

	printf("%s : WAN Link %s\n", __FUNCTION__, wanLinkPathName);
	sprintf(tr181Obj, "Device.%s", wanLinkPathName);
	wanLinkOid = zcfgFeObjNameToObjId(tr181Obj, &wanLinkIid);

	ret = zcfgFeObjJsonDel(wanLinkOid, &wanLinkIid, NULL);
	if(ret != ZCFG_SUCCESS) {
		printf("%s : Delete Object Fail\n", __FUNCTION__);	
	}

	return ret;
}

/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANDSLLinkConfig

    Related object in TR181:
    Device.ATM.Link.i
    Device.ATM.Link.i.Stats.
    Device.ATM.Link.i.QoS
 */
zcfgRet_t WANDslLinkConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char atmLink[24] = {0};
	objIndex_t atmLinkIid;
	struct json_object *atmLinkJobj = NULL, *atmLinkStJobj = NULL, *atmLinkQosJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;	
	
	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANDSLLinkConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, atmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(atmLink, "ATM") == NULL) {
		printf("%s : Not a ATM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	IID_INIT(atmLinkIid);
	sscanf(atmLink, "ATM.Link.%hhu", &atmLinkIid.idx[0]);
	atmLinkIid.level = 1;

	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_LINK, &atmLinkIid, &atmLinkJobj)) != ZCFG_SUCCESS)
		return ret;

	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_LINK_ST, &atmLinkIid, &atmLinkStJobj)) != ZCFG_SUCCESS) {
		json_object_put(atmLinkJobj);	
		return ret;
	}

	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_LINK_QOS, &atmLinkIid, &atmLinkQosJobj)) != ZCFG_SUCCESS) {
		json_object_put(atmLinkStJobj);
		json_object_put(atmLinkJobj);
		return ret;
	}

	/*fill up tr98 WANDSLLinkConfig object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(atmLinkJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
			
		paramValue = json_object_object_get(atmLinkQosJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(strstr(paramList->name, "ATM") != NULL) {
			ptr = paramList->name + 3;

			paramValue = json_object_object_get(atmLinkStJobj, ptr);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}				

			paramValue = json_object_object_get(atmLinkJobj, ptr);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			paramValue = json_object_object_get(atmLinkQosJobj, ptr);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		if(strcmp(paramList->name, "ATMQoS") == 0) {
			paramValue = json_object_object_get(atmLinkQosJobj, "QoSClass");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		/*End of special case*/

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}
		
	json_object_put(atmLinkJobj);
	json_object_put(atmLinkStJobj);
	json_object_put(atmLinkQosJobj);

	return ret;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANDSLLinkConfig

    Related object in TR181:
    Device.ATM.Link.i
    Device.ATM.Link.i.QoS
 */
zcfgRet_t WANDslLinkConfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char atmLink[32] = {0};
	objIndex_t atmLinkIid;
	struct json_object *atmLinkJobj = NULL, *atmLinkQosJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANDSLLinkConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, atmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(atmLink, "ATM") == NULL) {
		printf("%s : Not a ATM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	IID_INIT(atmLinkIid);
	sscanf(atmLink, "ATM.Link.%hhu", &atmLinkIid.idx[0]);
	atmLinkIid.level = 1;

	/*Get Device.ATM.Link.i*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_LINK, &atmLinkIid, &atmLinkJobj)) != ZCFG_SUCCESS)
		return ret;	

	/*Get Device.ATM.Link.i.QoS*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_LINK_QOS, &atmLinkIid, &atmLinkQosJobj)) != ZCFG_SUCCESS) {
		json_object_put(atmLinkJobj);
		return ret;
	}

	if(multiJobj){
		tmpObj = atmLinkQosJobj;
		atmLinkQosJobj = NULL;
		atmLinkQosJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ATM_LINK_QOS, &atmLinkIid, multiJobj, tmpObj);
		json_object_put(tmpObj);

		tmpObj = atmLinkJobj;
		atmLinkJobj = NULL;
		atmLinkJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ATM_LINK, &atmLinkIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
	}
		
	/*write tr181 Device.ATM.Link.i and Device.ATM.Link.i.QoS object*/
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANDSLLinkConfig to Device.ATM.Link.i*/
			tr181ParamValue = json_object_object_get(atmLinkJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(atmLinkJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*Write value from WANDSLLinkConfig to Device.ATM.Link.i.QoS*/
			tr181ParamValue = json_object_object_get(atmLinkQosJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(atmLinkQosJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
			if(strstr(paramList->name, "ATM") != NULL) {
				ptr = paramList->name + 3;
			
				tr181ParamValue = json_object_object_get(atmLinkJobj, ptr);
				if(tr181ParamValue != NULL) {
					json_object_object_add(atmLinkJobj, ptr, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}

				tr181ParamValue = json_object_object_get(atmLinkQosJobj, ptr);
				if(tr181ParamValue != NULL) {
					json_object_object_add(atmLinkQosJobj, ptr, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
				
			if(strcmp(paramList->name, "ATMQoS") == 0) {
				tr181ParamValue = json_object_object_get(atmLinkQosJobj, "QoSClass");
				if(tr181ParamValue != NULL) {
					json_object_object_add(atmLinkQosJobj, "QoSClass", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
			/*End of special case*/
			/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;
		}
		else {
			paramList++;
		}
	} /*Edn while*/
		
	if(multiJobj == NULL){
		/*Set Device.ATM.Link.i.QoS first*/
		if((ret = zcfgFeObjJsonSet(RDM_OID_ATM_LINK_QOS, &atmLinkIid, atmLinkQosJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.ATM.Link.i.QoS fail\n", __FUNCTION__);
			json_object_put(atmLinkJobj);
			json_object_put(atmLinkQosJobj);
			return ret;
		}

		/*Set Device.ATM.Link.i*/
		if((ret = zcfgFeObjJsonSet(RDM_OID_ATM_LINK, &atmLinkIid, atmLinkJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.ATM.Link.i fail\n", __FUNCTION__);
			json_object_put(atmLinkJobj);
			json_object_put(atmLinkQosJobj);
			return ret;
		}
		json_object_put(atmLinkJobj);
		json_object_put(atmLinkQosJobj);
	}

	return ZCFG_SUCCESS;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPTMLinkConfig

    Related object in TR181:
    Device.PTM.Link.i
 */
zcfgRet_t WANPtmLinkConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char ptmLink[24] = {0};
	objIndex_t ptmLinkIid;
	struct json_object *ptmLinkJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANPTMLinkConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ptmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(ptmLink, "PTM") == NULL) {
		printf("%s : Not a PTM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	/*Get related tr181 objects*/
	IID_INIT(ptmLinkIid);
	sscanf(ptmLink, "PTM.Link.%hhu", &ptmLinkIid.idx[0]);
	ptmLinkIid.level = 1;

	/*Get Device.PTM.Link.i*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_PTM_LINK, &ptmLinkIid, &ptmLinkJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(ptmLinkJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}

	json_object_put(ptmLinkJobj);

	return ZCFG_SUCCESS;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPTMLinkConfig

    Related object in TR181:
    Device.PTM.Link.i
 */
zcfgRet_t WANPtmLinkConfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char ptmLink[32] = {0};
	tr98Parameter_t *paramList = NULL;
	objIndex_t ptmLinkIid;
	struct json_object *ptmLinkJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANPTMLinkConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ptmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(ptmLink, "PTM") == NULL) {
		printf("%s : Not a PTM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	IID_INIT(ptmLinkIid);
	sscanf(ptmLink, "PTM.Link.%hhu", &ptmLinkIid.idx[0]);
	ptmLinkIid.level = 1;

	/*Get Device.PTM.Link.i*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_PTM_LINK, &ptmLinkIid, &ptmLinkJobj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = ptmLinkJobj;
		ptmLinkJobj = NULL;
		ptmLinkJobj = zcfgFeJsonMultiObjAppend(RDM_OID_PTM_LINK, &ptmLinkIid, multiJobj, tmpObj);
	}
	
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANPTMLinkConfig to Device.PTM.Link.i*/
			tr181ParamValue = json_object_object_get(ptmLinkJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ptmLinkJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		paramList++;	
	} /*Edn while*/

	/*Set Device.PTM.Link.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_PTM_LINK, &ptmLinkIid, ptmLinkJobj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(ptmLinkJobj);
			return ret;
		}
		json_object_put(ptmLinkJobj);
	}

	return ZCFG_SUCCESS;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPTMLinkConfig.Stats

    Related object in TR181:
    Device.PTM.Link.i.Stats
 */
zcfgRet_t WANPtmLinkConfStObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char ptmLink[24] = {0};
	objIndex_t ptmLinkIid;
	struct json_object *ptmLinkStJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANPTMLinkConfig.Stats");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ptmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(ptmLink, "PTM") == NULL) {
		printf("%s : Not a PTM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}

	/*Get related tr181 objects*/
	IID_INIT(ptmLinkIid);
	sscanf(ptmLink, "PTM.Link.%hhu", &ptmLinkIid.idx[0]);
	ptmLinkIid.level = 1;

	if((ret = zcfgFeObjJsonGet(RDM_OID_PTM_LINK_ST, &ptmLinkIid, &ptmLinkStJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(ptmLinkStJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(!strcmp(paramList->name, "FramesSent")) { 
			paramValue = json_object_object_get(ptmLinkStJobj, "PacketsSent");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}	
		else if(!strcmp(paramList->name, "FramesReceived")) {
			paramValue = json_object_object_get(ptmLinkStJobj, "PacketsReceived");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}	
		else if(!strcmp(paramList->name, "OOSNearEnd") || !strcmp(paramList->name, "OOSFarEnd")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(0));
			paramList++;
			continue;
		}

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}	

	json_object_put(ptmLinkStJobj);

	return ZCFG_SUCCESS;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANEthernetLinkConfig

    Related object in TR181:
    Device.Ethernet.Link
 */
zcfgRet_t WANEthLinkConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char ethLink[32] = {0};
	objIndex_t objIid;
	rdm_EthLink_t *ethLinkObj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANEthernetLinkConfig");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ethLink)) == ZCFG_SUCCESS) {
		if(strstr(ethLink, "Ethernet") == NULL) {
			printf("%s : Not an Ethernet Link\n", __FUNCTION__);
			return ZCFG_NO_SUCH_OBJECT;
		}

		IID_INIT(objIid);
		sscanf(ethLink, "Ethernet.Link.%hhu", &objIid.idx[0]);
		objIid.level = 1;

		/*Get Ethernet.Link.i*/
		if(zcfgFeObjStructGet(RDM_OID_ETH_LINK, &objIid, (void **)&ethLinkObj) == ZCFG_SUCCESS) {
			*tr98Jobj = json_object_new_object();

			if(!strcmp(ethLinkObj->Status, "Up") || !strcmp(ethLinkObj->Status, "Down")) {
				json_object_object_add(*tr98Jobj, "EthernetLinkStatus", json_object_new_string(ethLinkObj->Status));
			}
			else {
				json_object_object_add(*tr98Jobj, "EthernetLinkStatus", json_object_new_string("Unavailable"));
			}
			zcfgFeObjStructFree(ethLinkObj);
		}
		else {
			printf("%s : Can't get Ethernet.Link object\n", __FUNCTION__);
			return ZCFG_INTERNAL_ERROR;
		}
	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv4Address.i
 */
zcfgRet_t WANIpConnObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	objIndex_t ipIfaceIid, ipv4AddrIid;
	objIndex_t dnsSrvIid;
	struct json_object *ipIfaceJobj = NULL, *ipAddrJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *dnsSrvJobj = NULL;
	tr98Parameter_t *paramList = NULL;
	char pmPath[256] = {0};
	char tmp[256] = {0};
	int numOfEntries = 0;
	int i;
	char *connStatus = NULL;
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char typeBuf[20] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}

	IID_INIT(ipIfaceIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipIfaceIid.idx[0]);
	ipIfaceIid.level = 1;

	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE, &ipIfaceIid, &ipIfaceJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface Fail\n", __FUNCTION__);
		return ret;
	}

	/* Get Device.IP.Interface.i.IPv4Address.i */
	memcpy(&ipv4AddrIid, &ipIfaceIid, sizeof(objIndex_t));
	ipv4AddrIid.level++;
	ipv4AddrIid.idx[1] = 1;

	if(zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V4_ADDR, &ipv4AddrIid, &ipAddrJobj) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_DEBUG, "%s : Can't get IPv4Address.i Object\n", __FUNCTION__);
		ipAddrJobj = NULL;
	}
	else {
		zcfgLog(ZCFG_LOG_DEBUG, "%s : IPv4Address.i %s\n", __FUNCTION__, json_object_to_json_string(ipAddrJobj));
	}

	/*DNSServer*/
	IID_INIT(dnsSrvIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, &dnsSrvJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Type")));
		if(!strcmp(ipIface, ifBuf) && (!strcmp("DHCPv6", typeBuf) || !strcmp("RouterAdvertisement", typeBuf))){
			break;
		}
		else {
			json_object_put(dnsSrvJobj);
			dnsSrvJobj = NULL;
		}
	}	

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipIfaceJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		if(ipAddrJobj != NULL) {
			paramValue = json_object_object_get(ipAddrJobj, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		/*special case*/
		if(!strcmp(paramList->name, "ExternalIPAddress")) {
			if(ipAddrJobj != NULL) {
				paramValue = json_object_object_get(ipAddrJobj, "IPAddress");
				if(paramValue != NULL) {
					json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}

				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
				paramList++;
				continue;
			}
		}
		else if(!strcmp(paramList->name, "SubnetMask")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "NATEnabled")) {
			natInfoSet(ipIface, *tr98Jobj);
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "DefaultGateway")) {
			defaultGwInfoSet(ipIface, *tr98Jobj);
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "DNSEnabled")) {
			/*Also set DNSServers here*/
			dnsInfoSet(ipIface, *tr98Jobj);
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "PossibleConnectionTypes")) {
			paramValue = json_object_object_get(ipIfaceJobj, "X_ZYXEL_PossibleConnectionTypes");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		else if(!strcmp(paramList->name, "ConnectionType")) {
			paramValue = json_object_object_get(ipIfaceJobj, "X_ZYXEL_ConnectionType");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		else if(!strcmp(paramList->name, "PortMappingNumberOfEntries")){
			for(i = 1; i<=254; i++){
				snprintf(pmPath, sizeof(pmPath), "%s.PortMapping.%d", tr98FullPathName, i);
				if(zcfgFe98To181MappingNameGet(pmPath, tmp) == ZCFG_SUCCESS) {
					numOfEntries++;
				}
			}
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(numOfEntries));
			paramList++;
			continue;			
		}
		else if(!strcmp(paramList->name, "ConnectionStatus")) {
			paramValue = json_object_object_get(ipIfaceJobj, "Status");
			if(paramValue != NULL) {
				connStatus = json_object_get_string(paramValue);
				if(!strcmp(connStatus, "Up"))
					json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("Connected"));
				else if (!strcmp(connStatus, "Down") ||!strcmp(connStatus, "LowerLayerDown"))
					json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("Disconnected"));
				else
					json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("Unconfigured"));
			}
			else
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("Unconfigured"));

			paramList++;
			continue;
		}		
#ifdef IPV6INTERFACE_PROFILE		
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Enable")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6Enable");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Status")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6Status");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6AddressNumberOfEntries")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6AddressNumberOfEntries");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6PrefixNumberOfEntries")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6PrefixNumberOfEntries");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}		
		else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSEnabled") == 0){
			if(dnsSrvJobj){
				paramValue = json_object_object_get(dnsSrvJobj, "Enable");
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			}
			else{	
				//json_object_object_add(*tr98Jobj, paramList->name, json_object_new_boolean(0));
			}
			paramList++;	
			continue;
		}
		else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSServers") == 0){
			if(dnsSrvJobj){
				paramValue = json_object_object_get(dnsSrvJobj, "DNSServer");
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			}
			else{
				//json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			paramList++;	
			continue;
		
		}		
#endif

		/*Not defined in tr181, give it a default value*/
		if(!strcmp(paramList->name, "LastConnectionError")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("ERROR_NONE"));
		}
		else if(!strcmp(paramList->name, "ConnectionTrigger")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("On-Demand"));
		}
		else if(!strcmp(paramList->name, "RouteProtocolRx")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string("Off"));
		}
		else if(!strcmp(paramList->name, "ShapingRate")) {
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(-1));
		}
		else {
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			zcfgFeTr98DefaultValueSet(*tr98Jobj, paramList->name, paramList->type);
		}

		paramList++;
	}

	json_object_put(ipIfaceJobj);
	if(ipAddrJobj != NULL)
		json_object_put(ipAddrJobj);
	if(dnsSrvJobj){
		json_object_put(dnsSrvJobj);
	}

	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv4Address.i
 */
zcfgRet_t WANIpConnObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char devIpIface[32] = {0};
	objIndex_t ipIfaceIid;
	objIndex_t dnsSrvIid, dnsSrvV6Iid;
	struct json_object *ipIfaceJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	struct json_object *dnsSrvJobj = NULL, *dnsSrvV6Jobj = NULL;
	const char *addrType = NULL, *connType = NULL;
	tr98Parameter_t *paramList = NULL;
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char typeBuf[20] = {0};

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	//sprintf(devIpIface, "Device.%s", ipIface);
	sprintf(devIpIface, "%s", ipIface);
	IID_INIT(ipIfaceIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipIfaceIid.idx[0]);
	ipIfaceIid.level = 1;

	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE, &ipIfaceIid, &ipIfaceJobj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = ipIfaceJobj;
		ipIfaceJobj = NULL;
		ipIfaceJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE, &ipIfaceIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
	}

	/*DNSServer*/
	IID_INIT(dnsSrvV6Iid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvV6Iid, &dnsSrvV6Jobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvV6Jobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvV6Jobj, "Type")));
		if(!strcmp(ipIface, ifBuf) && (!strcmp("DHCPv6", typeBuf) || !strcmp("RouterAdvertisement", typeBuf))){
			break;
		}
		else {
			json_object_put(dnsSrvV6Jobj);
			dnsSrvV6Jobj = NULL;
		}
	}	
	IID_INIT(dnsSrvIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, &dnsSrvJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Type")));
		if(!strcmp(ipIface, ifBuf) && strcmp("DHCPv6", typeBuf) && strcmp("RouterAdvertisement", typeBuf)){
			break;
		}
		else {
			json_object_put(dnsSrvJobj);
			dnsSrvJobj = NULL;
		}
	}	


	if(multiJobj){
		if(dnsSrvV6Jobj){
			tmpObj = dnsSrvV6Jobj;
			dnsSrvV6Jobj = NULL;
			dnsSrvV6Jobj = zcfgFeJsonMultiObjAppend(RDM_OID_DNS_CLIENT_SRV, &dnsSrvV6Iid, multiJobj, tmpObj);			
			json_object_put(tmpObj);
		}
		if(dnsSrvJobj){
			tmpObj = dnsSrvJobj;
			dnsSrvJobj = NULL;
			dnsSrvJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, multiJobj, tmpObj);			
			json_object_put(tmpObj);
		}
	}

	paramValue = json_object_object_get(tr98Jobj, "AddressingType");
	addrType = json_object_get_string(paramValue);

	paramValue = json_object_object_get(tr98Jobj, "ConnectionType");
	connType = json_object_get_string(paramValue);

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipIfaceJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipIfaceJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
			if(!strcmp(paramList->name, "ConnectionType")) {
				json_object_object_add(ipIfaceJobj, "X_ZYXEL_ConnectionType", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(!strcmp(paramList->name, "DNSEnabled")){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "Enable", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
			else if(!strcmp(paramList->name, "DNSServers")){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "DNSServer", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
			else if(!strcmp(paramList->name, "X_ZYXEL_DNSType")){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "X_ZYXEL_Type", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}			
#ifdef IPV6INTERFACE_PROFILE		
			else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Enable")) {
				json_object_object_add(ipIfaceJobj, "IPv6Enable", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSEnabled") == 0){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "Enable", JSON_OBJ_COPY(paramValue));
					paramList++;	
					continue;
			}
		}
			else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSServers") == 0){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "DNSServers", JSON_OBJ_COPY(paramValue));
					paramList++;	
					continue;
				}
			}			
#endif				
		}
		paramList++;	
	}

	if(!strcmp(connType, "IP_Routed")) {
		/*Set IP Address*/
		ret = ipaddrSet(devIpIface, &ipIfaceIid, addrType, tr98Jobj);
	}

	/*Set Device.IP.Interface.i*/
	if(multiJobj){
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIfaceIid, ipIfaceJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.i Fail\n", __FUNCTION__);
			json_object_put(ipIfaceJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_DEBUG, "%s : Set Device.IP.Interface.i Success\n", __FUNCTION__);
		}
		json_object_put(ipIfaceJobj);
	}

	return ret;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i
 *
 *   Related object in TR181:
 */
zcfgRet_t WANIpConnObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char wanIntfObj[128] = {0};
	char wanLinkObj[128] = {0};
	char wanIpConnObj[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ethLinkPathName[32] = {0};
	char ipIfacePathName[32] = {0};
	char higherLayer[64] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	uint32_t  wanLinkOid = 0;
	objIndex_t wanLinkIid;
	char *ptr = NULL;
	rdm_AtmLink_t *atmLinkObj = NULL;
	rdm_PtmLink_t *ptmLinkObj = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANConnectionDevice");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanIntfObj)) != ZCFG_SUCCESS) {
		return ret;
	}

	/* wanIntfObj will be DSL.Channel.i or Ethernet.Interface.i */
	/* Check it's DSL or Ethernet first */
	if(strstr(wanIntfObj, "DSL") != NULL) { // DSL WAN
		strcpy(tr98TmpName, tr98FullPathName);
		ptr = strstr(tr98TmpName, ".WANIPConnection");
		*ptr = '\0';

		/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
		if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanLinkObj)) != ZCFG_SUCCESS) {
			return ret;
		}
			
		/* wanLinkObj will be ATM.Link or PTM.Link */
		IID_INIT(wanLinkIid);
		sprintf(tr181Obj, "Device.%s", wanLinkObj);
		wanLinkOid = zcfgFeObjNameToObjId(tr181Obj, &wanLinkIid);

		if(wanLinkOid == RDM_OID_ATM_LINK) {
			printf("ATM Link\n");
			if((ret = zcfgFeObjStructGet(RDM_OID_ATM_LINK, &wanLinkIid, (void **)&atmLinkObj)) != ZCFG_SUCCESS) {
				return ret;
			}

			/*Try to get the higher layer of ATM.Link*/
			ret = zcfgFeTr181IfaceStackHigherLayerGet(wanLinkObj, higherLayer);
			if(ret == ZCFG_NO_SUCH_OBJECT) {
				if(strcmp(atmLinkObj->LinkType, "EoA") == 0) {
					/*Add Device.Ethernet.Link.i*/
					if((ret = ethLinkAdd(ethLinkPathName, wanLinkObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					/*VLAN Consideration in the future*/

					/*Add Device.IP.Interface.i*/
					if((ret = ipIfaceAdd(ipIfacePathName, ethLinkPathName)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					if((ret = zcfgFe181To98MappingNameGet(ipIfacePathName, wanIpConnObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					sscanf(wanIpConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%d", idx);
				}
				else if(strcmp(atmLinkObj->LinkType, "IPoA") == 0) {
					printf("ATM Link type is IPoA\n");
					/*Add Device.IP.Interface.i ?*/
				}
				else if(strcmp(atmLinkObj->LinkType, "PPPoA") == 0) {
					printf("ATM Link type is PPPoA\n");
					/*Add Device.PPP.Interface.i and Device.IP.Interface.i ?*/
				}
				else {
					printf("ATM Link type %s not supported\n", atmLinkObj->LinkType);
				}
			}
			else {
				/*Ethernet.Link already exists*/
				if(strstr(higherLayer, "Ethernet.Link") != NULL) {
					printf("Ethernet.Link already exists, only add Device.IP.Interface\n");
					/*Add Device.IP.Interface.i*/
					if((ret = ipIfaceAdd(ipIfacePathName, higherLayer)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					if((ret = zcfgFe181To98MappingNameGet(ipIfacePathName, wanIpConnObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					sscanf(wanIpConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%d", idx);
				}
				else{
					printf("%s : Unknown HigherLayers of ATM.Link\n", __FUNCTION__);
				}
			}
			zcfgFeObjStructFree(atmLinkObj);
		}
		else if(wanLinkOid == RDM_OID_PTM_LINK) {
			printf("PTM Link\n");
			if((ret = zcfgFeObjStructGet(RDM_OID_PTM_LINK, &wanLinkIid, (void **)&ptmLinkObj)) != ZCFG_SUCCESS) {
				return ret;
			}

			/*Try to get the higher layer of PTM.Link*/
			ret = zcfgFeTr181IfaceStackHigherLayerGet(wanLinkObj, higherLayer);
			if(ret == ZCFG_NO_SUCH_OBJECT) {
				/*Add Device.Ethernet.Link.i*/
				if((ret = ethLinkAdd(ethLinkPathName, wanLinkObj)) != ZCFG_SUCCESS) {
					zcfgFeObjStructFree(ptmLinkObj);
					return ret;
				}

				/*VLAN Consideration in the future*/

				/*Add Device.IP.Interface.i*/
				if((ret = ipIfaceAdd(ipIfacePathName, ethLinkPathName)) != ZCFG_SUCCESS) {
					zcfgFeObjStructFree(ptmLinkObj);
					printf("%s : Add Device.IP.Interface.i fail\n", __FUNCTION__);
					return ret;
				}

				if((ret = zcfgFe181To98MappingNameGet(ipIfacePathName, wanIpConnObj)) != ZCFG_SUCCESS) {
					zcfgFeObjStructFree(ptmLinkObj);
					return ret;
				}

				sscanf(wanIpConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%d", idx);
			}
			else {
				/*Ethernet.Link already exists*/
				if(strstr(higherLayer, "Ethernet.Link") != NULL) {
					printf("Ethernet.Link already exists, only add Device.IP.Interface\n");
					/*Add Device.IP.Interface.i*/
					if((ret = ipIfaceAdd(ipIfacePathName, higherLayer)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(ptmLinkObj);
						return ret;
					}

					if((ret = zcfgFe181To98MappingNameGet(ipIfacePathName, wanIpConnObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(ptmLinkObj);
						return ret;
					}

					sscanf(wanIpConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%d", idx);
				}
				else{
					printf("%s : Unknown HigherLayers of PTM.Link\n", __FUNCTION__);
				}	
			}

			zcfgFeObjStructFree(ptmLinkObj);
		}
		else {
			printf("%s : Unknown Link Type\n", __FUNCTION__);
		}
	}
	else if(strstr(wanIntfObj, "Ethernet") != NULL) { // Ethernet WAN
		printf("Ethernet WAN\n");
		/*Try to get the higher layer of Ethernet.Interface*/
		ret = zcfgFeTr181IfaceStackHigherLayerGet(wanIntfObj, wanLinkObj);
		if(ret == ZCFG_NO_SUCH_OBJECT) {
			/*It should not happen here*/
			return ret;
		}

		/*Add Device.IP.Interface.i*/
		if((ret = ipIfaceAdd(ipIfacePathName, wanLinkObj)) != ZCFG_SUCCESS) {
			return ret;
		}

		if((ret = zcfgFe181To98MappingNameGet(ipIfacePathName, wanIpConnObj)) != ZCFG_SUCCESS) {
			return ret;
		}

		sscanf(wanIpConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%d", idx);
	}

	return ret;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i
 *
 *   Related object in TR181:
 */
zcfgRet_t WANIpConnObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	objIndex_t ipIfaceIid;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

        if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipIfaceIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipIfaceIid.idx[0]);
	ipIfaceIid.level = 1;

	ret = zcfgFeObjJsonDel(RDM_OID_IP_IFACE, &ipIfaceIid, NULL);
	if(ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete Object Fail\n", __FUNCTION__);	
	}

	return ret;
}

/*
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient
 *
 *   Related object in TR181:
 *   Device.DHCPv4.Client.i
 */
zcfgRet_t DhcpClientObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ipIface[32] = {0};
	char *ptr = NULL;
	objIndex_t objIid;
	rdm_Dhcpv4Client_t *dhcpcObj = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".DHCPClient");
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(objIid);
	while((ret = zcfgFeObjStructGetNext(RDM_OID_DHCPV4_CLIENT, &objIid, (void **)&dhcpcObj)) == ZCFG_SUCCESS) {
		if(!strcmp(dhcpcObj->Interface, ipIface)) {
			*tr98Jobj = json_object_new_object();
			json_object_object_add(*tr98Jobj, "SentDHCPOptionNumberOfEntries", json_object_new_int(dhcpcObj->SentOptionNumberOfEntries));
			json_object_object_add(*tr98Jobj, "ReqDHCPOptionNumberOfEntries", json_object_new_int(dhcpcObj->ReqOptionNumberOfEntries));
			zcfgFeObjStructFree(dhcpcObj);
			break;
		}
		
		zcfgFeObjStructFree(dhcpcObj);
	}

	return ZCFG_SUCCESS;
}
/*
 *   InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient.SentDHCPOption.i.
 *
 *   Related object in TR181:
 *   Device.DHCPv4.Client.i.SentOption.i
 */
zcfgRet_t DhcpClientSentOptObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;
	struct json_object *optObj = NULL;
	struct json_object *paramValue = NULL;
	bool found = false;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	/* get parent DHCP client */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	/* obtain index of dhcp option */
	memcpy(&optIid, &dhcpcIid, sizeof(objIndex_t));
	optIid.level++;
	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%*d.DHCPClient.SentDHCPOption.%hhu", &optIid.idx[optIid.level - 1]);

	if(optIid.idx[optIid.level - 1] == 0){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to obtain index of DHCPClient.SentDHCPOption.i\n", __FUNCTION__);
		return ZCFG_INVALID_ARGUMENTS;
	}

	/* get child DHCP client sent options */
	if((ret = zcfgFeObjJsonGet(RDM_OID_DHCPV4_SENT_OPT, &optIid, &optObj)) == ZCFG_SUCCESS){
		*tr98Jobj = json_object_new_object();
		paramList = tr98Obj[handler].parameter;
		while(paramList->name != NULL) {
			/* get parameter value from tr181 */
			paramValue = json_object_object_get(optObj, paramList->name);

			/* write it to tr098 json object */
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
			}
		}
		zcfgFeJsonObjFree(optObj);
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t DhcpClientSentOptObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;
	struct json_object *optObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	/* get parent DHCP client */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	/* obtain index of dhcp option */
	memcpy(&optIid, &dhcpcIid, sizeof(objIndex_t));
	optIid.level++;
	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%*d.DHCPClient.SentDHCPOption.%hhu", &optIid.idx[optIid.level - 1]);

	if(optIid.idx[optIid.level - 1] == 0){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to obtain index of DHCPClient.SentDHCPOption.i\n", __FUNCTION__);
		return ZCFG_INVALID_ARGUMENTS;
	}

	/* get child DHCP client sent options */
	if((ret = zcfgFeObjJsonGet(RDM_OID_DHCPV4_SENT_OPT, &optIid, &optObj)) == ZCFG_SUCCESS){
		/* if multiple set is required, just appended JSON to multiJobj */
		if(multiJobj){
			tmpObj = optObj;
			optObj = NULL;
			optObj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV4_SENT_OPT, &optIid, multiJobj, tmpObj);
		}

		/* set(update) value to target object */
		if(optObj){
			paramList = tr98Obj[handler].parameter;
			while(paramList->name != NULL) {
				/* get parameter from tr098 */
				paramValue = json_object_object_get(tr98Jobj, paramList->name);

				/* write it to tr181 json object */
				if(paramValue != NULL) {
					json_object_object_add(optObj, paramList->name, JSON_OBJ_COPY(paramValue));
				}

				paramList++;;
			}
		}

		/* is not multiple set, jsut set object immediately after update parameter value */
		if(!multiJobj){
			if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV4_SENT_OPT, &optIid, optObj, NULL)) != ZCFG_SUCCESS ) {
				zcfgLog(ZCFG_LOG_ERR, "%s : Set RDM_OID_DHCPV4_SENT_OPT object Fail with ret=%d\n", __FUNCTION__, ret);
				zcfgFeJsonObjFree(optObj);
				return ret;
			}
		}
		zcfgFeJsonObjFree(optObj);
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t DhcpClientSentOptObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;

	/* get parent Iid */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	memcpy(&optIid, &dhcpcIid, sizeof(dhcpcIid));
	
	/* add child under get parent */
	if((ret = zcfgFeObjJsonAdd(RDM_OID_DHCPV4_SENT_OPT, &optIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to add dhcp client set option with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	*idx = optIid.idx[1];

	return ZCFG_SUCCESS;
	
}


zcfgRet_t DhcpClientSentOptObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;
	
	/* get parent Iid */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	memcpy(&optIid, &dhcpcIid, sizeof(objIndex_t));
	optIid.level++;
	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%*d.DHCPClient.SentDHCPOption.%hhu", &optIid.idx[optIid.level - 1]);

	if((ret = zcfgFeObjJsonDel(RDM_OID_DHCPV4_SENT_OPT, &optIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to delete dhcpc sent option with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}

/*
 *   InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient.ReqDHCPOption.i.
 *
 *   Related object in TR181:
 *   Device.DHCPv4.Client.i.ReqOption.i
 */
zcfgRet_t DhcpClientReqOptObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;
	struct json_object *optObj = NULL;
	struct json_object *paramValue = NULL;
	bool found = false;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	/* get parent DHCP client */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	/* obtain index of dhcp option */
	memcpy(&optIid, &dhcpcIid, sizeof(objIndex_t));
	optIid.level++;
	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%*d.DHCPClient.ReqDHCPOption.%hhu", &optIid.idx[optIid.level - 1]);

	if(optIid.idx[optIid.level - 1] == 0){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to obtain index of DHCPClient.ReqDHCPOption.i\n", __FUNCTION__);
		return ZCFG_INVALID_ARGUMENTS;
	}
	
	/* get child DHCP client sent options */
	if((ret = zcfgFeObjJsonGet(RDM_OID_DHCPV4_REQ_OPT, &optIid, &optObj)) == ZCFG_SUCCESS){
		*tr98Jobj = json_object_new_object();
		paramList = tr98Obj[handler].parameter;
		while(paramList->name != NULL) {
			/* get parameter value from tr181 */
			paramValue = json_object_object_get(optObj, paramList->name);

			/* write it to tr098 json object */
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
			}
		}
		zcfgFeJsonObjFree(optObj);
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t DhcpClientReqOptObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;
	struct json_object *optObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	/* get parent DHCP client */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	/* obtain index of dhcp option */
	memcpy(&optIid, &dhcpcIid, sizeof(objIndex_t));
	optIid.level++;
	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%*d.DHCPClient.ReqDHCPOption.%hhu", &optIid.idx[optIid.level - 1]);

	if(optIid.idx[optIid.level - 1] == 0){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to obtain index of DHCPClient.ReqDHCPOption.i\n", __FUNCTION__);
		return ZCFG_INVALID_ARGUMENTS;
	}

	/* get child DHCP client sent options */
	if((ret = zcfgFeObjJsonGet(RDM_OID_DHCPV4_REQ_OPT, &optIid, &optObj)) == ZCFG_SUCCESS){
		/* if multiple set is required, just appended JSON to multiJobj */
		if(multiJobj){
			tmpObj = optObj;
			optObj = NULL;
			optObj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV4_REQ_OPT, &optIid, multiJobj, tmpObj);
		}

		/* set(update) value to target object */
		if(optObj){
			paramList = tr98Obj[handler].parameter;
			while(paramList->name != NULL) {
				/* get parameter from tr098 */
				paramValue = json_object_object_get(tr98Jobj, paramList->name);

				/* write it to tr181 json object */
				if(paramValue != NULL) {
					json_object_object_add(optObj, paramList->name, JSON_OBJ_COPY(paramValue));
				}

				paramList++;;
			}
		}

		/* is not multiple set, jsut set object immediately after update parameter value */
		if(!multiJobj){
			if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV4_REQ_OPT, &optIid, optObj, NULL)) != ZCFG_SUCCESS ) {
				zcfgLog(ZCFG_LOG_ERR, "%s : Set RDM_OID_DHCPV4_SENT_OPT object Fail with ret=%d\n", __FUNCTION__, ret);
				zcfgFeJsonObjFree(optObj);
				return ret;
			}
		}
		zcfgFeJsonObjFree(optObj);
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t DhcpClientReqOptObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;

	/* get parent Iid */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	memcpy(&optIid, &dhcpcIid, sizeof(dhcpcIid));
	
	/* add child under get parent */
	if((ret = zcfgFeObjJsonAdd(RDM_OID_DHCPV4_REQ_OPT, &optIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to add dhcp client req option with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	*idx = optIid.idx[1];

	return ZCFG_SUCCESS;
	
}


zcfgRet_t DhcpClientReqOptObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t dhcpcIid, optIid;
	
	/* get parent Iid */
	if((ret = DhcpcIidGet(tr98FullPathName, &dhcpcIid)) == ZCFG_NOT_FOUND){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to get dhcpc Iid\n", __FUNCTION__);
		return ZCFG_NOT_FOUND;
	}

	memcpy(&optIid, &dhcpcIid, sizeof(objIndex_t));
	optIid.level++;
	sscanf(tr98FullPathName, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANIPConnection.%*d.DHCPClient.ReqDHCPOption.%hhu", &optIid.idx[optIid.level - 1]);

	if((ret = zcfgFeObjJsonDel(RDM_OID_DHCPV4_REQ_OPT, &optIid, NULL)) != ZCFG_SUCCESS){
		zcfgLog(ZCFG_LOG_ERR, "%s: fail to delete dhcpc req option with ret=%d\n", __FUNCTION__, ret);
		return ret;
	}

	return ZCFG_SUCCESS;
}


/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i
 *
 *   Related object in TR181:
 *   Device.PPP.Interface.i
 *   Device.PPP.Interface.i.PPPoA
 *   Device.PPP.Interface.i.PPPoE
 *   Device.PPP.Interface.i.IPCP
 *   Device.IP.Interface.i
 */
zcfgRet_t WANPppConnObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char pppIface[32] = {0}, ipIface[32] = {0};
	tr98Parameter_t *paramList = NULL;
	uint32_t  pppConnOid = 0;
	objIndex_t pppConnIid, ipIfaceIid;
	objIndex_t dnsSrvIid;
	struct json_object *pppConnJobj = NULL, *pppoeJobj = NULL, *ipcpJobj = NULL, *ipIfaceJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *dnsSrvJobj = NULL;
	char pmPath[256] = {0};
	char tmp[256] = {0};
	int numOfEntries = 0;
	int i;
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char typeBuf[20] = {0};

	zcfgLog(ZCFG_LOG_INFO, "Enter %s\n", __FUNCTION__);

	/*find tr181 mapping object*/
	if(zcfgFe98To181MappingNameGet(tr98FullPathName, pppIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANPPPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANPPPConnection object.
		 */		
		return ZCFG_NO_MORE_INSTANCE;
	}

	zcfgLog(ZCFG_LOG_INFO, "PPP Interface object %s\n", pppIface);
	IID_INIT(pppConnIid);
	sprintf(tr181Obj, "Device.%s", pppIface);
	pppConnOid = zcfgFeObjNameToObjId(tr181Obj, &pppConnIid);

	/*Get related tr181 objects*/
	/*Get PPP.Interface.i*/
	if((ret = zcfgFeObjJsonGet(pppConnOid, &pppConnIid, &pppConnJobj)) != ZCFG_SUCCESS)
		return ret;

	/*Get PPP.Interface.i.PPPoA(gnore now)*/

	/*Get PPP.Interface.i.PPPoE*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_PPP_IFACE_PPPOE, &pppConnIid, &pppoeJobj)) != ZCFG_SUCCESS)
		return ret;

	/*Get PPP.Interface.i.IPCP*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_PPP_IFACE_IPCP, &pppConnIid, &ipcpJobj)) != ZCFG_SUCCESS)
		return ret;

	/*Get IP.Interface.i above PPP.Interface.i*/
	if(zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface) != ZCFG_SUCCESS)
		return ret;

	/*Get IP.Interface.i*/
	IID_INIT(ipIfaceIid);
	ipIfaceIid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &ipIfaceIid.idx[0]);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE, &ipIfaceIid, &ipIfaceJobj)) != ZCFG_SUCCESS)
		return ret;

	/*DNSServer*/
	IID_INIT(dnsSrvIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, &dnsSrvJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Type")));
		if(!strcmp(ipIface, ifBuf) && (!strcmp("DHCPv6", typeBuf) || !strcmp("RouterAdvertisement", typeBuf))){
			break;
		}
		else {
			json_object_put(dnsSrvJobj);
			dnsSrvJobj = NULL;
		}
	}	

	/*Fill up tr98 WANPPPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(pppConnJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(pppoeJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(ipcpJobj, paramList->name);
		if(paramValue != NULL) {
			if( !strcmp(paramList->name, "DNSServers")){// have been get before by dnsInfoSet()
				paramList++;
				continue;				
			} 
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*Is IP.Interface.i necessary here?*/

		/*special case*/
		if(strstr(paramList->name, "PPPoESessionID") != NULL) {
			paramValue = json_object_object_get(pppoeJobj, "SessionID");
		}
		else if(!strcmp(paramList->name, "PPPEncryptionProtocol")) {
			paramValue = json_object_object_get(pppConnJobj, "EncryptionProtocol");
		}
		else if(!strcmp(paramList->name, "PPPCompressionProtocol")) {
			paramValue = json_object_object_get(pppConnJobj, "PPPCompressionProtocol");
		}
		else if(!strcmp(paramList->name, "PPPoEACName")) {
			paramValue = json_object_object_get(pppoeJobj, "ACName");
		}
		else if(!strcmp(paramList->name, "PPPoEServiceName")) {
			paramValue = json_object_object_get(pppoeJobj, "ServiceName");
		}
		else if(!strcmp(paramList->name, "PPPLCPEcho")) {
			paramValue = json_object_object_get(pppConnJobj, "LCPEcho");
		}
		else if(!strcmp(paramList->name, "PPPLCPEchoRetry")) {
			paramValue = json_object_object_get(pppConnJobj, "LCPEchoRetry");
		}
		else if(!strcmp(paramList->name, "ExternalIPAddress")) {
			paramValue = json_object_object_get(ipcpJobj, "LocalIPAddress");
		}
		else if(!strcmp(paramList->name, "PPPAuthenticationProtocol")) {
			paramValue = json_object_object_get(pppConnJobj, "AuthenticationProtocol");
		}
		else if(!strcmp(paramList->name, "PossibleConnectionTypes")) {
			paramValue = json_object_object_get(pppConnJobj, "X_ZYXEL_PossibleConnectionTypes");
		}
		else if(!strcmp(paramList->name, "ConnectionType")) {
			paramValue = json_object_object_get(pppConnJobj, "X_ZYXEL_ConnectionType");
		}
		else if(!strcmp(paramList->name, "NATEnabled")) {
			natInfoSet(ipIface, *tr98Jobj);
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "DefaultGateway")) {
			defaultGwInfoSet(ipIface, *tr98Jobj);
			paramList++;
			continue;
		}
       	else if(!strcmp(paramList->name, "DNSEnabled")) {
			/*Also set DNSServers here*/
			dnsInfoSet(ipIface, *tr98Jobj);
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "PortMappingNumberOfEntries")){
			for(i = 1; i<=254; i++){
				snprintf(pmPath, sizeof(pmPath), "%s.PortMapping.%d", tr98FullPathName, i);
				if(zcfgFe98To181MappingNameGet(pmPath, tmp) == ZCFG_SUCCESS) {
					numOfEntries++;
				}
			}
			json_object_object_add(*tr98Jobj, paramList->name, json_object_new_int(numOfEntries));
			paramList++;
			continue;			
		}		
#ifdef IPV6INTERFACE_PROFILE		
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Enable")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6Enable");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Status")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6Status");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6AddressNumberOfEntries")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6AddressNumberOfEntries");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(!strcmp(paramList->name, "X_ZYXEL_IPv6PrefixNumberOfEntries")) {
			paramValue = json_object_object_get(ipIfaceJobj, "IPv6PrefixNumberOfEntries");
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
		else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSEnabled") == 0){
			if(dnsSrvJobj){
				paramValue = json_object_object_get(dnsSrvJobj, "Enable");
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			}
			else{	
				//json_object_object_add(*tr98Jobj, paramList->name, json_object_new_boolean(0));
			}
			paramList++;	
			continue;
		}
		else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSServers") == 0){
			if(dnsSrvJobj){
				paramValue = json_object_object_get(dnsSrvJobj, "DNSServer");
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			}
			else{
				//json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			paramList++;	
			continue;
		
		}						
#endif
		else {
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			zcfgFeTr98DefaultValueSet(*tr98Jobj, paramList->name, paramList->type);
			paramList++;
			continue;
		}

		if(paramValue != NULL) {		
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
		}

		paramValue = NULL;
		/*End of special case*/
		
		paramList++;	
	}

	json_object_put(pppConnJobj);
	json_object_put(pppoeJobj);
	json_object_put(ipcpJobj);
	json_object_put(ipIfaceJobj);
	if(dnsSrvJobj){
		json_object_put(dnsSrvJobj);
	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i
 *
 *   Related object in TR181:
 *   Device.PPP.Interface.i
 *   Device.PPP.Interface.i.PPPoA
 *   Device.PPP.Interface.i.PPPoE
 *   Device.PPP.Interface.i.IPCP
 */
zcfgRet_t WANPppConnObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	objIndex_t pppIfaceIid, ipIfaceIid;
	objIndex_t dnsSrvIid, dnsSrvV6Iid;
	struct json_object *pppIfaceJobj = NULL, *ipIfaceJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *dnsSrvJobj = NULL, *dnsSrvV6Jobj = NULL;
	tr98Parameter_t *paramList = NULL;
	char ifBuf[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char typeBuf[20] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	printf("TR181 object %s\n", pppIface);
	IID_INIT(pppIfaceIid);
	pppIfaceIid.level = 1;
	sscanf(pppIface, "PPP.Interface.%hhu", &pppIfaceIid.idx[0]);

	/*Get related tr181 objects*/
	/*Get PPP.Interface.i*/
	if((ret = zcfgFeObjJsonGet(RDM_OID_PPP_IFACE, &pppIfaceIid, &pppIfaceJobj)) != ZCFG_SUCCESS) {
		printf("%s : Get PPP.Interface fail\n", __FUNCTION__);
		return ZCFG_INTERNAL_ERROR;
	}

	/*Get IP.Interface.i above PPP.Interface.i*/
	if(zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(ipIfaceIid);
	ipIfaceIid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &ipIfaceIid.idx[0]);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE, &ipIfaceIid, &ipIfaceJobj)) != ZCFG_SUCCESS) {
		printf("%s : Get IP.Interface fail\n", __FUNCTION__);
		json_object_put(ipIfaceJobj);
		return ZCFG_INTERNAL_ERROR;
	}
	
	/*DNSServer*/
	IID_INIT(dnsSrvV6Iid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvV6Iid, &dnsSrvV6Jobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvV6Jobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvV6Jobj, "Type")));
		if(!strcmp(ipIface, ifBuf) && (!strcmp("DHCPv6", typeBuf) || !strcmp("RouterAdvertisement", typeBuf))){
			break;
		}
		else {
			json_object_put(dnsSrvV6Jobj);
			dnsSrvV6Jobj = NULL;
		}
	}	
	IID_INIT(dnsSrvIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, &dnsSrvJobj)) == ZCFG_SUCCESS) {
		strcpy(ifBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Interface")));
		strcpy(typeBuf, json_object_get_string(json_object_object_get(dnsSrvJobj, "Type")));
		if(!strcmp(ipIface, ifBuf) && strcmp("DHCPv6", typeBuf) && strcmp("RouterAdvertisement", typeBuf)){
			break;
		}
		else {
			json_object_put(dnsSrvJobj);
			dnsSrvJobj = NULL;
		}
	}	


	if(multiJobj){
		tmpObj = pppIfaceJobj;
		pppIfaceJobj = NULL;
		pppIfaceJobj = zcfgFeJsonMultiObjAppend(RDM_OID_PPP_IFACE, &pppIfaceIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
		tmpObj = ipIfaceJobj;
		ipIfaceJobj = NULL;
		ipIfaceJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE, &ipIfaceIid, multiJobj, tmpObj);
		json_object_put(tmpObj);

	}

	if(multiJobj){
		if(dnsSrvV6Jobj){
			tmpObj = dnsSrvV6Jobj;
			dnsSrvV6Jobj = NULL;
			dnsSrvV6Jobj = zcfgFeJsonMultiObjAppend(RDM_OID_DNS_CLIENT_SRV, &dnsSrvV6Iid, multiJobj, tmpObj);			
			json_object_put(tmpObj);
		}
		if(dnsSrvJobj){
			tmpObj = dnsSrvJobj;
			dnsSrvJobj = NULL;
			dnsSrvJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DNS_CLIENT_SRV, &dnsSrvIid, multiJobj, tmpObj);			
			json_object_put(tmpObj);
			
		}
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANPPPConnection to Device.PPP.Interface.i*/
			tr181ParamValue = json_object_object_get(pppIfaceJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(pppIfaceJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
			if(!strcmp(paramList->name, "ConnectionType")) {
				json_object_object_add(pppIfaceJobj, "X_ZYXEL_ConnectionType", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(!strcmp(paramList->name, "DNSEnabled")){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "Enable", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
			else if(!strcmp(paramList->name, "DNSServers")){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "DNSServer", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
			else if(!strcmp(paramList->name, "X_ZYXEL_DNSType")){
				if(dnsSrvJobj){
					json_object_object_add(dnsSrvJobj, "X_ZYXEL_Type", JSON_OBJ_COPY(paramValue));
					paramList++;
					continue;
				}
			}
#ifdef IPV6INTERFACE_PROFILE		
			else if(!strcmp(paramList->name, "X_ZYXEL_IPv6Enable")) {
				json_object_object_add(ipIfaceJobj, "IPv6Enable", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSEnabled") == 0){
				if(dnsSrvV6Jobj){
					json_object_object_add(dnsSrvV6Jobj, "Enable", JSON_OBJ_COPY(paramValue));
					paramList++;	
					continue;
				}
			}
			else if(strcmp( paramList->name, "X_ZYXEL_IPv6DNSServers") == 0){
				if(dnsSrvV6Jobj){
					json_object_object_add(dnsSrvV6Jobj, "DNSServers", JSON_OBJ_COPY(paramValue));
					paramList++;	
					continue;
			}
		}
#endif				
		}
		paramList++;
	}

	if(multiJobj){
	}
	else {
		if((ret = zcfgFeObjJsonSet(RDM_OID_PPP_IFACE, &pppIfaceIid, pppIfaceJobj, NULL)) != ZCFG_SUCCESS ) {
			printf("%s : Set PPP.Interface Fail\n", __FUNCTION__);
			json_object_put(pppIfaceJobj);
			return ret;
		}
		else {
			printf("%s : Set PPP.Interface Success\n", __FUNCTION__);
		}
		json_object_put(pppIfaceJobj);
	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i
 *
 *   Related object in TR181:
 */
zcfgRet_t WANPppConnObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char wanIntfObj[128] = {0};
	char wanLinkObj[128] = {0};
	char wanPppConnObj[128] = {0};
	char ethLinkPathName[32] = {0};
	char pppIfacePathName[32] = {0};
	char higherLayer[64] = {0};
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};  /*tr98TmpName is used to look up mapping table*/
	char *ptr = NULL;
	uint32_t  wanLinkOid = 0;
	objIndex_t wanLinkIid;
	rdm_AtmLink_t *atmLinkObj = NULL;
	rdm_PtmLink_t *ptmLinkObj = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANConnectionDevice");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanIntfObj)) != ZCFG_SUCCESS) {
		return ret;
	}

        /* wanIntfObj will be DSL.Channel.i or Ethernet.Interface.i */
	printf("%s : TR181 object %s\n", __FUNCTION__, wanIntfObj);

	/*Check it's DSL or Ethernet first*/
	if(strstr(wanIntfObj, "DSL") != NULL) { // DSL WAN
		printf("DSL WAN\n");
		strcpy(tr98TmpName, tr98FullPathName);
		ptr = strstr(tr98TmpName, ".WANPPPConnection");
		*ptr = '\0';

		/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
		if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, wanLinkObj)) != ZCFG_SUCCESS) {
			return ret;
		}
			
		/* wanLinkObj will be ATM.Link or PTM.Link */
		printf("TR181 object %s\n", wanLinkObj);
		IID_INIT(wanLinkIid);
		sprintf(tr181Obj, "Device.%s", wanLinkObj);
		wanLinkOid = zcfgFeObjNameToObjId(tr181Obj, &wanLinkIid);
		
		if(wanLinkOid == RDM_OID_ATM_LINK) {
			printf("ATM Link\n");
			if((ret = zcfgFeObjStructGet(RDM_OID_ATM_LINK, &wanLinkIid, (void **)&atmLinkObj)) != ZCFG_SUCCESS) {
				return ret;
			}

			/*Try to get the higher layer of ATM.Link*/
			ret = zcfgFeTr181IfaceStackHigherLayerGet(wanLinkObj, higherLayer);
			if(ret == ZCFG_NO_SUCH_OBJECT) {
				if(strcmp(atmLinkObj->LinkType, "EoA") == 0) {
					/*Add Device.Ethernet.Link.i*/
					if((ret = ethLinkAdd(ethLinkPathName, wanLinkObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					/*VLAN Consideration in the future*/

					/*Add Device.PPP.Interface.i*/
					if((ret = pppIfaceAdd(pppIfacePathName, ethLinkPathName)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					if((ret = zcfgFe181To98MappingNameGet(pppIfacePathName, wanPppConnObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					sscanf(wanPppConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANPPPConnection.%d", idx);
				}
				else if(strcmp(atmLinkObj->LinkType, "IPoA") == 0) {
					printf("ATM Link type is IPoA\n");
					/*Add Device.IP.Interface.i ?*/
				}
				else if(strcmp(atmLinkObj->LinkType, "PPPoA") == 0) {
					printf("ATM Link type is PPPoA\n");
					/*Add Device.PPP.Interface.i and Device.IP.Interface.i ?*/
				}
				else {
					printf("ATM Link type %s not supported\n", atmLinkObj->LinkType);
				}
			}
			else {
				/*Ethernet.Link already exists*/
				if(strstr(higherLayer, "Ethernet.Link") != NULL) {
					printf("%s : Ethernet.Link already exists, only add Device.PPP.Interface\n", __FUNCTION__);
					/*Add Device.PPP.Interface.i*/
					if((ret = pppIfaceAdd(pppIfacePathName, higherLayer)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					if((ret = zcfgFe181To98MappingNameGet(pppIfacePathName, wanPppConnObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(atmLinkObj);
						return ret;
					}

					sscanf(wanPppConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANPPPConnection.%d", idx);
				}
				else{
					printf("%s : Unknown HigherLayers %s\n", __FUNCTION__, higherLayer);
				}
			}
			zcfgFeObjStructFree(atmLinkObj);
		}
		else if(wanLinkOid == RDM_OID_PTM_LINK) {
			printf("PTM Link\n");
			if((ret = zcfgFeObjStructGet(RDM_OID_PTM_LINK, &wanLinkIid, (void **)&ptmLinkObj)) != ZCFG_SUCCESS) {
				return ret;
			}

			/*Try to get the higher layer of PTM.Link*/
			ret = zcfgFeTr181IfaceStackHigherLayerGet(ptmLinkObj->LowerLayers, higherLayer);
			if(ret == ZCFG_NO_SUCH_OBJECT) {
				/*Add Device.Ethernet.Link.i*/
				if((ret = ethLinkAdd(ethLinkPathName, wanLinkObj)) != ZCFG_SUCCESS) {
					zcfgFeObjStructFree(ptmLinkObj);
					return ret;
				}

				/*VLAN Consideration in the future*/

				/*Add Device.PPP.Interface.i*/
				if((ret = pppIfaceAdd(pppIfacePathName, ethLinkPathName)) != ZCFG_SUCCESS) {
					zcfgFeObjStructFree(ptmLinkObj);
					return ret;
				}

				if((ret = zcfgFe181To98MappingNameGet(pppIfacePathName, wanPppConnObj)) != ZCFG_SUCCESS) {
					zcfgFeObjStructFree(ptmLinkObj);
					return ret;
				}

				sscanf(wanPppConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANPPPConnection.%d", idx);
			}
			else {
				/*Ethernet.Link already exists*/
				if(strstr(higherLayer, "Ethernet.Link") != NULL) {
					printf("%s : Ethernet.Link already exists, only add Device.IP.Interface\n", __FUNCTION__);
					/*Add Device.PPP.Interface.i*/
					if((ret = pppIfaceAdd(pppIfacePathName, ethLinkPathName)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(ptmLinkObj);
						return ret;
					}

					if((ret = zcfgFe181To98MappingNameGet(pppIfacePathName, wanPppConnObj)) != ZCFG_SUCCESS) {
						zcfgFeObjStructFree(ptmLinkObj);
						return ret;
					}

					sscanf(wanPppConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANPPPConnection.%d", idx);
				}
				else{
					printf("%s : Unknown HigherLayers %s\n", __FUNCTION__, higherLayer);
				}	
			}

			zcfgFeObjStructFree(ptmLinkObj);
		}
		else {
			printf("Unknown Link Type\n");
		}
		
	}
	else if(strstr(wanIntfObj, "Ethernet") != NULL) { // Ethernet WAN
		printf("Ethernet WAN\n");
		/*Try to get the higher layer of Ethernet.Interface*/
		ret = zcfgFeTr181IfaceStackHigherLayerGet(wanIntfObj, wanLinkObj);
		if(ret == ZCFG_NO_SUCH_OBJECT) {
			/*It should not happen here*/
			return ret;
		}

		printf("Ethernet Link %s\n", wanLinkObj);

		/*Add Device.PPP.Interface.i*/
		if((ret = pppIfaceAdd(pppIfacePathName, wanLinkObj)) != ZCFG_SUCCESS) {
			return ret;
		}

		if((ret = zcfgFe181To98MappingNameGet(pppIfacePathName, wanPppConnObj)) != ZCFG_SUCCESS) {
			return ret;
		}

		sscanf(wanPppConnObj, "%*[^.].%*[^.].%*d.%*[^.].%*d.WANPPPConnection.%d", idx);
	}

	return ret;
}
/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i

    Related object in TR181:
 */
zcfgRet_t WANPppConnObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	char tr181Obj[128] = {0};
	char pppIfacePathName[32] = {0};
	uint32_t  pppIfaceOid = 0;
	objIndex_t pppIfaceIid, ipIfaceIid;
	rdm_IpIface_t *ipIface = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, pppIfacePathName)) != ZCFG_SUCCESS) {
		return ret;
	}
	
	printf("%s : pppIface %s\n", __FUNCTION__, pppIfacePathName);
	sprintf(tr181Obj, "Device.%s", pppIfacePathName);
	pppIfaceOid = zcfgFeObjNameToObjId(tr181Obj, &pppIfaceIid);

	IID_INIT(ipIfaceIid);
	while((ret = zcfgFeObjStructGetNext(RDM_OID_IP_IFACE, &ipIfaceIid, (void **)&ipIface)) == ZCFG_SUCCESS) {
		if(strcmp(ipIface->LowerLayers, pppIfacePathName) == 0) {
			if(zcfgFeObjStructDel(RDM_OID_IP_IFACE, &ipIfaceIid, NULL) == ZCFG_SUCCESS) {
				printf("%s : Delete IP Interface Success\n", __FUNCTION__);
			}
			else {
				printf("%s : Delete IP Interface Fail\n", __FUNCTION__);
			}
			zcfgFeObjStructFree(ipIface);
			break;
		}
		zcfgFeObjStructFree(ipIface);
	}

	ret = zcfgFeObjStructDel(RDM_OID_PPP_IFACE, &pppIfaceIid, NULL);
	if (ret == ZCFG_SUCCESS) {
		printf("%s : Delete PPP Interface Success\n", __FUNCTION__);
	}
	else {
		printf("%s : Delete PPP Interface Fail\n", __FUNCTION__);
	}

	return ret;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.PortMapping.i
 *                      InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.PortMapping.i
 *
 *   Related object in TR181:
 *   Device.NAT.PortMapping.i
 */
zcfgRet_t WANPortMappingGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char natPortMap[32] = {0};
	objIndex_t objIid;
	struct json_object *portMapJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	if(zcfgFe98To181MappingNameGet(tr98FullPathName, natPortMap) != ZCFG_SUCCESS) {
		/*  The instance number of PortMapping.i will be continuous because of the tr98 to tr181 mapping table. 
		 *  Therefore, just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this PortMapping object.
		 */	
		return ZCFG_NO_MORE_INSTANCE;
	}

	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(natPortMap, "NAT.PortMapping.%hhu", &objIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_NAT_PORT_MAPPING, &objIid, &portMapJobj)) != ZCFG_SUCCESS)
		return ret;

	/*fill up tr98 object from related tr181 objects*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write parameter value from tr181 objects to tr98 object*/		
		paramValue = json_object_object_get(portMapJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/
		if(!strcmp(paramList->name, "PortMappingEnabled")) { 
			paramValue = json_object_object_get(portMapJobj, "Enable");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}	
		else if(!strcmp(paramList->name, "PortMappingLeaseDuration")) {
			paramValue = json_object_object_get(portMapJobj, "LeaseDuration");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}	
		else if(!strcmp(paramList->name, "PortMappingProtocol")) {
			paramValue = json_object_object_get(portMapJobj, "Protocol");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
		else if(!strcmp(paramList->name, "PortMappingDescription")) {
			paramValue = json_object_object_get(portMapJobj, "Description");
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}	

	json_object_put(portMapJobj);

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.PortMapping.i
 *                      InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.PortMapping.i
 *
 *   Related object in TR181:
 *   Device.NAT.PortMapping.i
 */
zcfgRet_t WANPortMappingSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *portMapJobj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *paramValue = NULL;
	char portMap[32] = {0};
	tr98Parameter_t *paramList = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, portMap)) != ZCFG_SUCCESS) {
		return ret;
	}

	printf("%s : portMap %s\n", __FUNCTION__, portMap);

	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(portMap, "NAT.PortMapping.%hhu", &objIid.idx[0]);

	if((ret = zcfgFeObjJsonGet(RDM_OID_NAT_PORT_MAPPING, &objIid, &portMapJobj)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(multiJobj){
		tmpObj = portMapJobj;
		portMapJobj = NULL;
		portMapJobj = zcfgFeJsonMultiObjAppend(RDM_OID_NAT_PORT_MAPPING, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(portMapJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(portMapJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
			if(!strcmp(paramList->name, "PortMappingEnabled")) { 
				json_object_object_add(portMapJobj, "Enable", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(!strcmp(paramList->name, "PortMappingLeaseDuration")) {
				json_object_object_add(portMapJobj, "LeaseDuration", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(!strcmp(paramList->name, "PortMappingProtocol")) {
				json_object_object_add(portMapJobj, "Protocol", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
			else if(!strcmp(paramList->name, "PortMappingDescription")) {
				json_object_object_add(portMapJobj, "Description", JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;	
	}

	/*Set Device.NAT.PortMapping.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_NAT_PORT_MAPPING, &objIid, portMapJobj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(portMapJobj);
			return ret;
		}
		json_object_put(portMapJobj);
	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.PortMapping.i
 *                      InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.PortMapping.i
 *
 *   Related object in TR181:
 *   Device.NAT.PortMapping.i
 */
zcfgRet_t WANPortMappingAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	rdm_NatPortMapping_t *natPortMapObj = NULL;
	char tr98ConnName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char tr98PortMapName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char iface[32] = {0};
	char portMap[32] = {0};
	char *ptr = NULL;
	rdm_IpIface_t *ipIface = NULL;

	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98ConnName, tr98FullPathName);
	ptr = strstr(tr98ConnName, ".PortMapping");
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnName, iface)) != ZCFG_SUCCESS) {
		return ret;
	}
	
	//if PPP.Interface
	if(strstr(iface, "PPP")){
		IID_INIT(objIid);
		while((ret = zcfgFeObjStructGetNext(RDM_OID_IP_IFACE, &objIid, (void **)&ipIface)) == ZCFG_SUCCESS) {
			if(strcmp(ipIface->LowerLayers, iface) == 0) {
				memset(iface, '\0', sizeof(iface));
				snprintf(iface, sizeof(iface), "IP.Interface.%d",  objIid.idx[0]);
				zcfgFeObjStructFree(ipIface);
				break;
			}
			zcfgFeObjStructFree(ipIface);
		}

	}

	IID_INIT(objIid);
	if((ret = zcfgFeObjStructAdd(RDM_OID_NAT_PORT_MAPPING, &objIid, NULL)) != ZCFG_SUCCESS) {
		printf("%s : Add NAT.PortMapping Fail.\n", __FUNCTION__);
		return ret;
	}

	if(zcfgFeObjStructGet(RDM_OID_NAT_PORT_MAPPING, &objIid, (void **)&natPortMapObj) == ZCFG_SUCCESS) {
		strcpy(natPortMapObj->Interface, iface);
		if(zcfgFeObjStructSet(RDM_OID_NAT_PORT_MAPPING, &objIid, (void *)natPortMapObj, NULL) != ZCFG_SUCCESS) {
			printf("%s : Set NAT.PortMapping Fail.\n", __FUNCTION__);	
		}
		zcfgFeObjStructFree(natPortMapObj);
		sprintf(portMap, "NAT.PortMapping.%hhu", objIid.idx[0]);
		
		if((ret = zcfgFe181To98MappingNameGet(portMap, tr98PortMapName)) != ZCFG_SUCCESS) {
			return ret;
		}
		
		sscanf(tr98PortMapName, "%*[^.].%*[^.].%*d.%*[^.].%*d.%*[^.].%*d.PortMapping.%d", idx);
	}
	else {
		printf("%s : Get NAT.PortMapping Fail.\n", __FUNCTION__);
		return ZCFG_INTERNAL_ERROR;	
	}

	return ZCFG_SUCCESS;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.PortMapping.i
 *                      InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.PortMapping.i
 *
 *   Related object in TR181:
 *   Device.NAT.PortMapping.i
 */
zcfgRet_t WANPortMappingDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char portMap[32] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	if((ret = zcfgFe98To181MappingNameGet(tr98FullPathName, portMap)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(portMap, "NAT.PortMapping.%hhu", &objIid.idx[0]);

	ret = zcfgFeObjStructDel(RDM_OID_NAT_PORT_MAPPING, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		printf("%s : Delete NAT.PortMapping Fail\n", __FUNCTION__);
	}

	return ret;
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.Stats
 *			or InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.Stats
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.Stats
 *   or Device.PPP.Interface.i.Stats
 */
zcfgRet_t WANConnStObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char iface[32] = {0};
	objIndex_t objIid;
	struct json_object *ifaceStJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	uint32_t oid;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);

	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".Stats");
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, iface)) == ZCFG_SUCCESS) {
		IID_INIT(objIid);
		objIid.level = 1;

		if(strstr(iface, "IP.Interface") != NULL) {
			sscanf(iface, "IP.Interface.%hhu", &objIid.idx[0]);
			oid = RDM_OID_IP_IFACE_STAT;
		}
		else {
			sscanf(iface, "PPP.Interface.%hhu", &objIid.idx[0]);	
			oid = RDM_OID_PPP_IFACE_STAT;
		}

		if((ret = zcfgFeObjJsonGet(oid, &objIid, &ifaceStJobj)) != ZCFG_SUCCESS)
			return ret;

		*tr98Jobj = json_object_new_object();
		paramList = tr98Obj[handler].parameter;
		while(paramList->name != NULL) {
			ptr = paramList->name + strlen("Ethernet");
			paramValue = json_object_object_get(ifaceStJobj, ptr);	
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;		
		}
		
		json_object_put(ifaceStJobj);
	}

	return ZCFG_SUCCESS;
}

/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANATMF5LoopbackDiagnostics

    Related object in TR181:
    Device.ATM.Diagnostics.F5Loopback.
 */
zcfgRet_t WANAtmF5LoConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char atmLink[24] = {0};
	objIndex_t atmF5LoIid;
	struct json_object *atmF5LoJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *ifValue = NULL;
	tr98Parameter_t *paramList = NULL;	
	
	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANATMF5LoopbackDiagnostics");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, atmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(atmLink, "ATM") == NULL) {
		printf("%s : Not a ATM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}


	IID_INIT(atmF5LoIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_DIAG_F5_LO, &atmF5LoIid, &atmF5LoJobj)) != ZCFG_SUCCESS) {
		return ret;
	}


	/*fill up tr98 WANATMF5LoopbackDiagnostics object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	ifValue = json_object_object_get(atmF5LoJobj, "Interface");

	while(paramList->name != NULL) {
		paramValue = json_object_object_get(atmF5LoJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
			
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}	

		
	json_object_put(atmF5LoJobj);

	return ret;
}

/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANATMF5LoopbackDiagnostics

    Related object in TR181:
    Device.ATM.Diagnostics.F5Loopback.
 */
zcfgRet_t WANAtmF5LoConfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char atmLink[32] = {0};
	objIndex_t atmF5LoIid;
	struct json_object *atmF5LoJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".WANATMF5LoopbackDiagnostics");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, atmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(atmLink, "ATM") == NULL) {
		printf("%s : Not a ATM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}


	/*Get Device.ATM.Diagnostics.F5Loopback*/
	IID_INIT(atmF5LoIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_DIAG_F5_LO, &atmF5LoIid, &atmF5LoJobj)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(multiJobj){
		tmpObj = atmF5LoJobj;
		atmF5LoJobj = NULL;
		atmF5LoJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ATM_DIAG_F5_LO, &atmF5LoIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
	}
		
	/*write tr181 Device.ATM.Diagnostics.F5Loopback  object*/
	paramList = tr98Obj[handler].parameter;	
	json_object_object_add(atmF5LoJobj, "Interface", json_object_new_string(atmLink));
 	while(paramList->name != NULL) {
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANATMF5LoopbackDiagnostics to Device.ATM.Diagnostics.F5Loopback*/
			tr181ParamValue = json_object_object_get(atmF5LoJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(atmF5LoJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
  
			/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;
		}
		else {
			paramList++;
		}
	}   
 
		
	if(multiJobj == NULL){
		if((ret = zcfgFeObjJsonSet(RDM_OID_ATM_DIAG_F5_LO, &atmF5LoIid, atmF5LoJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.ATM.Diagnostics.F5Loopback fail\n", __FUNCTION__);
			json_object_put(atmF5LoJobj);
			return ret;
		}

		json_object_put(atmF5LoJobj);
	}

	return ZCFG_SUCCESS;
}


/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.X_ZYXEL_WANATMF4LoopbackDiagnostics

    Related object in TR181:
    Device.ATM.Diagnostics.X_ZYXEL_F4Loopback.
 */
zcfgRet_t WANAtmF4LoConfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char atmLink[24] = {0};
	objIndex_t atmF4LoIid;
	struct json_object *atmF4LoJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *ifValue = NULL;
	tr98Parameter_t *paramList = NULL;	
	
	printf("%s : Enter\n", __FUNCTION__);

	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".X_ZYXEL_WANATMF4LoopbackDiagnostics");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, atmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(atmLink, "ATM") == NULL) {
		printf("%s : Not a ATM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}


	IID_INIT(atmF4LoIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_DIAG_F4_LO, &atmF4LoIid, &atmF4LoJobj)) != ZCFG_SUCCESS) {
		return ret;
	}


	/*fill up tr98 WANATMF4LoopbackDiagnostics object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	ifValue = json_object_object_get(atmF4LoJobj, "Interface");

	while(paramList->name != NULL) {
		paramValue = json_object_object_get(atmF4LoJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}
			
		/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
		printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
		paramList++;
	}	

		
	json_object_put(atmF4LoJobj);

	return ret;
}

/*  TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.X_ZYXEL_WANATMF4LoopbackDiagnostics

    Related object in TR181:
    Device.ATM.Diagnostics.X_ZYXEL_F4Loopback.
 */
zcfgRet_t WANAtmF4LoConfObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char tr98TmpName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	char atmLink[32] = {0};
	objIndex_t atmF4LoIid;
	struct json_object *atmF4LoJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;
	tr98Parameter_t *paramList = NULL;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98TmpName, tr98FullPathName);
	ptr = strstr(tr98TmpName, ".X_ZYXEL_WANATMF4LoopbackDiagnostics");
	*ptr = '\0';

	/* tr98TmpName will be InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i */
	if((ret = zcfgFe98To181MappingNameGet(tr98TmpName, atmLink)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(strstr(atmLink, "ATM") == NULL) {
		printf("%s : Not a ATM Link\n", __FUNCTION__);
		return ZCFG_NO_SUCH_OBJECT;
	}


	/*Get Device.ATM.Diagnostics.F4Loopback*/
	IID_INIT(atmF4LoIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_ATM_DIAG_F4_LO, &atmF4LoIid, &atmF4LoJobj)) != ZCFG_SUCCESS) {
		return ret;
	}

	if(multiJobj){
		tmpObj = atmF4LoJobj;
		atmF4LoJobj = NULL;
		atmF4LoJobj = zcfgFeJsonMultiObjAppend(RDM_OID_ATM_DIAG_F4_LO, &atmF4LoIid, multiJobj, tmpObj);
		json_object_put(tmpObj);
	}
		
	/*write tr181 Device.ATM.Diagnostics.F4Loopback  object*/
	paramList = tr98Obj[handler].parameter;	
	json_object_object_add(atmF4LoJobj, "Interface", json_object_new_string(atmLink));
 	while(paramList->name != NULL) {
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANATMF4LoopbackDiagnostics to Device.ATM.Diagnostics.F4Loopback*/
			tr181ParamValue = json_object_object_get(atmF4LoJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(atmF4LoJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
  
			/*Not defined in tr181, give it a default value*/
#if TR98_MAPPING_DEBUG
			printf("Can't find parameter %s in TR181\n", paramList->name);
#endif
			paramList++;
		}
		else {
			paramList++;
		}
	}   
 
		
	if(multiJobj == NULL){
		if((ret = zcfgFeObjJsonSet(RDM_OID_ATM_DIAG_F4_LO, &atmF4LoIid, atmF4LoJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.ATM.Diagnostics.X_ZYXEL_F4Loopback fail\n", __FUNCTION__);
			json_object_put(atmF4LoJobj);
			return ret;
		}

		json_object_put(atmF4LoJobj);
	}

	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t WANIpv6AddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6AddrIid;
	struct json_object *ipv6AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);

	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	IID_INIT(ipv6AddrIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6AddrIid.idx[0]);
	ipv6AddrIid.level = 2;
	ipv6AddrIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, &ipv6AddrJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		return ret;
	}

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6AddrJobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "Prefix") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe181To98MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix),"%s.X_ZYXEL_IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6AddrJobj);

	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Address.i.
 */

zcfgRet_t WANIpv6AddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6AddrIid;
	struct json_object *ipv6AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipv6AddrIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6AddrIid.idx[0]);
	ipv6AddrIid.level = 2;
	ipv6AddrIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, &ipv6AddrJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		return ret;
	}


	if(multiJobj){
		tmpObj = ipv6AddrJobj;
		ipv6AddrJobj = NULL;
		ipv6AddrJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "Prefix") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".X_ZYXEL_IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe98To181MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(ipv6AddrJobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}			
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6AddrJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6AddrJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, ipv6AddrJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
			json_object_put(ipv6AddrJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		}
		json_object_put(ipv6AddrJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t WANIpv6AddrObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objV6Iid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ipIface[32] = {0};
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}


	IID_INIT(objV6Iid);
	objV6Iid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &objV6Iid.idx[0]);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V6_ADDR, &objV6Iid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Add IP.Interface.%d.IPv6Address Fail.\n", __FUNCTION__, objV6Iid.idx[0]);
		return ret;
	}

	*idx = objV6Iid.idx[1];

	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t WANIpv6AddrObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint8_t ipv6Instance = 0;
	char ipIface[32] = {0};
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}


	IID_INIT(objIid);
	objIid.level = 2;
	sscanf(ipIface, "IP.Interface.%hhu", &objIid.idx[0]);
	objIid.idx[1] = ipv6Instance;

	ret = zcfgFeObjStructDel(RDM_OID_IP_IFACE_V6_ADDR, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, objIid.idx[0], objIid.idx[1]);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t WANIpv6PrefixObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6PrefixIid;
	struct json_object *ipv6PrefixJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);

	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	IID_INIT(ipv6PrefixIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6PrefixIid.idx[0]);
	ipv6PrefixIid.level = 2;
	ipv6PrefixIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, &ipv6PrefixJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		return ret;
	}

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6PrefixJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6PrefixJobj);

	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */

zcfgRet_t WANIpv6PrefixObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6PrefixIid;
	struct json_object *ipv6PrefixJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipv6PrefixIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6PrefixIid.idx[0]);
	ipv6PrefixIid.level = 2;
	ipv6PrefixIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, &ipv6PrefixJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		return ret;
	}


	if(multiJobj){
		tmpObj = ipv6PrefixJobj;
		ipv6PrefixJobj = NULL;
		ipv6PrefixJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6PrefixJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6PrefixJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, ipv6PrefixJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
			json_object_put(ipv6PrefixJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		}
		json_object_put(ipv6PrefixJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t WANIpv6PrefixObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objV6Iid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char ipIface[32] = {0};
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}


	IID_INIT(objV6Iid);
	objV6Iid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &objV6Iid.idx[0]);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V6_PREFIX, &objV6Iid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Add IP.Interface.%d.IPv6Prefix Fail.\n", __FUNCTION__, objV6Iid.idx[0]);
		return ret;
	}

	*idx = objV6Iid.idx[1];
	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t WANIpv6PrefixObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint8_t ipv6Instance = 0;
	char ipIface[32] = {0};
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	
	IID_INIT(objIid);
	objIid.level = 2;
	sscanf(ipIface, "IP.Interface.%hhu", &objIid.idx[0]);
	objIid.idx[1] = ipv6Instance;

	ret = zcfgFeObjStructDel(RDM_OID_IP_IFACE_V6_PREFIX, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, objIid.idx[0], objIid.idx[1]);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_DHCPv6Client.
 *
 *   Related object in TR181:
 *   Device.DHCPv6.Client.i.
 */
zcfgRet_t WANIpv6DhcpV6ObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6ClientIid;
	struct json_object *ipv6ClientJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_DHCPv6Client");
	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}

	IID_INIT(ipv6ClientIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, &ipv6ClientJobj)) == ZCFG_SUCCESS) {
		paramValue = json_object_object_get(ipv6ClientJobj, "Interface");
		if(paramValue != NULL){
			if(strcmp(ipIface, json_object_get_string(paramValue))==0){
				found = 1;
				break;
			}
		}
		json_object_put(ipv6ClientJobj);
	}

	if(!found)
		return ret;
	
	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6ClientJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6ClientJobj);
	
	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_DHCPv6Client.
 *
 *   Related object in TR181:
 *   Device.IPv6rd.
 *   Device.IPv6rd.InterfaceSetting.i.
 */

zcfgRet_t WANIpv6DhcpV6ObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6ClientIid;
	struct json_object *ipv6ClientJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_DHCPv6Client");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipv6ClientIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, &ipv6ClientJobj)) == ZCFG_SUCCESS) {
		if(strcmp(ipIface, json_object_get_string(json_object_object_get(ipv6ClientJobj, "Interface")))==0){
			found = 1;
			break;
		}
		else
			json_object_put(ipv6ClientJobj);
	}

	if(!found )
		return ret;

	if(multiJobj){
		tmpObj = ipv6ClientJobj;
		ipv6ClientJobj = NULL;
		ipv6ClientJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6ClientJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6ClientJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, ipv6ClientJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv6.Client.%d Fail\n", __FUNCTION__, ipv6ClientIid.idx[0]);
			json_object_put(ipv6ClientJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv6.Client.%d Fail\n", __FUNCTION__, ipv6ClientIid.idx[0]);
		}
		json_object_put(ipv6ClientJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6rd.
 *
 *   Related object in TR181:
 *   Device.IPv6rd.
 *   Device.IPv6rd.InterfaceSetting.i.
 */
zcfgRet_t WANIpv6RdObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char addrsrcObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6RdIid;
	struct json_object *ipv6RdJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t addrsrcInstance = 0;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6rd");
	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	IID_INIT(ipv6RdIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_IPV6RD_INTF, &ipv6RdIid, &ipv6RdJobj)) == ZCFG_SUCCESS) {
		paramValue = json_object_object_get(ipv6RdJobj, "X_ZYXEL_Interface");
		if(paramValue != NULL){
			if(strcmp(ipIface, json_object_get_string(paramValue))==0){
				found = 1;
				break;
			}
		}
		json_object_put(ipv6RdJobj);
	}
	if(!found)
		return ret;
	
	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6RdJobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "AddressSource") == 0){//transfer
				strcpy(addrsrcObjName, json_object_get_string(paramValue));
				ptr = strstr(addrsrcObjName, ".IPv4Address");
				if(ptr){
					sscanf(ptr, ".IPv4Address.%hhu", &addrsrcInstance);
					*ptr = '\0';
					if(zcfgFe181To98MappingNameGet(addrsrcObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv4Address.%d", ipIface, addrsrcInstance);
						json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}			
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6RdJobj);
	
	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6rd.
 *
 *   Related object in TR181:
 *   Device.DHCPv6.Client.i.
 */

zcfgRet_t WANIpv6RdObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char addrsrcObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6RdIid;
	struct json_object *ipv6RdJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t addrsrcInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6rd");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, ipIface)) != ZCFG_SUCCESS) {
		return ret;
	}

	IID_INIT(ipv6RdIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_IPV6RD_INTF, &ipv6RdIid, &ipv6RdJobj)) == ZCFG_SUCCESS) {
		paramValue = json_object_object_get(ipv6RdJobj, "X_ZYXEL_Interface");
		if(paramValue != NULL){
			if(strcmp(ipIface, json_object_get_string(paramValue))==0){
				found = 1;
				break;
			}
		}
		json_object_put(ipv6RdJobj);
	}


	if(!found )
		return ret;

	if(multiJobj){
		tmpObj = ipv6RdJobj;
		ipv6RdJobj = NULL;
		ipv6RdJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IPV6RD_INTF, &ipv6RdIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6RdJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				if(strcmp( paramList->name, "AddressSource") == 0){//transfer
					strcpy(addrsrcObjName, json_object_get_string(paramValue));
					ptr = strstr(addrsrcObjName, ".IPv4Address");
					if(ptr){
						sscanf(ptr, ".IPv4Address.%hhu", &addrsrcInstance);
						*ptr = '\0';
						if(zcfgFe98To181MappingNameGet(addrsrcObjName, ipIface) == ZCFG_SUCCESS) {
							snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv4Address.%d", ipIface, addrsrcInstance);
							json_object_object_add(ipv6RdJobj, paramList->name, json_object_new_string(tr98Prefix));
							paramList++;
							continue;
						}
					}
				}	

				json_object_object_add(ipv6RdJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IPV6RD_INTF, &ipv6RdIid, ipv6RdJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IPv6rd.InterfaceSetting.%d Fail\n", __FUNCTION__, ipv6RdIid.idx[0]);
			json_object_put(ipv6RdJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IPv6rd.InterfaceSetting.%d Fail\n", __FUNCTION__, ipv6RdIid.idx[0]);
		}
		json_object_put(ipv6RdJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t WANPppv6AddrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6AddrIid;
	struct json_object *ipv6AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);

	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;
	
	IID_INIT(ipv6AddrIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6AddrIid.idx[0]);
	ipv6AddrIid.level = 2;
	ipv6AddrIid.idx[1] = ipv6Instance;

	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, &ipv6AddrJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		return ret;
	}

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6AddrJobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "Prefix") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe181To98MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix),"%s.X_ZYXEL_IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6AddrJobj);

	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */

zcfgRet_t WANPppv6AddrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char prefixObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6AddrIid;
	struct json_object *ipv6AddrJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t prefixInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(ipv6AddrIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6AddrIid.idx[0]);
	ipv6AddrIid.level = 2;
	ipv6AddrIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, &ipv6AddrJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		return ret;
	}


	if(multiJobj){
		tmpObj = ipv6AddrJobj;
		ipv6AddrJobj = NULL;
		ipv6AddrJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "Prefix") == 0){//transfer
				strcpy(prefixObjName, json_object_get_string(paramValue));
				ptr = strstr(prefixObjName, ".X_ZYXEL_IPv6Prefix");
				if(ptr){
					sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &prefixInstance);
					*ptr = '\0';
					if(zcfgFe98To181MappingNameGet(prefixObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv6Prefix.%d", ipIface, prefixInstance);
						json_object_object_add(ipv6AddrJobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}			
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6AddrJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6AddrJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V6_ADDR, &ipv6AddrIid, ipv6AddrJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
			json_object_put(ipv6AddrJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, ipv6AddrIid.idx[0], ipv6AddrIid.idx[1]);
		}
		json_object_put(ipv6AddrJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t WANPppv6AddrObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objV6Iid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char pppIface[32] = {0}, ipIface[32] = {0};
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;


	IID_INIT(objV6Iid);
	objV6Iid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &objV6Iid.idx[0]);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V6_ADDR, &objV6Iid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Add IP.Interface.%d.IPv6Address Fail.\n", __FUNCTION__, objV6Iid.idx[0]);
		return ret;
	}

	*idx = objV6Iid.idx[1];

	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Address.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Address.i.
 */
zcfgRet_t WANPppv6AddrObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint8_t ipv6Instance = 0;
	char pppIface[32] = {0}, ipIface[32] = {0};
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Address");
	sscanf(ptr, ".X_ZYXEL_IPv6Address.%hhu", &ipv6Instance);
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;


	IID_INIT(objIid);
	objIid.level = 2;
	sscanf(ipIface, "IP.Interface.%hhu", &objIid.idx[0]);
	objIid.idx[1] = ipv6Instance;

	ret = zcfgFeObjStructDel(RDM_OID_IP_IFACE_V6_ADDR, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete IP.Interface.%d.IPv6Address.%d Fail\n", __FUNCTION__, objIid.idx[0], objIid.idx[1]);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t WANPppv6PrefixObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6PrefixIid;
	struct json_object *ipv6PrefixJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);

	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;
	
	IID_INIT(ipv6PrefixIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6PrefixIid.idx[0]);
	ipv6PrefixIid.level = 2;
	ipv6PrefixIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, &ipv6PrefixJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		return ret;
	}

	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6PrefixJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6PrefixJobj);

	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */

zcfgRet_t WANPppv6PrefixObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6PrefixIid;
	struct json_object *ipv6PrefixJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	uint8_t ipv6Instance = 0;
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(ipv6PrefixIid);
	sscanf(ipIface, "IP.Interface.%hhu", &ipv6PrefixIid.idx[0]);
	ipv6PrefixIid.level = 2;
	ipv6PrefixIid.idx[1] = ipv6Instance;
	
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, &ipv6PrefixJobj)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Get IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		return ret;
	}


	if(multiJobj){
		tmpObj = ipv6PrefixJobj;
		ipv6PrefixJobj = NULL;
		ipv6PrefixJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6PrefixJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6PrefixJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE_V6_PREFIX, &ipv6PrefixIid, ipv6PrefixJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
			json_object_put(ipv6PrefixJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, ipv6PrefixIid.idx[0], ipv6PrefixIid.idx[1]);
		}
		json_object_put(ipv6PrefixJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t WANPppv6PrefixObjAdd(char *tr98FullPathName, int *idx)
{
	zcfgRet_t ret;
	objIndex_t objV6Iid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char pppIface[32] = {0}, ipIface[32] = {0};
	char *ptr = NULL;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;


	IID_INIT(objV6Iid);
	objV6Iid.level = 1;
	sscanf(ipIface, "IP.Interface.%hhu", &objV6Iid.idx[0]);
	if((ret = zcfgFeObjStructAdd(RDM_OID_IP_IFACE_V6_PREFIX, &objV6Iid, NULL)) != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Add IP.Interface.%d.IPv6Prefix Fail.\n", __FUNCTION__, objV6Iid.idx[0]);
		return ret;
	}

	*idx = objV6Iid.idx[1];
	return ZCFG_SUCCESS;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Prefix.i.
 *
 *   Related object in TR181:
 *   Device.IP.Interface.i
 *   Device.IP.Interface.i.IPv6Prefix.i.
 */
zcfgRet_t WANPppv6PrefixObjDel(char *tr98FullPathName)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char *ptr = NULL;
	uint8_t ipv6Instance = 0;
	char pppIface[32] = {0}, ipIface[32] = {0};
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6Prefix");
	sscanf(ptr, ".X_ZYXEL_IPv6Prefix.%hhu", &ipv6Instance);
	*ptr = '\0';

	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(objIid);
	objIid.level = 2;
	sscanf(ipIface, "IP.Interface.%hhu", &objIid.idx[0]);
	objIid.idx[1] = ipv6Instance;

	ret = zcfgFeObjStructDel(RDM_OID_IP_IFACE_V6_PREFIX, &objIid, NULL);
	if (ret != ZCFG_SUCCESS) {
		zcfgLog(ZCFG_LOG_ERR, "%s : Delete IP.Interface.%d.IPv6Prefix.%d Fail\n", __FUNCTION__, objIid.idx[0], objIid.idx[1]);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_DHCPv6Client.
 *
 *   Related object in TR181:
 *   Device.DHCPv6.Client.i.
 */
zcfgRet_t WANPppv6DhcpV6ObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6ClientIid;
	struct json_object *ipv6ClientJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_DHCPv6Client");
	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(ipv6ClientIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, &ipv6ClientJobj)) == ZCFG_SUCCESS) {
		paramValue = json_object_object_get(ipv6ClientJobj, "Interface");
		if(paramValue != NULL){
			if(strcmp(ipIface, json_object_get_string(paramValue))==0){
				found = 1;
				break;
			}
		}
		json_object_put(ipv6ClientJobj);
	}

	if(!found)
		return ret;
	
	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6ClientJobj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6ClientJobj);
	
	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_DHCPv6Client.
 *
 *   Related object in TR181:
 *   Device.IPv6rd.
 *   Device.IPv6rd.InterfaceSetting.i.
 */

zcfgRet_t WANPppv6DhcpV6ObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6ClientIid;
	struct json_object *ipv6ClientJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_DHCPv6Client");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(ipv6ClientIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, &ipv6ClientJobj)) == ZCFG_SUCCESS) {
		if(strcmp(ipIface, json_object_get_string(json_object_object_get(ipv6ClientJobj, "Interface")))==0){
			found = 1;
			break;
		}
		else
			json_object_put(ipv6ClientJobj);
	}

	if(!found )
		return ret;

	if(multiJobj){
		tmpObj = ipv6ClientJobj;
		ipv6ClientJobj = NULL;
		ipv6ClientJobj = zcfgFeJsonMultiObjAppend(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6ClientJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipv6ClientJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_DHCPV6_CLIENT, &ipv6ClientIid, ipv6ClientJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv6.Client.%d Fail\n", __FUNCTION__, ipv6ClientIid.idx[0]);
			json_object_put(ipv6ClientJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.DHCPv6.Client.%d Fail\n", __FUNCTION__, ipv6ClientIid.idx[0]);
		}
		json_object_put(ipv6ClientJobj);
	}

	return ret;
}

/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6rd.
 *
 *   Related object in TR181:
 *   Device.IPv6rd.
 *   Device.IPv6rd.InterfaceSetting.i.
 */
zcfgRet_t WANPppv6RdObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char addrsrcObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6RdIid;
	struct json_object *ipv6RdJobj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t addrsrcInstance = 0;
	
	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6rd");
	*ptr = '\0';

	if(zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface) != ZCFG_SUCCESS) {
		/*  The instance number of WANIPConnection.i will be continuous. Therefore, 
		 *  just return "ZCFG_NO_MORE_INSTANCE" when there is no related mapping of tr181 for
		 *  this WANIPConnection object.
		 */
		return ZCFG_NO_MORE_INSTANCE;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;
	
	IID_INIT(ipv6RdIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_IPV6RD_INTF, &ipv6RdIid, &ipv6RdJobj)) == ZCFG_SUCCESS) {
		paramValue = json_object_object_get(ipv6RdJobj, "X_ZYXEL_Interface");
		if(paramValue != NULL){
			if(strcmp(ipIface, json_object_get_string(paramValue))==0){
				found = 1;
				break;
			}
		}
		json_object_put(ipv6RdJobj);
	}
	if(!found)
		return ret;
	
	/*Fill up tr98 WANIPConnection.i object*/
	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	
	while(paramList->name != NULL) {
		paramValue = json_object_object_get(ipv6RdJobj, paramList->name);
		if(paramValue != NULL) {
			if(strcmp( paramList->name, "AddressSource") == 0){//transfer
				strcpy(addrsrcObjName, json_object_get_string(paramValue));
				ptr = strstr(addrsrcObjName, ".IPv4Address");
				if(ptr){
					sscanf(ptr, ".IPv4Address.%hhu", &addrsrcInstance);
					*ptr = '\0';
					if(zcfgFe181To98MappingNameGet(addrsrcObjName, ipIface) == ZCFG_SUCCESS) {
						snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv4Address.%d", ipIface, addrsrcInstance);
						json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98Prefix));
						paramList++;
						continue;
					}
				}
			}			
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		/*special case*/

		paramList++;
	}

	json_object_put(ipv6RdJobj);
	
	return ZCFG_SUCCESS;	
}
/*  
 *   TR98 Object Name : InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6rd.
 *
 *   Related object in TR181:
 *   Device.DHCPv6.Client.i.
 */

zcfgRet_t WANPppv6RdObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	char pppIface[32] = {0}, ipIface[32] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char addrsrcObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	objIndex_t ipv6RdIid;
	struct json_object *ipv6RdJobj = NULL;
	struct json_object *paramValue = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *tmpObj = NULL;	
	tr98Parameter_t *paramList = NULL;
	char *ptr = NULL;
	int found = 0;
	char tr98Prefix[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	uint8_t addrsrcInstance = 0;

	zcfgLog(ZCFG_LOG_INFO, "%s : Enter\n", __FUNCTION__);
	
	strcpy(tr98ConnObjName, tr98FullPathName);
	ptr = strstr(tr98ConnObjName, ".X_ZYXEL_IPv6rd");
	*ptr = '\0';

	/*find tr181 mapping object*/
	if((ret = zcfgFe98To181MappingNameGet(tr98ConnObjName, pppIface)) != ZCFG_SUCCESS) {
		return ret;
	}
	/*Get IP.Interface.i above PPP.Interface.i*/
	if((ret = zcfgFeTr181IfaceStackHigherLayerGet(pppIface, ipIface)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(ipv6RdIid);
	while((ret = zcfgFeObjJsonGetNext(RDM_OID_IPV6RD_INTF, &ipv6RdIid, &ipv6RdJobj)) == ZCFG_SUCCESS) {
		paramValue = json_object_object_get(ipv6RdJobj, "X_ZYXEL_Interface");
		if(paramValue != NULL){
			if(strcmp(ipIface, json_object_get_string(paramValue))==0){
				found = 1;
				break;
			}
		}
		json_object_put(ipv6RdJobj);
	}


	if(!found )
		return ret;

	if(multiJobj){
		tmpObj = ipv6RdJobj;
		ipv6RdJobj = NULL;
		ipv6RdJobj = zcfgFeJsonMultiObjAppend(RDM_OID_IPV6RD_INTF, &ipv6RdIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			/*Write value from WANIPConnection to Device.IP.Interface.i*/
			tr181ParamValue = json_object_object_get(ipv6RdJobj, paramList->name);
			if(tr181ParamValue != NULL) {
				if(strcmp( paramList->name, "AddressSource") == 0){//transfer
					strcpy(addrsrcObjName, json_object_get_string(paramValue));
					ptr = strstr(addrsrcObjName, ".IPv4Address");
					if(ptr){
						sscanf(ptr, ".IPv4Address.%hhu", &addrsrcInstance);
						*ptr = '\0';
						if(zcfgFe98To181MappingNameGet(addrsrcObjName, ipIface) == ZCFG_SUCCESS) {
							snprintf(tr98Prefix, sizeof(tr98Prefix), "%s.IPv4Address.%d", ipIface, addrsrcInstance);
							json_object_object_add(ipv6RdJobj, paramList->name, json_object_new_string(tr98Prefix));
							paramList++;
							continue;
						}
					}
				}	

				json_object_object_add(ipv6RdJobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			/*special case*/
		}
		paramList++;	
	}


	/*Set Device.IP.Interface.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IPV6RD_INTF, &ipv6RdIid, ipv6RdJobj, NULL)) != ZCFG_SUCCESS ) {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IPv6rd.InterfaceSetting.%d Fail\n", __FUNCTION__, ipv6RdIid.idx[0]);
			json_object_put(ipv6RdJobj);
			return ret;
		}
		else {
			zcfgLog(ZCFG_LOG_ERR, "%s : Set Device.IPv6rd.InterfaceSetting.%d Fail\n", __FUNCTION__, ipv6RdIid.idx[0]);
		}
		json_object_put(ipv6RdJobj);
	}

	return ret;
}

