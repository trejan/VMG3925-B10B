/*Parameter*/
extern tr98Parameter_t para_Root[];

/*Handler Function*/
extern zcfgRet_t rootObjGet(char *, int, struct json_object **);
