tr98Parameter_t para_LanDev[] = {	
	{ "LANEthernetInterfaceNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "LANUSBInterfaceNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "LANWLANConfigurationNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ NULL, 0, 0, 0}
};
	
tr98Parameter_t para_LanHostConfMgmt[] = {	
	{ "MACAddress", PARAMETER_ATTR_READONLY, 19, json_type_string},	
	{ "DHCPServerConfigurable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "DHCPServerEnable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "DHCPRelay", PARAMETER_ATTR_READONLY, 0, json_type_boolean},	
	{ "MinAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "MaxAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "ReservedAddresses", PARAMETER_ATTR_WRITE, 257, json_type_string},	
	{ "SubnetMask", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "DNSServers", PARAMETER_ATTR_WRITE, 65, json_type_string},	
	{ "DomainName", PARAMETER_ATTR_WRITE, 65, json_type_string},	
	{ "IPRouters", PARAMETER_ATTR_WRITE, 65, json_type_string},	
	{ "DHCPLeaseTime", PARAMETER_ATTR_WRITE, 0, json_type_int},	
	{ "UseAllocatedWAN", PARAMETER_ATTR_WRITE, 20, json_type_string},	
	{ "AssociatedConnection", PARAMETER_ATTR_WRITE, 257, json_type_string},	
	{ "PassthroughLease", PARAMETER_ATTR_WRITE, 0, json_type_uint32},	
	{ "PassthroughMACAddress", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ "AllowedMACAddress", PARAMETER_ATTR_WRITE, 513, json_type_string},	
	{ "IPInterfaceNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "DHCPStaticAddressNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "DHCPOptionNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "DHCPConditionalPoolNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "X_ZYXEL_DNS_Type", PARAMETER_ATTR_WRITE, 16, json_type_string},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_IpIntf[] = {	
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "IPInterfaceIPAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "IPInterfaceSubnetMask", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "IPInterfaceAddressingType", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "X_ZYXEL_IfName", PARAMETER_ATTR_WRITE, 17, json_type_string},
	{ "X_ZYXEL_ConnectionId", PARAMETER_ATTR_WRITE, 17, json_type_int},
	{ "X_ZYXEL_IPR2_MARKING", PARAMETER_ATTR_WRITE, 17, json_type_uint32},
#ifdef IPV6INTERFACE_PROFILE
	{ "X_ZYXEL_IPv6Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "X_ZYXEL_IPv6Status", PARAMETER_ATTR_READONLY, 10, json_type_string},
	{ "X_ZYXEL_IPv6DNSEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "X_ZYXEL_IPv6DNSServers", PARAMETER_ATTR_WRITE, 65, json_type_string},
	{ "X_ZYXEL_IPv6LanIdentifierEUI64Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "X_ZYXEL_IPv6AddressNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "X_ZYXEL_IPv6PrefixNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
#endif
	{ NULL, 0, 0, 0}
};

#ifdef IPV6INTERFACE_PROFILE
tr98Parameter_t para_IpIntfV6Addr[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Status", PARAMETER_ATTR_READONLY, 24, json_type_string},
	{ "IPAddressStatus", PARAMETER_ATTR_READONLY, 16, json_type_string},
	{ "IPAddress", PARAMETER_ATTR_WRITE, 48, json_type_string},
	{ "Origin", PARAMETER_ATTR_READONLY, 24, json_type_string},
	{ "Prefix", PARAMETER_ATTR_WRITE, 32, json_type_string},
	{ "PreferredLifetime", PARAMETER_ATTR_WRITE, 0, json_type_time},
	{ "ValidLifetime", PARAMETER_ATTR_WRITE, 0, json_type_time},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_IpIntfV6Prefix[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Status", PARAMETER_ATTR_READONLY, 24, json_type_string},
	{ "PrefixStatus", PARAMETER_ATTR_READONLY, 16, json_type_string},
	{ "Prefix", PARAMETER_ATTR_WRITE, 24, json_type_string},
	{ "OnLink", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Autonomous", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "PreferredLifetime", PARAMETER_ATTR_WRITE, 0, json_type_time},
	{ "ValidLifetime", PARAMETER_ATTR_WRITE, 0, json_type_time},
	{ NULL, 0, 0, 0}
};
#endif
#ifdef ROUTERADVERTISEMENT_PROFILE
tr98Parameter_t para_IpIntfRouterAdver[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Status", PARAMETER_ATTR_READONLY, 19, json_type_string},
	{ "MaxRtrAdvInterval", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "MinRtrAdvInterval", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AdvDefaultLifetime", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AdvManagedFlag", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "AdvOtherConfigFlag", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "AdvLinkMTU", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AdvReachableTime", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AdvRetransTimer", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AdvCurHopLimit", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};

#endif
#ifdef IPV6SERVER_PROFILE
tr98Parameter_t para_IpIntfV6Srv[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Status", PARAMETER_ATTR_READONLY, 19, json_type_string},
	{ "IANAEnable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "IANAPrefixes", PARAMETER_ATTR_READONLY, 800, json_type_string},//comman separate *8
	{ NULL, 0, 0, 0}
};
#endif

tr98Parameter_t para_LanIpFilter[] = {	
	{ "Name", PARAMETER_ATTR_WRITE, 33, json_type_string},	
	{ "SourceAddress", PARAMETER_ATTR_WRITE, 18, json_type_string},	
	{ "DestinationAddress", PARAMETER_ATTR_WRITE, 18, json_type_string},	
	{ "Port", PARAMETER_ATTR_WRITE, 0, json_type_uint32},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_LanPortMapp[] = {	
	{ "Enabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "Name", PARAMETER_ATTR_WRITE, 33, json_type_string},	
	{ "ServerIPAddress", PARAMETER_ATTR_WRITE, 18, json_type_string},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_DhcpStaticAddr[] = {	
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "Chaddr", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ "Yiaddr", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_DhcpOpt[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Tag", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "Value", PARAMETER_ATTR_WRITE, json_type_base64},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_DhcpCondServPool[] = {	
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "PoolOrder", PARAMETER_ATTR_WRITE, 0, json_type_uint32},	
	{ "SourceInterface", PARAMETER_ATTR_WRITE, 1025, json_type_string},	
	{ "VendorClassID", PARAMETER_ATTR_WRITE, 257, json_type_string},	
	{ "VendorClassIDExclude", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "VendorClassIDMode", PARAMETER_ATTR_WRITE, 11, json_type_string},	
	{ "ClientID", PARAMETER_ATTR_WRITE, 257, json_type_string},	
	{ "ClientIDExclude", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "UserClassID", PARAMETER_ATTR_WRITE, 257, json_type_string},	
	{ "UserClassIDExclude", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "Chaddr", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ "ChaddrMask", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ "ChaddrExclude", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "LocallyServed", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "MinAddress", PARAMETER_ATTR_WRITE, 9, json_type_string},	
	{ "MaxAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "ReservedAddresses", PARAMETER_ATTR_WRITE, 513, json_type_string},	
	{ "SubnetMask", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "DNSServers", PARAMETER_ATTR_WRITE, 65, json_type_string},	
	{ "DomainName", PARAMETER_ATTR_WRITE, 65, json_type_string},	
	{ "IPRouters", PARAMETER_ATTR_WRITE, 65, json_type_string},	
	{ "DHCPLeaseTime", PARAMETER_ATTR_WRITE, 0, json_type_int},	
	{ "UseAllocatedWAN", PARAMETER_ATTR_WRITE, 13, json_type_string},	
	{ "AssociatedConnection", PARAMETER_ATTR_WRITE, 257, json_type_string},	
	{ "DHCPServerIPAddress", PARAMETER_ATTR_WRITE, 17, json_type_string},	
	{ "DHCPStaticAddressNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "DHCPOptionNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_DhcpCondServPoolDhcpStaticAddr[] = {	
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "Chaddr", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ "Yiaddr", PARAMETER_ATTR_WRITE, 19, json_type_string},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_DhcpCondServPoolDhcpOpt[] = {	
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "Tag", PARAMETER_ATTR_WRITE, 0, json_type_uint32},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_LanEthIntfConf[] = {	
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "Status", PARAMETER_ATTR_READONLY, 10, json_type_string},	
	{ "Name", PARAMETER_ATTR_READONLY, 17, json_type_string},	
	{ "MACAddress", PARAMETER_ATTR_READONLY, 19, json_type_string},	
	{ "MACAddressControlEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},	
	{ "MaxBitRate", PARAMETER_ATTR_WRITE, 7, json_type_string},	
	{ "DuplexMode", PARAMETER_ATTR_WRITE, 6, json_type_string},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_LanEthIntfConfStat[] = {	
	{ "BytesSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "BytesReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "PacketsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "PacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "ErrorsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "ErrorsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "UnicastPacketsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "UnicastPacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "DiscardPacketsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "DiscardPacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "MulticastPacketsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "MulticastPacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "BroadcastPacketsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "BroadcastPacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ "UnknownProtoPacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},	
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_LanDevWlanCfg[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Status", PARAMETER_ATTR_READONLY, 10, json_type_string},
	{ "Name", PARAMETER_ATTR_READONLY, 17, json_type_string},
	{ "BSSID", PARAMETER_ATTR_READONLY, 19, json_type_string},
	{ "MaxBitRate", PARAMETER_ATTR_WRITE, 5, json_type_string},
	{ "Channel", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AutoChannelEnable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "SSID", PARAMETER_ATTR_WRITE, 33, json_type_string},
	{ "BeaconType", PARAMETER_ATTR_WRITE, 19, json_type_string},
	{ "MACAddressControlEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "Standard", PARAMETER_ATTR_READONLY, 8, json_type_string},
	{ "WEPKeyIndex", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "KeyPassphrase", PARAMETER_ATTR_WRITE, 64, json_type_string},
	{ "WEPEncryptionLevel", PARAMETER_ATTR_READONLY, 65, json_type_string},
	{ "BasicEncryptionModes", PARAMETER_ATTR_WRITE, 15, json_type_string},
	{ "BasicAuthenticationMode", PARAMETER_ATTR_WRITE, 22, json_type_string},
	{ "WPAEncryptionModes", PARAMETER_ATTR_WRITE, 28, json_type_string},
	{ "WPAAuthenticationMode", PARAMETER_ATTR_WRITE, 20, json_type_string},
	{ "IEEE11iEncryptionModes", PARAMETER_ATTR_WRITE, 28, json_type_string},
	{ "IEEE11iAuthenticationMode", PARAMETER_ATTR_WRITE, 26, json_type_string},
	{ "PossibleChannels", PARAMETER_ATTR_READONLY, 1025, json_type_string},
	{ "BasicDataTransmitRates", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "OperationalDataTransmitRates", PARAMETER_ATTR_WRITE, 257, json_type_string},
	{ "PossibleDataTransmitRates", PARAMETER_ATTR_READONLY, 257, json_type_string},
	{ "InsecureOOBAccessEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "BeaconAdvertisementEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "SSIDAdvertisementEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "RadioEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "TransmitPowerSupported", PARAMETER_ATTR_READONLY, 65, json_type_string},
	{ "TransmitPower", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "AutoRateFallBackEnabled", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "LocationDescription", PARAMETER_ATTR_WRITE, 4097, json_type_string},
	{ "RegulatoryDomain", PARAMETER_ATTR_WRITE, 4, json_type_string},
	{ "TotalPSKFailures", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TotalIntegrityFailures", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "ChannelsInUse", PARAMETER_ATTR_READONLY, 1025, json_type_string},
	{ "DeviceOperationMode", PARAMETER_ATTR_WRITE, 27, json_type_string},
	{ "DistanceFromRoot", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "PeerBSSID", PARAMETER_ATTR_WRITE, 19, json_type_string},
	{ "AuthenticationServiceMode", PARAMETER_ATTR_WRITE, 20, json_type_string},
	{ "WMMSupported", PARAMETER_ATTR_READONLY, 0, json_type_boolean},
	{ "UAPSDSupported", PARAMETER_ATTR_READONLY, 0, json_type_boolean},
	{ "WMMEnable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "UAPSDEnable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "TotalBytesSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TotalBytesReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TotalPacketsSent", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TotalPacketsReceived", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "TotalAssociations", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_LanDevWlanCfgWps[] = {
	{ "Enable", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "DeviceName", PARAMETER_ATTR_READONLY, 33, json_type_string},
	{ "DevicePassword", PARAMETER_ATTR_WRITE, 0, json_type_uint32},
	{ "UUID", PARAMETER_ATTR_READONLY, 37, json_type_string},
	{ "Version", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "ConfigMethodsSupported", PARAMETER_ATTR_READONLY, 105, json_type_string},
	{ "ConfigMethodsEnabled", PARAMETER_ATTR_WRITE, 105, json_type_string},
	{ "SetupLockedState", PARAMETER_ATTR_READONLY, 26, json_type_string},
	{ "SetupLock", PARAMETER_ATTR_WRITE, 0, json_type_boolean},
	{ "ConfigurationState", PARAMETER_ATTR_READONLY, 16, json_type_string},
	{ "LastConfigurationError", PARAMETER_ATTR_READONLY, 28, json_type_string},
	{ "RegistrarNumberOfEntries", PARAMETER_ATTR_READONLY, 0, json_type_uint32},
	{ "RegistrarEstablished", PARAMETER_ATTR_READONLY, 0, json_type_boolean},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_WepKey[] = {
	{ "WEPKey", PARAMETER_ATTR_WRITE, 129, json_type_string},
	{ NULL, 0, 0, 0}
};

tr98Parameter_t para_Psk[] = {
	{ "PreSharedKey", PARAMETER_ATTR_WRITE, 65, json_type_string},
	{ "KeyPassphrase", PARAMETER_ATTR_WRITE, 64, json_type_string},
	{ "AssociatedDeviceMACAddress", PARAMETER_ATTR_WRITE, 19, json_type_string},
	{ NULL, 0, 0, 0}
};
