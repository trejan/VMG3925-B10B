/*Parameter*/
extern tr98Parameter_t para_LanConfSec[];

/*Handler Function*/
extern zcfgRet_t lanConfSecObjGet(char *, int, struct json_object **);
extern zcfgRet_t lanConfSecObjSet(char *, int , struct json_object *, struct json_object *);

