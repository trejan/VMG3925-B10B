/*Parameter*/
extern tr98Parameter_t para_IpPingDiag[];
extern tr98Parameter_t para_TraceRtDiag[];
extern tr98Parameter_t para_RtHop[];
extern tr98Parameter_t para_PerpDiag[];
extern tr98Parameter_t para_DlDiag[];
extern tr98Parameter_t para_UlDiag[];
/*Handler Function*/

/* InternetGatewayDevice.IPPingDiagnostics */
extern zcfgRet_t ipPingDiagObjGet(char *, int, struct json_object **);
extern zcfgRet_t ipPingDiagObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.TraceRouteDiagnostics */
extern zcfgRet_t traceRtDiagObjGet(char *, int, struct json_object **);
extern zcfgRet_t traceRtDiagObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.i */
extern zcfgRet_t routeHopsObjGet(char *, int, struct json_object **);
/* InternetGatewayDevice.Capabilities.PerformanceDiagnostic */
extern zcfgRet_t perfDiagObjGet(char *, int, struct json_object **);
/* InternetGatewayDevice.DownloadDiagnostics */
extern zcfgRet_t dlDiagObjGet(char *, int, struct json_object **);
extern zcfgRet_t dlDiagObjSet(char *, int, struct json_object *, struct json_object *);
/* InternetGatewayDevice.UploadDiagnostics */
extern zcfgRet_t ulDiagObjGet(char *, int, struct json_object **);
extern zcfgRet_t ulDiagObjSet(char *, int, struct json_object *, struct json_object *);