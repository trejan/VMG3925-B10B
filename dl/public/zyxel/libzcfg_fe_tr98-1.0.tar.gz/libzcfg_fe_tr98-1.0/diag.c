#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcmd_schema.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"
#include "zcfg_fe_tr98.h"
#include "diag_parameter.h"

extern tr98Object_t tr98Obj[];

extern zcfgRet_t zcfgFeTr181IfaceStackHigherLayerGet(char *, char *);
extern zcfgRet_t zcfgFeTr181IfaceStackLowerLayerGet(char *, char *);
/*
 *   TR98 Object Name : InternetGatewayDevice.IPPingDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.IPPing
 */
zcfgRet_t ipPingDiagObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *ipPingObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char devIpIface[48] = {0};
	char iface[40] = {0};
	char lowerLayer[32] = {0};
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_IPPING, &objIid, &ipPingObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*special case*/
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(ipPingObj, paramList->name);
			strcpy(devIpIface, json_object_get_string(paramValue));
			if(!strcmp(devIpIface, "")) {
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			else {
				strcpy(iface, devIpIface);
				zcfgFeTr181IfaceStackLowerLayerGet(iface, lowerLayer);
				if(strstr(lowerLayer, "PPP.Interface") != NULL) {
					strcpy(iface, lowerLayer);
				}
				zcfgFe181To98MappingNameGet(iface, tr98ObjName);
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98ObjName));
			}
			paramList++;
			continue;
		}
		
		paramValue = json_object_object_get(ipPingObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}

	json_object_put(ipPingObj);

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.IPPingDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.IPPing
 */
zcfgRet_t ipPingDiagObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *ipPingObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char iface[40] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char higherLayer[32] = {0};
	char devIpIface[48] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_IPPING, &objIid, &ipPingObj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = ipPingObj;
		ipPingObj = NULL;
		ipPingObj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_DIAG_IPPING, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				strcpy(tr98ConnObjName, json_object_get_string(paramValue));
				if(zcfgFe98To181MappingNameGet(tr98ConnObjName, iface) != ZCFG_SUCCESS) {
					json_object_object_add(ipPingObj, paramList->name, json_object_new_string(""));
				}
				else {
					if(strstr(iface, "PPP.Interface") != NULL) {
						zcfgFeTr181IfaceStackHigherLayerGet(iface, higherLayer);
						strcpy(iface, higherLayer);
					}
					
					strcpy(devIpIface, iface);
					json_object_object_add(ipPingObj, paramList->name, json_object_new_string(devIpIface));
				}
			}
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(ipPingObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ipPingObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	/*Set Device.Routing.Router.1.IPv4Forwarding.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_DIAG_IPPING, &objIid, ipPingObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(ipPingObj);
			return ret;
		}
		json_object_put(ipPingObj);
	}

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.TraceRouteDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.TraceRoute
 */
zcfgRet_t traceRtDiagObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *traceRtObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char devIpIface[48] = {0};
	char lowerLayer[32] = {0};
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_TRACE_RT, &objIid, &traceRtObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*special case*/
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(traceRtObj, paramList->name);
			strcpy(devIpIface, json_object_get_string(paramValue));
			if(!strcmp(devIpIface, "")) {
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			else {
				zcfgFeTr181IfaceStackLowerLayerGet(devIpIface, lowerLayer);
				if(strstr(lowerLayer, "PPP.Interface") != NULL) {
					strcpy(devIpIface, lowerLayer);
				}

				zcfgFe181To98MappingNameGet(devIpIface, tr98ObjName);
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98ObjName));
			}
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(traceRtObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}



		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}

	json_object_put(traceRtObj);

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.TraceRouteDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.TraceRoute
 */
zcfgRet_t traceRtDiagObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *traceRtObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char higherLayer[32] = {0};
	char devIpIface[48] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_TRACE_RT, &objIid, &traceRtObj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = traceRtObj;
		traceRtObj = NULL;
		traceRtObj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_DIAG_TRACE_RT, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				strcpy(tr98ConnObjName, json_object_get_string(paramValue));
				if(zcfgFe98To181MappingNameGet(tr98ConnObjName, devIpIface) != ZCFG_SUCCESS) {
					json_object_object_add(traceRtObj, paramList->name, json_object_new_string(""));
				}
				else {
					if(strstr(devIpIface, "PPP.Interface") != NULL) {
						zcfgFeTr181IfaceStackHigherLayerGet(devIpIface, higherLayer);
						strcpy(devIpIface, higherLayer);
					}
					
					json_object_object_add(traceRtObj, paramList->name, json_object_new_string(devIpIface));
				}
			}
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(traceRtObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(traceRtObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	/*Set Device.Routing.Router.1.IPv4Forwarding.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_DIAG_TRACE_RT, &objIid, traceRtObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(traceRtObj);
			return ret;
		}
		json_object_put(traceRtObj);
	}

	return ZCFG_SUCCESS;
}
/*
 *   TR98 Object Name : InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.i
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.TraceRoute.RouteHops.i
 */
zcfgRet_t routeHopsObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *rtHopObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char paramName[32] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	objIid.level = 1;
	sscanf(tr98FullPathName, "InternetGatewayDevice.TraceRouteDiagnostics.RouteHops.%hhu", &objIid.idx[0]);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_TRACERT_RT_HOPS, &objIid, &rtHopObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		sscanf(paramList->name, "Hop%s", paramName);

		printf("%s : paramName %s\n", __FUNCTION__, paramName);

		paramValue = json_object_object_get(rtHopObj, paramName);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}

	json_object_put(rtHopObj);

	return ZCFG_SUCCESS;
}

/*
 *   TR98 Object Name : InternetGatewayDevice.Capabilities.PerformanceDiagnostic
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.DownloadDiagnostics
 *   Device.IP.Diagnostics.UploadDiagnostics
 */
zcfgRet_t perfDiagObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *dlDiagObj = NULL;
	struct json_object *ulDiagObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	//char devIpIface[48] = {0};
	//char iface[40] = {0};
	//char lowerLayer[32] = {0};
	//char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_DL_DIAG, &objIid, &dlDiagObj)) != ZCFG_SUCCESS)
		return ret;

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_UL_DIAG, &objIid, &ulDiagObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {

		if(!strcmp(paramList->name, "DownloadTransports")) {
			paramValue = json_object_object_get(dlDiagObj, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			printf("Can't find parameter %s in TR181\n", paramList->name);
			paramList++;
		}
		else if (!strcmp(paramList->name, "UploadTransports"))
		{
			paramValue = json_object_object_get(ulDiagObj, paramList->name);
			if(paramValue != NULL) {
				json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}

			printf("Can't find parameter %s in TR181\n", paramList->name);
			paramList++;
		}
	}

	json_object_put(dlDiagObj);
	json_object_put(ulDiagObj);

	return ZCFG_SUCCESS;
}

/*
 *   TR98 Object Name : InternetGatewayDevice.DownloadDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.DownloadDiagnostics
 */
zcfgRet_t dlDiagObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *dlDiagObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char devIpIface[48] = {0};
	char iface[40] = {0};
	char lowerLayer[32] = {0};
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_DL_DIAG, &objIid, &dlDiagObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*special case*/
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(dlDiagObj, paramList->name);
			strcpy(devIpIface, json_object_get_string(paramValue));
			if(!strcmp(devIpIface, "")) {
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			else {
				strcpy(iface, devIpIface);
				zcfgFeTr181IfaceStackLowerLayerGet(iface, lowerLayer);
				if(strstr(lowerLayer, "PPP.Interface") != NULL) {
					strcpy(iface, lowerLayer);
				}
				zcfgFe181To98MappingNameGet(iface, tr98ObjName);
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98ObjName));
			}
			paramList++;
			continue;
		}
		
		paramValue = json_object_object_get(dlDiagObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}

	json_object_put(dlDiagObj);

	return ZCFG_SUCCESS;
}

/*
 *   TR98 Object Name : InternetGatewayDevice.DownloadDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.DownloadDiagnostics
 */
zcfgRet_t dlDiagObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *dlDiagObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char iface[40] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char higherLayer[32] = {0};
	char devIpIface[48] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_DL_DIAG, &objIid, &dlDiagObj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = dlDiagObj;
		dlDiagObj = NULL;
		dlDiagObj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_DIAG_DL_DIAG, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				strcpy(tr98ConnObjName, json_object_get_string(paramValue));
				if(zcfgFe98To181MappingNameGet(tr98ConnObjName, iface) != ZCFG_SUCCESS) {
					json_object_object_add(dlDiagObj, paramList->name, json_object_new_string(""));
				}
				else {
					if(strstr(iface, "PPP.Interface") != NULL) {
						zcfgFeTr181IfaceStackHigherLayerGet(iface, higherLayer);
						strcpy(iface, higherLayer);
					}
					
					strcpy(devIpIface, iface);
					json_object_object_add(dlDiagObj, paramList->name, json_object_new_string(devIpIface));
				}
			}
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(dlDiagObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(dlDiagObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	/*Set Device.Routing.Router.1.IPv4Forwarding.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_DIAG_DL_DIAG, &objIid, dlDiagObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(dlDiagObj);
			return ret;
		}
		json_object_put(dlDiagObj);
	}

	return ZCFG_SUCCESS;
}

/*
 *   TR98 Object Name : InternetGatewayDevice.UploadDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.UploadDiagnostics
 */
zcfgRet_t ulDiagObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *ulDiagObj = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char devIpIface[48] = {0};
	char iface[40] = {0};
	char lowerLayer[32] = {0};
	char tr98ObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_UL_DIAG, &objIid, &ulDiagObj)) != ZCFG_SUCCESS)
		return ret;

	*tr98Jobj = json_object_new_object();
	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*special case*/
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(ulDiagObj, paramList->name);
			strcpy(devIpIface, json_object_get_string(paramValue));
			if(!strcmp(devIpIface, "")) {
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(""));
			}
			else {
				strcpy(iface, devIpIface);
				zcfgFeTr181IfaceStackLowerLayerGet(iface, lowerLayer);
				if(strstr(lowerLayer, "PPP.Interface") != NULL) {
					strcpy(iface, lowerLayer);
				}
				zcfgFe181To98MappingNameGet(iface, tr98ObjName);
				json_object_object_add(*tr98Jobj, paramList->name, json_object_new_string(tr98ObjName));
			}
			paramList++;
			continue;
		}
		
		paramValue = json_object_object_get(ulDiagObj, paramList->name);
		if(paramValue != NULL) {
			json_object_object_add(*tr98Jobj, paramList->name, JSON_OBJ_COPY(paramValue));
			paramList++;
			continue;
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);
		paramList++;
	}

	json_object_put(ulDiagObj);

	return ZCFG_SUCCESS;
}

/*
 *   TR98 Object Name : InternetGatewayDevice.UploadDiagnostics
 *
 *   Related object in TR181:
 *   Device.IP.Diagnostics.UploadDiagnostics
 */
zcfgRet_t ulDiagObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj)
{
	zcfgRet_t ret;
	objIndex_t objIid;
	struct json_object *ulDiagObj = NULL;
	struct json_object *tmpObj = NULL;
	struct json_object *tr181ParamValue = NULL;
	struct json_object *paramValue = NULL;
	tr98Parameter_t *paramList = NULL;
	char iface[40] = {0};
	char tr98ConnObjName[TR98_MAX_OBJ_NAME_LENGTH] = {0};
	char higherLayer[32] = {0};
	char devIpIface[48] = {0};

	printf("%s : Enter\n", __FUNCTION__);

	IID_INIT(objIid);
	if((ret = zcfgFeObjJsonGet(RDM_OID_IP_DIAG_UL_DIAG, &objIid, &ulDiagObj)) != ZCFG_SUCCESS)
		return ret;

	if(multiJobj){
		tmpObj = ulDiagObj;
		ulDiagObj = NULL;
		ulDiagObj = zcfgFeJsonMultiObjAppend(RDM_OID_IP_DIAG_DL_DIAG, &objIid, multiJobj, tmpObj);
	}

	paramList = tr98Obj[handler].parameter;
	while(paramList->name != NULL) {
		/*Write new parameter value from tr98 object to tr181 objects*/		
		if(!strcmp(paramList->name, "Interface")) {
			paramValue = json_object_object_get(tr98Jobj, paramList->name);
			if(paramValue != NULL) {
				strcpy(tr98ConnObjName, json_object_get_string(paramValue));
				if(zcfgFe98To181MappingNameGet(tr98ConnObjName, iface) != ZCFG_SUCCESS) {
					json_object_object_add(ulDiagObj, paramList->name, json_object_new_string(""));
				}
				else {
					if(strstr(iface, "PPP.Interface") != NULL) {
						zcfgFeTr181IfaceStackHigherLayerGet(iface, higherLayer);
						strcpy(iface, higherLayer);
					}
					
					strcpy(devIpIface, iface);
					json_object_object_add(ulDiagObj, paramList->name, json_object_new_string(devIpIface));
				}
			}
			paramList++;
			continue;
		}

		paramValue = json_object_object_get(tr98Jobj, paramList->name);
		if(paramValue != NULL) {
			tr181ParamValue = json_object_object_get(ulDiagObj, paramList->name);
			if(tr181ParamValue != NULL) {
				json_object_object_add(ulDiagObj, paramList->name, JSON_OBJ_COPY(paramValue));
				paramList++;
				continue;
			}
		}

		printf("Can't find parameter %s in TR181\n", paramList->name);

		paramList++;	
	}

	/*Set Device.Routing.Router.1.IPv4Forwarding.i*/
	if(multiJobj){
		json_object_put(tmpObj);
	}
	else{
		if((ret = zcfgFeObjJsonSet(RDM_OID_IP_DIAG_UL_DIAG, &objIid, ulDiagObj, NULL)) != ZCFG_SUCCESS ) {
			json_object_put(ulDiagObj);
			return ret;
		}
		json_object_put(ulDiagObj);
	}

	return ZCFG_SUCCESS;
}

