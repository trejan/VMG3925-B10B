/*Parameter*/
extern tr98Parameter_t para_L2Br[];
extern tr98Parameter_t para_Br[];
extern tr98Parameter_t para_Port[];
extern tr98Parameter_t para_Vlan[];
extern tr98Parameter_t para_Filter[];
extern tr98Parameter_t para_Mark[];
extern tr98Parameter_t para_AvaiIntf[];

/*Handler Function*/
extern zcfgRet_t l2BridingObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);

extern zcfgRet_t l2BrObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t l2BrObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t l2BrObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t l2BrObjDel(char *tr98FullPathName);


extern zcfgRet_t l2BrFilterObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t l2BrFilterObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);
extern zcfgRet_t l2BrFilterObjAdd(char *tr98FullPathName, int *idx);
extern zcfgRet_t l2BrFilterObjDel(char *tr98FullPathName);

extern zcfgRet_t l2BrAvailableIntfObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);

extern zcfgRet_t l2BrVlanObjGet(char *tr98FullPathName, int handler, struct json_object **tr98Jobj);
extern zcfgRet_t l2BrVlanObjSet(char *tr98FullPathName, int handler, struct json_object *tr98Jobj, struct json_object *multiJobj);