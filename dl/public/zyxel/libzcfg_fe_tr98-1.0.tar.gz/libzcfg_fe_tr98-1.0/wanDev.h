/*Parameter*/
extern tr98Parameter_t para_WanDev[];
extern tr98Parameter_t para_WANDslDiag[];
extern tr98Parameter_t para_WANConnDev[];
extern tr98Parameter_t para_WANCommIfaceCfg[];
extern tr98Parameter_t para_WANDslIfaceCfg[];
extern tr98Parameter_t para_WANDslIfTestParam[];
extern tr98Parameter_t para_WANEthIntfConf[];
extern tr98Parameter_t para_WANEthIntfConfStat[];
extern tr98Parameter_t para_WANDslLinkConf[];
extern tr98Parameter_t para_WANPtmLinkConf[];
extern tr98Parameter_t para_WANPtmLinkConfStat[];
extern tr98Parameter_t para_WANEthLinkConf[];
extern tr98Parameter_t para_WANIpConn[];
extern tr98Parameter_t para_DhcpClient[];
extern tr98Parameter_t para_SentDhcpOpt[];
extern tr98Parameter_t para_ReqDhcpOpt[];
extern tr98Parameter_t para_WANIpPortMap[];
extern tr98Parameter_t para_WANIpConnStat[];
#ifdef IPV6INTERFACE_PROFILE
extern tr98Parameter_t para_WANIpv6Addr[];
extern tr98Parameter_t para_WANIpv6Prefix[];
#endif
#ifdef DHCPV6CLIENT_PROFILE
extern tr98Parameter_t para_WANIpDhcpV6Client[];
#endif
#ifdef IPV6RD_PROFILE
extern tr98Parameter_t para_WANIpv6Rd[];
#endif

extern tr98Parameter_t para_WANPppConn[];
extern tr98Parameter_t para_WANPppPortMap[];
extern tr98Parameter_t para_WANPppConnStat[];
#ifdef IPV6INTERFACE_PROFILE
extern tr98Parameter_t para_WANPppv6Addr[];
extern tr98Parameter_t para_WANPppv6Prefix[];
#endif
#ifdef DHCPV6CLIENT_PROFILE
extern tr98Parameter_t para_WANPppDhcpV6Client[];
#endif
#ifdef IPV6RD_PROFILE
extern tr98Parameter_t para_WANPppv6Rd[];
#endif
extern tr98Parameter_t para_WanAtmF5LoDiag[];
extern tr98Parameter_t para_WanAtmF4LoDiag[];

/*Handler Function*/
extern zcfgRet_t WANDeviceObjGet(char *, int, struct json_object **);

extern zcfgRet_t WANCommIfaceCfgObjGet(char *, int, struct json_object **);

/*InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig*/
extern zcfgRet_t WANDslIfaceCfgObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANDslIfaceCfgObjSet(char *, int, struct json_object *, struct json_object *);

/*InternetGatewayDevice.WANDevice.i.WANEthernetInterfaceConfig.TestParams*/
extern zcfgRet_t WANDslIfTestParamGet(char *, int, struct json_object **);

extern zcfgRet_t WANEthIfaceCfgObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANEthIfaceCfgObjSet(char *, int, struct json_object *, struct json_object *);

extern zcfgRet_t WANEthIfaceCfgStObjGet(char *, int, struct json_object **);

extern zcfgRet_t WANDslDiagObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANDslDiagObjSet(char *, int, struct json_object *, struct json_object *);

extern zcfgRet_t WANConnDevObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANConnDevObjAdd(char *, int *);
extern zcfgRet_t WANConnDevObjDel(char *);

extern zcfgRet_t WANDslLinkConfObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANDslLinkConfObjSet(char *, int, struct json_object *, struct json_object *);

extern zcfgRet_t WANPtmLinkConfObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANPtmLinkConfObjSet(char *, int, struct json_object *, struct json_object *);

extern zcfgRet_t WANPtmLinkConfStObjGet(char *, int, struct json_object **);

extern zcfgRet_t WANEthLinkConfObjGet(char *, int, struct json_object **);

extern zcfgRet_t WANIpConnObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANIpConnObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANIpConnObjAdd(char *, int *);
extern zcfgRet_t WANIpConnObjDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.DHCPClient */
extern zcfgRet_t DhcpClientObjGet(char *, int, struct json_object **);
extern zcfgRet_t DhcpClientSentOptObjGet(char *, int, struct json_object **);
extern zcfgRet_t DhcpClientSentOptObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t DhcpClientSentOptObjAdd(char *, int *);
extern zcfgRet_t DhcpClientSentOptObjDel(char *);
extern zcfgRet_t DhcpClientReqOptObjGet(char *, int, struct json_object **);
extern zcfgRet_t DhcpClientReqOptObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t DhcpClientReqOptObjAdd(char *, int *);
extern zcfgRet_t DhcpClientReqOptObjDel(char *);


extern zcfgRet_t WANPppConnObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANPppConnObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANPppConnObjAdd(char *, int *);
extern zcfgRet_t WANPppConnObjDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.PortMapping.i */
/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.PortMapping.i */
extern zcfgRet_t WANPortMappingGet(char *, int, struct json_object **);
extern zcfgRet_t WANPortMappingSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANPortMappingAdd(char *, int *);
extern zcfgRet_t WANPortMappingDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.Stats */
/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.Stats */
extern zcfgRet_t WANConnStObjGet(char *, int, struct json_object **);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANATMF5LoopbackDiagnostics*/
extern zcfgRet_t WANAtmF5LoConfObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANAtmF5LoConfObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.X_ZYXEL_WANATMF4LoopbackDiagnostics*/
extern zcfgRet_t WANAtmF4LoConfObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANAtmF4LoConfObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Address.i.*/
extern zcfgRet_t WANIpv6AddrObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANIpv6AddrObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANIpv6AddrObjAdd(char *, int *);
extern zcfgRet_t WANIpv6AddrObjDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6Prefix.i.*/
extern zcfgRet_t WANIpv6PrefixObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANIpv6PrefixObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANIpv6PrefixObjAdd(char *, int *);
extern zcfgRet_t WANIpv6PrefixObjDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_DHCPv6Client.*/
extern zcfgRet_t WANIpv6DhcpV6ObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANIpv6DhcpV6ObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANIPConnection.i.X_ZYXEL_IPv6rd..*/
extern zcfgRet_t WANIpv6RdObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANIpv6RdObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Address.i.*/
extern zcfgRet_t WANPppv6AddrObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANPppv6AddrObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANPppv6AddrObjAdd(char *, int *);
extern zcfgRet_t WANPppv6AddrObjDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6Prefix.i.*/
extern zcfgRet_t WANPppv6PrefixObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANPppv6PrefixObjSet(char *, int, struct json_object *, struct json_object *);
extern zcfgRet_t WANPppv6PrefixObjAdd(char *, int *);
extern zcfgRet_t WANPppv6PrefixObjDel(char *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_DHCPv6Client.*/
extern zcfgRet_t WANPppv6DhcpV6ObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANPppv6DhcpV6ObjSet(char *, int, struct json_object *, struct json_object *);

/* InternetGatewayDevice.WANDevice.i.WANConnectionDevice.i.WANPPPConnection.i.X_ZYXEL_IPv6rd..*/
extern zcfgRet_t WANPppv6RdObjGet(char *, int, struct json_object **);
extern zcfgRet_t WANPppv6RdObjSet(char *, int, struct json_object *, struct json_object *);

