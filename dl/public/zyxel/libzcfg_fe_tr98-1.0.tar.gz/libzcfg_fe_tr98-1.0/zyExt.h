/*Parameter*/
extern tr98Parameter_t para_DnsRtEntry[];
extern tr98Parameter_t para_DDns[];

/*Handler Function*/

/*InternetGatewayDevice.X_ZYXEL_EXT.DNSRouteEntry.i*/
extern zcfgRet_t zyExtDnsRtObjGet(char *, int, struct json_object **);
extern zcfgRet_t zyExtDnsRtObjSet(char *, int , struct json_object *, struct json_object *);
extern zcfgRet_t zyExtDnsRtObjAdd(char *, int *);
extern zcfgRet_t zyExtDnsRtObjDel(char *);

/*InternetGatewayDevice.X_ZYXEL_EXT.DynamicDNS*/
extern zcfgRet_t zyExtDDnsObjGet(char *, int, struct json_object **);
extern zcfgRet_t zyExtDDnsObjSet(char *, int, struct json_object *, struct json_object *);