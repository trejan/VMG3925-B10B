#ifndef _ZCFG_FE_RDM_ACCESS_H
#define _ZCFG_FE_RDM_ACCESS_H
#include "zcfg_msg.h"
/*
 *  Provide the API for front end process to communicate with
 *  zcmd.
 */
zcfgRet_t zcfgFeSharedMemInit();
zcfgRet_t zcfgFeObjRead(zcfg_offset_t, objIndex_t *, uint32_t, char **);
zcfgRet_t zcfgFeObjWrite(zcfg_offset_t, objIndex_t *, char *, uint32_t, char *);

zcfgRet_t zcfgFeReqSend(uint32_t, char *);

#define zcfgFeDelayApply(payload)       zcfgFeReqSend(ZCFG_MSG_DELAY_APPLY, payload)
#define zcfgFeReApply()                 zcfgFeReqSend(ZCFG_MSG_RE_APPLY, NULL)
#define zcfgFeFwUpgrade(payload)        zcfgFeReqSend(REQUEST_FIRMWARE_UPGRADE, payload)
#define zcfgFeRestoreDefault(payload)   zcfgFeReqSend(REQUEST_RESTORE_DEFAULT, payload)
#define zcfgFeRomdUpgrade(payload)      zcfgFeReqSend(REQUEST_ROMD_UPGRADE, payload)
#define zcfgFeConfBackup()              zcfgFeReqSend(REQUEST_CONFIG_BACKUP, NULL)
#define zcfgFeAutoProvision(payload)    zcfgFeReqSend(ZCFG_MSG_AUTO_PROVISION, payload)
#define zcfgFeResetWan(payload)         zcfgFeReqSend(REQUEST_REINIT_MACLESS_PROVISIONING, payload)

/*TR98 support*/
zcfgRet_t zcfgFeMappingNameGet(uint32_t msgType, char *fullPathName, char *result);

#define zcfgFe98To181MappingNameGet(fullPathName, result) zcfgFeMappingNameGet(ZCFG_MSG_REQUEST_TR98_MAPPING, fullPathName, result)
#define zcfgFe181To98MappingNameGet(fullPathName, result) zcfgFeMappingNameGet(ZCFG_MSG_REQUEST_TR181_MAPPING, fullPathName, result)
/*End of TR98 support*/

#endif
