#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <errno.h>

#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcmd_schema.h"
#include "zcmd_tool.h"
#include "zcfg_msg.h"
#include "zcfg_eid.h"
#include "zcfg_debug.h"

void *schemaShmAddr = NULL;
void *objNameShmAddr = NULL;
void *paramNameShmAddr = NULL;
int shmid;
int schemaShmSize = 0;

extern int myEid;
/*
 *  Function Name: zcfgFeSharedMemInit
 *  Description: Used by front-end process to attach the shared memory.
 *               By doing so, the front-end process just can get object
 *               and parameter information stored in shared memory.
 *
 */
zcfgRet_t zcfgFeSharedMemInit()
{
	key_t key = ftok(ZCFG_SHM_KEY, 0);
	int size;
	FILE *fptr;
	char *objFileName = "/etc/zcfg_objName.bin";
	char *paramFileName = "/etc/zcfg_paramName.bin";

	//zcfgLog(ZCFG_LOG_INFO, "key %d\n", (int)key);

	if((fptr = fopen("/var/shm_size", "r")) == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "Can't open \"/var/shm_size\" to read shared memory size\n");
		return ZCFG_INTERNAL_ERROR;
	}
	else {
		fscanf(fptr, "%d", &size);
		schemaShmSize = size;
	}

	fclose(fptr);

	if ((shmid = shmget(key, size, IPC_CREAT | 0666)) < 0) {
		perror("shmget:");
		zcfgLog(ZCFG_LOG_ERR, "\ncannot create shared memory\n");
		return ZCFG_INTERNAL_ERROR;
	}

	if ((schemaShmAddr = shmat(shmid, NULL, 0)) == (char *) -1) {
		perror("shmat:");
		zcfgLog(ZCFG_LOG_ERR, "\ncannot attach shared memory\n");
		return ZCFG_INTERNAL_ERROR;
	}

	zcfgLog(ZCFG_LOG_NOTICE, "Attached to schema shared memory\n");

	/*attach to object name shared memory buffer*/
	key = ftok(objFileName, 0);

	if((fptr = fopen(objFileName, "rb")) == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "Can't fopen %s\n", objFileName);
		return ZCFG_INTERNAL_ERROR;
	}
	else {
		fseek(fptr, 0L, SEEK_END);
		size = ftell(fptr);
		fseek(fptr, 0L, SEEK_SET);
	}

	fclose(fptr);

	if ((shmid = shmget(key, size, IPC_CREAT | 0666)) < 0) {
		perror("shmget:");
		zcfgLog(ZCFG_LOG_ERR, "\ncannot create shared memory\n");
		return ZCFG_INTERNAL_ERROR;
	}

	if (( objNameShmAddr = shmat(shmid, NULL, 0)) == (char *) -1) {
		perror("shmat:");
		zcfgLog(ZCFG_LOG_ERR, "\ncannot attach shared memory\n");
		return ZCFG_INTERNAL_ERROR;
	}

	zcfgLog(ZCFG_LOG_NOTICE, "Attached to object name shared memory\n");

	/*attach to parameter name shared memory buffer*/
	key = ftok(paramFileName, 0);

	if((fptr = fopen(paramFileName, "rb")) == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "Can't fopen %s\n", paramFileName);
		return ZCFG_INTERNAL_ERROR;
	}
	else {
		fseek(fptr, 0L, SEEK_END);
		size = ftell(fptr);
		fseek(fptr, 0L, SEEK_SET);
	}

	fclose(fptr);

	if ((shmid = shmget(key, size, IPC_CREAT | 0666)) < 0) {
		perror("shmget:");
		zcfgLog(ZCFG_LOG_ERR, "\ncannot create shared memory\n");
		return ZCFG_INTERNAL_ERROR;
	}

	if (( paramNameShmAddr = shmat(shmid, NULL, 0)) == (char *) -1) {
		perror("shmat:");
		zcfgLog(ZCFG_LOG_ERR, "\ncannot attach shared memory\n");
		return ZCFG_INTERNAL_ERROR;
	}

	zcfgLog(ZCFG_LOG_NOTICE, "Attached to parameter name shared memory\n");

	return ZCFG_SUCCESS;
}
/*
 *  Function Name: zcfgFeObjRead
 *  Description: Used by front-end process to send request message
 *               to ZCMD to get object.
 *
 */
zcfgRet_t zcfgFeObjRead(zcfg_offset_t oid, objIndex_t *objIid, uint32_t type, char **result)
{
	zcfgRet_t ret;
	char *recvStr = NULL;
	void *recvBuf = NULL;
	zcfgMsg_t *sendMsgHdr = NULL;
	zcfgMsg_t *recvMsgHdr = NULL;

	if(myEid == -1) {
		zcfgLog(ZCFG_LOG_ERR, "Invalid eid\n");
		return ZCFG_INVALID_EID;
	}

	if(schemaShmAddr == NULL)
		zcfgFeSharedMemInit();

	sendMsgHdr = (zcfgMsg_t *)malloc(sizeof(zcfgMsg_t));
	sendMsgHdr->type = type;
	/*No payload*/
	sendMsgHdr->length = 0;
	memcpy(sendMsgHdr->objIid, objIid, sizeof(objIndex_t));
	sendMsgHdr->oid = oid;
	sendMsgHdr->srcEid = myEid;
	sendMsgHdr->dstEid = ZCFG_EID_ZCMD;

	ret = zcfgMsgSendAndGetReply(sendMsgHdr, (zcfgMsg_t **)&recvBuf, 0);

	if(ret == ZCFG_SUCCESS) {
		recvMsgHdr = (zcfgMsg_t*)recvBuf;

		if(recvMsgHdr->type == RESPONSE_GET_FAIL) {
			ret = recvMsgHdr->statCode;
			if(ret == ZCFG_NO_SUCH_OBJECT)
				memcpy(objIid, recvMsgHdr->objIid, sizeof(objIndex_t));
		}
		else if(recvMsgHdr->type == RESPONSE_NO_MORE_INSTANCE) {
			ret = ZCFG_NO_MORE_INSTANCE;
		}
		else {
			memcpy(objIid, recvMsgHdr->objIid, sizeof(objIndex_t));
			/*Get json string from message*/
			recvStr = (char *)(recvBuf+sizeof(zcfgMsg_t));

			*result = (char *)malloc(strlen(recvStr)+1);
			strcpy(*result, recvStr);

			if(recvMsgHdr->type == RESPONSE_GET_SUCCESS)
				ret = ZCFG_SUCCESS;
			else
				ret = ZCFG_EMPTY_OBJECT;
		}
	}

	free(recvBuf);
	return ret;	
}
/*
 *  Function Name: zcfgFeObjWrite
 *  Description: Used by front-end process to send request message
 *               to ZCMD to write object in the data model.
 *
 */
zcfgRet_t zcfgFeObjWrite(zcfg_offset_t oid, objIndex_t *objIid, char *setValue, uint32_t type, char *feedbackMsg)
{
	zcfgRet_t ret;
	int len = 0;
	char *recvStr = NULL;
	void *sendBuf = NULL;
	void *recvBuf = NULL;
	zcfgMsg_t *sendMsgHdr = NULL;
	zcfgMsg_t *recvMsgHdr = NULL;	

	if(myEid == -1) {
		zcfgLog(ZCFG_LOG_ERR, "Invalid eid\n");
		return ZCFG_INVALID_EID;
	}

	if(schemaShmAddr == NULL)
		zcfgFeSharedMemInit();

	if(setValue != NULL)
		len = strlen(setValue) + 1;

	sendBuf = (void *)malloc(sizeof(zcfgMsg_t) + len);
	sendMsgHdr = (zcfgMsg_t *)sendBuf;
	sendMsgHdr->type = type;
	sendMsgHdr->length = len;
	memcpy(sendMsgHdr->objIid, objIid, sizeof(objIndex_t));
	sendMsgHdr->oid = oid;
	sendMsgHdr->srcEid = myEid;
	sendMsgHdr->dstEid = ZCFG_EID_ZCMD;

	if(setValue != NULL)
		strcpy((char *)(sendMsgHdr + 1), setValue);

	ret = zcfgMsgSendAndGetReply(sendBuf, (zcfgMsg_t **)&recvBuf, 0);

	if(ret == ZCFG_SUCCESS) {
		recvMsgHdr = (zcfgMsg_t*)recvBuf;

		if(recvMsgHdr->type == RESPONSE_WRITE_OBJ_SUCCESS) {
			memcpy(objIid, recvMsgHdr->objIid, sizeof(objIndex_t));
			ret = ZCFG_SUCCESS;
		}
		else {
			/*Check if there is a feedback error message*/
			if( recvMsgHdr->length > 0 ) {
				recvStr = (char *)(recvBuf+sizeof(zcfgMsg_t));
				if(feedbackMsg != NULL) {
					strcpy(feedbackMsg, recvStr);
				}
			}
			ret = recvMsgHdr->statCode;
		}
	}

	free(recvBuf);
	return ret;
}

zcfgRet_t zcfgFeReqSend(uint32_t msgType, char *payload)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	int payloadLen = 0;
	void *sendBuf = NULL;
	void *recvBuf = NULL;
	zcfgMsg_t *sendMsgHdr = NULL;
	zcfgMsg_t *recvMsgHdr = NULL;

	switch(msgType) {
		case ZCFG_MSG_DELAY_APPLY:
		case REQUEST_FIRMWARE_UPGRADE:
		case REQUEST_ROMD_UPGRADE:
			if(payload == NULL || strlen(payload) == 0)
				return ZCFG_INVALID_ARGUMENTS;

			payloadLen = strlen(payload)+1;
			break;
		case REQUEST_RESTORE_DEFAULT:
		case REQUEST_CONFIG_BACKUP:
		case ZCFG_MSG_RE_APPLY:
		case ZCFG_MSG_AUTO_PROVISION:
		case REQUEST_REINIT_MACLESS_PROVISIONING:
			if(payload == NULL || strlen(payload) == 0)
				payloadLen = 0;
			else
				payloadLen = strlen(payload)+1;
			break;
		default:
			return ZCFG_INVALID_PARAM_VALUE;
	}

	sendBuf = (void *)malloc(sizeof(zcfgMsg_t) + payloadLen);
	sendMsgHdr = (zcfgMsg_t *)sendBuf;
	sendMsgHdr->type = msgType;
	sendMsgHdr->length = payloadLen;
	sendMsgHdr->dstEid = ZCFG_EID_ZCMD;

	if(payloadLen > 0)
		strcpy((char *)(sendMsgHdr + 1), payload);

	ret = zcfgMsgSendAndGetReply(sendMsgHdr, (zcfgMsg_t **)&recvBuf, 0);
	if(ret == ZCFG_SUCCESS) {
		recvMsgHdr = (zcfgMsg_t*)recvBuf;
		if ( recvMsgHdr->type == RESPONSE_FAIL ) {
			ret = recvMsgHdr->statCode;
		}
	}
	else if(ret == ZCFG_SUCCESS_AND_NO_REPLY) {
		ret = ZCFG_SUCCESS;
	}
	else {
		return ZCFG_INTERNAL_ERROR;
	}

	free(recvBuf);
	return ret;
}

#ifdef ZCFG_TR98_SUPPORT
zcfgRet_t zcfgFeMappingNameGet(uint32_t msgType, char *fullPathName, char *result)
{
	zcfgRet_t ret;
	int payloadLen = 0;
	char *recvStr = NULL;
	void *sendBuf = NULL;
	void *recvBuf = NULL;
	zcfgMsg_t *sendMsgHdr = NULL;
	zcfgMsg_t *recvMsgHdr = NULL;

	if(fullPathName != NULL) {
		payloadLen = strlen(fullPathName) + 1;
	}
	else {
		return ZCFG_INTERNAL_ERROR;
	}

	if(payloadLen == 0)
		return ZCFG_INVALID_ARGUMENTS;

	sendBuf = (void *)malloc(sizeof(zcfgMsg_t) + payloadLen);
	sendMsgHdr = (zcfgMsg_t *)sendBuf;
	sendMsgHdr->type = msgType;
	sendMsgHdr->length = payloadLen;
	sendMsgHdr->dstEid = ZCFG_EID_ZCMD;

	strcpy((char *)(sendMsgHdr + 1), fullPathName);

	ret = zcfgMsgSendAndGetReply(sendMsgHdr, (zcfgMsg_t **)&recvBuf, 0);

	if(ret == ZCFG_SUCCESS) {
		recvMsgHdr = (zcfgMsg_t*)recvBuf;
		if ( recvMsgHdr->type == RESPONSE_FAIL ) {
			return ZCFG_INTERNAL_ERROR;
		}
		else {
			if( recvMsgHdr->length > 0 ) {
				recvStr = (char *)(recvBuf+sizeof(zcfgMsg_t));
				strcpy(result, recvStr);
			}	
		}
		
		free(recvBuf);
	}
	else
		return ZCFG_INTERNAL_ERROR;

	return ZCFG_SUCCESS;	
}
#endif
