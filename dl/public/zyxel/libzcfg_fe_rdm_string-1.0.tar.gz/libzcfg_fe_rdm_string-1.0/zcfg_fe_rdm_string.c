#include <ctype.h>

#include <json/json.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_access.h"
#include "zcfg_fe_rdm_string.h"
#include "zcmd_schema.h"
#include "zcfg_msg.h"
#include "zcfg_debug.h"

extern void *schemaShmAddr;
extern void *objNameShmAddr;
extern void *paramNameShmAddr;
extern int schemaShmSize;
/*
 *  Function Name: zcfgFeObjNameToObjId
 *  Description: Translate the object name to object id
 *
 */
int zcfgFeObjNameToObjId(char *objName, objIndex_t *objIid)
{
	char *token = NULL;
	char *fullPathName = NULL;
	char *tmpName = NULL;
	char *name = NULL;
	uint8_t level = 0;
	uint16_t len = 0, c = 0, paramCount = 0;
	uint32_t oid = 0;
	objInfo_t *objInfo = NULL;
	bool find = false;
#if 0
#ifdef ZCFG_TR98_SUPPORT
	if(strstr(objName, "InternetGatewayDevice") != NULL) {
		printf("A TR98 data model\n");
		return ZCFG_TR98_DATA_MODEL;
	}
#endif
#endif
	if(schemaShmAddr == NULL)
		zcfgFeSharedMemInit();

	if(objName == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "Object Name is NULL\n");
		return ZCFG_NO_SUCH_OBJECT;
	}

	fullPathName = (char *)malloc(strlen(objName)+1);
	tmpName = (char *)malloc(strlen(objName)+1);
	strcpy(tmpName, objName);

	token = strtok(tmpName, ".");
	/*InternetGatewayDevice*/
	strcpy(fullPathName, token);
	token = strtok(NULL, ".");

	while(token != NULL) {
		strcat(fullPathName, ".");

		len = strlen(token);
		for(c = 0; c < len; c++) {
			if(!isdigit(*(token + c)))
				break;
		}

		if(len == c) {
			strcat(fullPathName, "i");
			objIid->idx[level++] = atoi(token);
		}
		else {
			strcat(fullPathName, token);
		}

		token = strtok(NULL, ".");
	}

	objIid->level = level;

	while(oid < schemaShmSize) {
		objInfo = GET_OBJ_INFO_BY_OID(oid);
		name = GET_OBJ_NAME(objInfo);

		if(strcmp(fullPathName, name) == 0) {
			find = true;
			break;
		}
		else {
			paramCount = objInfo->count;
			oid = oid + sizeof(objInfo_t) + paramCount*sizeof(parameterInfo_t);
		}
	}

	free(fullPathName);
	free(tmpName);

	if(!find) {
		zcfgLog(ZCFG_LOG_ERR, "Can't find OID by object name %s\n", objName);
		return ZCFG_NO_SUCH_OBJECT;
	}

	return oid;
}
/*
 *  Function Name: zcfgFeParamValGet 
 *  Description: Get a parameter value from the json object get from zcmd.
 *  Parameters: value: the json object contains data values and is get from zcmd.
 *
 *  Return value : 1. NULL : the parameter doesn't exist in json object
 *                 2. All the return values are string format
 */
char* zcfgFeParamValGet(struct json_object *value, char *parameterName)
{
	struct json_object *paramVal = NULL;

	paramVal = json_object_object_get(value, parameterName);
	if(paramVal == NULL)
		return NULL;

	switch(json_object_get_type(paramVal)) {
		case json_type_boolean:
			if(json_object_get_boolean(paramVal))
				return "1";
			else
				return "0";
		case json_type_string:
			return (char *)json_object_get_string(paramVal);
		case json_type_int:
			return (char *)json_object_to_json_string(paramVal);
		default:
			return NULL;
	}
}
/*
 *  Function Name: zcfgFeParamChk 
 *  Description: Check the type of parameter to be set is valid or not
 *
 *  Return value : 1. ZCFG_SUCCESS
 *                 2. ZCFG_ERROR_PARAMETER_TYPE : the parameter type is difference from the definition in schema
 *                 3. ZCFG_NO_SUCH_PARAMETER : the parameter name to set can not be found in schema
 *                 4. ZCFG_SET_READ_ONLY_PARAM : set a read-only parameter
 *		   5. ZCFG_INVALID_PARAM_VALUE_LENGTH : the value length is invalid
 */
static zcfgRet_t zcfgFeParamChk(zcfg_offset_t oid, char *parameterName, uint32_t type, char *value)
{
	objInfo_t *objInfo = NULL;
	int strLen = 0;
	char *p = NULL;
	int index = 0;
	
	objInfo = GET_OBJ_INFO_BY_OID(oid);

	GET_PAMAMETERS_IN_OBJECT(objInfo, paramInfo, paramName) {
		if(strcmp(paramName, parameterName) == 0) {
			if(paramInfo->attr & PARAMETER_ATTR_READONLY) {
				zcfgLog(ZCFG_LOG_ERR, "Can not set a read-only parameter %s\n", paramName);
				return ZCFG_SET_READ_ONLY_PARAM;
			}

			if(type != paramInfo->type) {
				if( type == json_type_string && paramInfo->type==json_type_hex){
					/*pass*/
				}
				else{
					zcfgLog(ZCFG_LOG_ERR, "Invalid type %d for parameter %s, the correct type should be %d\n", type, parameterName, paramInfo->type);
					return ZCFG_ERROR_PARAMETER_TYPE;
				}
			}

			if(type == json_type_string || type == json_type_time) {
				strLen = strlen(value);
				if(strLen >= paramInfo->len) {
					zcfgLog(ZCFG_LOG_ERR, "The value length of %s is %d greater than %d defined in schema\n", parameterName, strLen, paramInfo->len);
					return ZCFG_INVALID_PARAM_VALUE_LENGTH;
				}
			}

			/*validate formate*/
			switch(type){
				case json_type_int:
					p = value;
					if(atol(value)<0){
						if(*p != '-'){
							return ZCFG_INVALID_PARAM_VALUE;
						}
						p++;
					}
					while(*p!='\0'){
						if(!isdigit(*p)){
							return ZCFG_INVALID_PARAM_VALUE;
						}
						p++;
					}
					break;
				case json_type_uint8:
				case json_type_uint16:
				case json_type_uint32:
					p = value;
					while(*p!='\0'){
						if(!isdigit(*p)){
							return ZCFG_INVALID_PARAM_VALUE;
						}
						p++;
					}
					break;
				case json_type_boolean:
					if(strcasecmp(value, "true")==0 ){
						strcpy(value, "1");
						break;
					}
					else if(strcasecmp(value, "false")==0 ){
						strcpy(value, "0");
						break;
					}

					if( (strcmp(value, "0")!=0) && (strcmp(value, "1")!=0)){
						return ZCFG_INVALID_PARAM_VALUE;
					}
					break;
			
				case json_type_time:/*0001-01-01T00:00:00Z*/
					strLen = strlen(value);
					if(strLen != 19 && strLen != 20){
						return ZCFG_INVALID_PARAM_VALUE;
					}
					p = value;
					for(index = 0; index<strLen; index++){
						if(index==4 || index==7){
							if(!(*p == '-')){
								return ZCFG_INVALID_PARAM_VALUE;
							}
						}
						else if(index == 10){
							if(!(*p == 'T')){
								return ZCFG_INVALID_PARAM_VALUE;
							}
						}
						else if(index == 13 || index ==16){
							if(!(*p == ':')){
								return ZCFG_INVALID_PARAM_VALUE;
							}
						}
						else if(index == 19){
							if(!(*p == 'Z')){
								return ZCFG_INVALID_PARAM_VALUE;
							}
						}
						else{
							if(!isdigit(*p)){
								return ZCFG_INVALID_PARAM_VALUE;
							}
						}	
						p++;
					}
					break;
				default:
					break;
			}
			
			return ZCFG_SUCCESS;
		}
	}

	zcfgLog(ZCFG_LOG_ERR, "There is no parameter '%s' in schema\n", parameterName);
	return ZCFG_NO_SUCH_PARAMETER;
}
/*
 *  Function Name: zcfgFeJsonObjParamSet
 *  Description: Set the parameter value in a json object
 *  Parameters: json : a json object which contains data values 
 *
 *  Return value : 1. ZCFG_SUCCESS
 *                 2. ZCFG_INTERNAL_ERROR
 *                 3. ZCFG_ERROR_PARAMETER_TYPE : the parameter type is difference from the definition in schema
 *                 4. ZCFG_NO_SUCH_PARAMETER : the parameter name cannot be found in schema
 *                 5. ZCFG_SET_READ_ONLY_PARAM : set a read-only parameter
 *                 6. ZCFG_INVALID_PARAM_VALUE_LENGTH : the value length is invalid
 */
zcfgRet_t zcfgFeJsonObjParamSet(zcfg_offset_t oid, char *paramName, uint32_t type, struct json_object *setJobj, char *value)
{
	zcfgRet_t ret;
	struct json_object *setValue = NULL;
	
	zcfgLog(ZCFG_LOG_DEBUG, "Parameter Name %s %s\n", paramName, value);

	if(setJobj == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "The setJobj pointer is NULL value\n");
		return ZCFG_INTERNAL_ERROR;
	}

	ret = zcfgFeParamChk(oid, paramName, type, value);

	if(ret != ZCFG_SUCCESS) 
		return ret;

	switch (type) {
		case json_type_boolean:
			setValue = json_object_new_boolean(atoi(value));
			break;
		case json_type_int:
			setValue = json_object_new_int(atoi(value));
			break;
		case json_type_uint32:
			setValue = json_object_new_int((uint32_t)atoi(value));
			break;
		case json_type_string:
			setValue = json_object_new_string(value);
			break;
		case json_type_time:
			setValue = json_object_new_string(value);
			break;
		default:
			zcfgLog(ZCFG_LOG_ERR, "Type not support\n");
			return ZCFG_ERROR_PARAMETER_TYPE;
			break;
	}

	json_object_object_add(setJobj, paramName, setValue);
	return ZCFG_SUCCESS;
}
/*
 *  Function Name: zcfgFeJsonMultiObjAppend 
 *  Description: append a single json onject to multiple json object with following format
 *  Parameters: multiJobj : a json object which contains multiple data objects to be set
 *   
 *  Multiple object format: {
 *                            "OID_1" : { "objIid_1_1" : {set_object1_1},
 *                                        "objIid_1_2" : {set_object1_2},                     
 *                                                     .
 *                                                     .
 *                                      },
 *                                      .
 *                                      .
 *                          }
 */
json_object* zcfgFeJsonMultiObjAppend(zcfg_offset_t oid, objIndex_t *objIid, json_object *multiJobj, json_object *jobj)
{
	struct json_object *newOidJobj = NULL;
	struct json_object *oidJobj = NULL;
	struct json_object *iidJobj = NULL;
	struct json_object *dupJobj = NULL;
	char objIndexID[32];
	char objID[16];

	if(multiJobj == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "The multiJobj pointer is NULL value\n");
		return NULL;
	}

	sprintf(objIndexID, "%d.%d.%d.%d.%d.%d.%d", objIid->level, objIid->idx[0], objIid->idx[1], objIid->idx[2], objIid->idx[3], objIid->idx[4], objIid->idx[5]);
	sprintf(objID, "%d", oid);

	/*Check if there is already a same OID object exist or not*/
	oidJobj = json_object_object_get(multiJobj, objID);
	if(oidJobj != NULL) {
		/*Get the object to be set by iid*/
		iidJobj = json_object_object_get(oidJobj, objIndexID);
		if(iidJobj != NULL) {
			return iidJobj;
		}
		else {
			/*Duplicate the json object that is going to be set*/
			dupJobj = json_tokener_parse(json_object_to_json_string(jobj));
			/*Add the new data object to be set to multiple json object*/
			json_object_object_add(oidJobj, objIndexID, dupJobj);
			return dupJobj;
		}
	}
	else {
		newOidJobj = json_object_new_object();
		json_object_object_add(multiJobj, objID, newOidJobj);
		/*Duplicate the json object is going to be set*/
		dupJobj = json_tokener_parse(json_object_to_json_string(jobj));
		/*Add the new data object to be set to multiple json object*/
		json_object_object_add(newOidJobj, objIndexID, dupJobj);
		return dupJobj;
	}
}

zcfgRet_t zcfgFeObjJsonGetNext(zcfg_offset_t oid, objIndex_t *objIid, struct json_object **value)
{
	zcfgRet_t ret;
	char *result;

	ret = zcfgFeObjRead(oid, objIid, REQUEST_GET_NEXT_OBJ, &result);

	if(ret != ZCFG_INTERNAL_ERROR && ret != ZCFG_NO_MORE_INSTANCE) {
		*value = json_tokener_parse(result);
		free(result);
	}

	return ret;
}

zcfgRet_t zcfgFeObjJsonGet(zcfg_offset_t oid, objIndex_t *objIid, struct json_object **value)
{
	zcfgRet_t ret;
	char *result;

	ret = zcfgFeObjRead(oid, objIid, REQUEST_GET_OBJ, &result);

	if(ret == ZCFG_SUCCESS) {
		*value = json_tokener_parse(result);
		free(result);
	}

	return ret;
}

zcfgRet_t zcfgFeObjJsonGetWithoutUpdate(zcfg_offset_t oid, objIndex_t *objIid, struct json_object **value)
{
        zcfgRet_t ret;
        char *result;

        ret = zcfgFeObjRead(oid, objIid, REQUEST_GET_OBJ_WITHOUT_UPDATE, &result);

        if(ret == ZCFG_SUCCESS) {
		*value = json_tokener_parse(result);
                free(result);
        }

        return ret;
}

zcfgRet_t zcfgFeSubInObjJsonGetNext(zcfg_offset_t oid, objIndex_t *objIid, objIndex_t *insIid, struct json_object **value)
{
        zcfgRet_t ret;
        char *result = NULL;

        if(objIid->level >= insIid->level) {
                memcpy(insIid, objIid, sizeof(objIndex_t));
                insIid->level++;
        }

        insIid->idx[insIid->level-1]++;

        ret = zcfgFeObjRead(oid, insIid, REQUEST_GET_NEXT_SUB, &result);

        if(ret == ZCFG_SUCCESS) {
                /*Translate json string to user request structure*/
                *value = json_tokener_parse(result);
                free(result);
        }

        return ret;
}

zcfgRet_t zcfgFeObjJsonSet(zcfg_offset_t oid, objIndex_t *objIid, struct json_object *jobj, char *fbkMsg)
{
        zcfgRet_t ret;
	char *value = NULL;

	value = (char *)json_object_to_json_string(jobj);

	if(value == NULL)
		return ZCFG_INTERNAL_ERROR;

	ret = zcfgFeObjWrite(oid, objIid, value, REQUEST_SET_OBJ, fbkMsg);
        return ret;
}

zcfgRet_t zcfgFeObjJsonSetWithoutApply(zcfg_offset_t oid, objIndex_t *objIid, struct json_object *jobj, char *fbkMsg)
{
	zcfgRet_t ret;
	char *value = NULL;

	value = (char *)json_object_to_json_string(jobj);

	if(value == NULL)
		return ZCFG_INTERNAL_ERROR;

	ret = zcfgFeObjWrite(oid, objIid, value, REQUEST_SET_WITHOUT_APPLY, fbkMsg);
	return ret;
}

zcfgRet_t zcfgFeMultiObjJsonSet(struct json_object *multiJobj, char *feedbackMsg)
{
	zcfgRet_t ret;
	char *value = NULL;
	objIndex_t objIid;

	value = (char *)json_object_to_json_string(multiJobj);

	if(value == NULL)
		return ZCFG_INTERNAL_ERROR;

	IID_INIT(objIid);
	ret = zcfgFeObjWrite(0, &objIid, value, REQUEST_SET_MULTI_OBJ, feedbackMsg);

	return ret;
}

zcfgRet_t zcfgFeObjJsonAdd(zcfg_offset_t oid, objIndex_t *objIid, char *feedbackMsg)
{
	zcfgRet_t ret;

	ret = zcfgFeObjWrite(oid, objIid, NULL, REQUEST_ADD_INSTANCE, feedbackMsg);

	return ret;
}

zcfgRet_t zcfgFeObjJsonDel(zcfg_offset_t oid, objIndex_t *objIid, char *feedbackMsg)
{
	zcfgRet_t ret;

	ret = zcfgFeObjWrite(oid, objIid, NULL, REQUEST_DEL_INSTANCE, feedbackMsg);

	return ret;
}
