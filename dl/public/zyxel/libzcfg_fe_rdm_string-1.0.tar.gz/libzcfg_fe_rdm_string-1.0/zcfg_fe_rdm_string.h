typedef struct multiObjInfo_s {
	uint32_t oid;
	objIndex_t objIid[1];
	struct json_object *setObj;
} multiObjInfo_t;

int zcfgFeObjNameToObjId(char *, objIndex_t *);
zcfgRet_t zcfgFeJsonObjGen(zcfg_offset_t, char *, uint32_t, struct json_object *, void *);
zcfgRet_t zcfgFeJsonObjParamSet(zcfg_offset_t, char *, uint32_t, struct json_object *, char *);
zcfgRet_t zcfgFeObjJsonGetNext(zcfg_offset_t, objIndex_t *, struct json_object **);
zcfgRet_t zcfgFeObjJsonGet(zcfg_offset_t, objIndex_t *, struct json_object **);
zcfgRet_t zcfgFeObjJsonGetWithoutUpdate(zcfg_offset_t, objIndex_t *, struct json_object **);
zcfgRet_t zcfgFeSubInObjJsonGetNext(zcfg_offset_t oid, objIndex_t *objIid, objIndex_t *insIid, struct json_object **value);
zcfgRet_t zcfgFeObjJsonSet(zcfg_offset_t, objIndex_t *, struct json_object *, char *);
zcfgRet_t zcfgFeObjJsonSetWithoutApply(zcfg_offset_t, objIndex_t *, struct json_object *, char *);
zcfgRet_t zcfgFeMultiObjJsonSet(struct json_object *, char *);
zcfgRet_t zcfgFeObjJsonAdd(zcfg_offset_t, objIndex_t *, char *);
zcfgRet_t zcfgFeObjJsonDel(zcfg_offset_t, objIndex_t *, char *);
char* zcfgFeParamValGet(struct json_object *, char *);
json_object* zcfgFeJsonMultiObjAppend(zcfg_offset_t, objIndex_t *, json_object *, json_object *);

#define zcfgFeJsonObjNew() json_object_new_object()
#define zcfgFeJsonObjFree(jobj) json_object_put(jobj); jobj = NULL
#define zcfgFeParamValForEach(obj, key) char *key; \
		for(struct lh_entry *entry = json_object_get_object(obj)->head; ({ if(entry) { key = (char*)entry->k;} ; entry; }); entry = entry->next )
#define zcfgNotifyListForEachObj(obj, key, paramList) char *key; char *paramList; \
	for(struct lh_entry *entry = json_object_get_object(obj)->head; ({ if(entry) { key = (char*)entry->k; paramList = (char *)json_object_get_string((struct json_object*)entry->v); } ; entry; }); entry = entry->next )
#define zcfgNotifyStrToJsonObj(listStr) json_tokener_parse(listStr)
