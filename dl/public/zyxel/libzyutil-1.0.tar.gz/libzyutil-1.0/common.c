#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/types.h>
#include <signal.h>
#include <fcntl.h>

#include <ctype.h>
#include <unistd.h>

#include "zcfg_common.h"
#include "zcfg_debug.h"

#define MID_SIZE_MAX  32

#include "zyutil.h"

#ifdef BRCM_PLATFORM

#include "board.h"
#include "bcm_hwdefs.h"
#include "bcmTag.h"

#define BOARD_DEVICE_NAME  "/dev/brcmboard"

#endif

/*
 *  Function Name: zyUtilIfaceHwAddrGet
 *  Description: Used to get the MAC Addfree of interface
 *  Parameters: 
 *              
 */
void zyUtilIfaceHwAddrGet(char *ifname, char *hwaddr)
{
	char buf[MID_SIZE_MAX+60];
	char sysCmd[1024];
	int i = 0, j = 0;
	char *p = NULL;
	FILE *fp = NULL;

	strcpy(hwaddr, "");

	sprintf(sysCmd, "ifconfig %s > /var/hwaddr ", ifname);
	system(sysCmd);

	fp = fopen("/var/hwaddr", "r");
	if(fp != NULL) {
		if (fgets(buf, sizeof(buf), fp)) {
			for(i = 2; i < (int)(sizeof(buf) - 5); i++) {
				if (buf[i]==':' && buf[i+3]==':') {
					p = buf+(i-2);
					for(j = 0; j < MID_SIZE_MAX-1; j++, p++) {
						if (isalnum(*p) || *p ==':') {
							hwaddr[j] = *p;
						}
						else {
							break;
						}
					}
					hwaddr[j] = '\0';
					break;
				}
			}
		}
		fclose(fp);
	}
}

bool zyUtilIsAppRunning(char *appName)
{
	char sysCmd[64];
	int size = 0;
	FILE *fp = NULL;
	bool isRunning = false;

	if(strlen(appName) == 0)
		return false;

	sprintf(sysCmd, "ps | grep %s | grep -v grep > /tmp/app", appName);
	system(sysCmd);

	fp = fopen("/tmp/app", "r");
	if(fp != NULL) {
		fseek(fp, 0L, SEEK_END);
		size = ftell(fp);

		if(size > 0)
			isRunning = true;

		fclose(fp);
	}

	return isRunning;
}

bool zyUtilCheckIfaceUp(char *devname)
{
	int skfd;
	int ret = false;
	struct ifreq intf;

	if (devname == NULL || (skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		return ret;
	}

	strcpy(intf.ifr_name, devname);

	/*   if interface is br0:0 and
	 *   there is no binding IP address then return down
	 */

	if (strchr(devname, ':') != NULL) {
		if (ioctl(skfd, SIOCGIFADDR, &intf) < 0) {
			close(skfd);
			return ret;
		}
	}

	// if interface flag is down then return down
	if (ioctl(skfd, SIOCGIFFLAGS, &intf) != -1) {
		if ((intf.ifr_flags & IFF_UP) != 0)
			ret = true;
	}

	close(skfd);

	return ret;
}

void zyUtilAddIntfToBridge(char *ifName, char *bridgeName)
{
	char sysCmd[64];

	sprintf(sysCmd, "brctl delif %s %s 2>/dev/null", bridgeName, ifName);
	system(sysCmd);
	sprintf(sysCmd, "ifconfig %s up", ifName);
	system(sysCmd);
	sprintf(sysCmd, "ifconfig %s 0.0.0.0", ifName);
	system(sysCmd);
	sprintf(sysCmd, "brctl addif %s %s", bridgeName, ifName);
	system(sysCmd);
	sprintf(sysCmd, "sendarp -s %s -d %s", bridgeName, bridgeName);
	system(sysCmd);
	sprintf(sysCmd, "sendarp -s %s -d %s", bridgeName, ifName);
	system(sysCmd);
}

void zyUtilDelIntfFromBridge(char *ifName, char *bridgeName)
{
	char sysCmd[64];

	sprintf(sysCmd, "brctl delif %s %s", bridgeName, ifName);
	system(sysCmd);
	sprintf(sysCmd, "sendarp -s %s -d %s", bridgeName, bridgeName);
	system(sysCmd);
	sprintf(sysCmd, "sendarp -s %s -d %s", bridgeName, ifName);
	system(sysCmd);
}

zcfgRet_t zyUtilGetDomainNameFromUrl(char *url, char *domainName, int domainNameLength)
{
	char *domainNameStartPtr = NULL;
	char *domainNameEndPtr = NULL;
	char tmpdomainName[128] = {0};

	if(!strcmp(url, "\0")){
		zcfgLog(ZCFG_LOG_INFO, "url string is empty \n");
		return ZCFG_SUCCESS;
	}

	domainNameStartPtr = strstr(url, "://");
	if (NULL == domainNameStartPtr) {
		domainNameStartPtr = url;
	} 
	else {
		domainNameStartPtr += strlen("://");
	}

	domainNameEndPtr = strstr(domainNameStartPtr, ":");
	if (NULL == domainNameEndPtr) {
		domainNameEndPtr = strstr(domainNameStartPtr, "/");
		if (NULL == domainNameEndPtr) {
			domainNameEndPtr = url + strlen(url);
		}
	}

	strncpy(tmpdomainName, domainNameStartPtr, (domainNameEndPtr-domainNameStartPtr));

	domainNameStartPtr = strstr(tmpdomainName, "*.");
	if (NULL == domainNameStartPtr) {
		domainNameStartPtr = tmpdomainName;
	} 
	else {
		domainNameStartPtr += strlen("*.");		
	}
	
	domainNameEndPtr = tmpdomainName + strlen(tmpdomainName);

	strncpy(domainName, domainNameStartPtr, (domainNameEndPtr-domainNameStartPtr));
	
	return ZCFG_SUCCESS;
}

#if 0
zcfgRet_t zyUtilAppStopByPidfile(char *pidFile)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	char sysCmd[32] = {0};
	FILE *fptr = NULL;
	int pid = 0;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	if((fptr = fopen(pidFile, "r")) != NULL) {
		fscanf(fptr, "%d", &pid);
		printf("%s : Stop process with PID %d\n", __FUNCTION__, pid);
		snprintf(sysCmd, sizeof(sysCmd), "kill -9 %d", pid);
		zcfgLog(ZCFG_LOG_DEBUG, "Command %s\n", sysCmd);
		if(system(sysCmd) != 0)
			ret = ZCFG_INTERNAL_ERROR; 
		fclose(fptr);
	}

	return ret;
}
#endif

zcfgRet_t zyUtilAppStopByPidfile(char *pidFile)
{
	zcfgRet_t ret = ZCFG_SUCCESS;
	FILE *fptr = NULL;
	int pid = 0;

	zcfgLog(ZCFG_LOG_DEBUG, "%s : Enter\n", __FUNCTION__);

	if((fptr = fopen(pidFile, "r")) != NULL) {
		fscanf(fptr, "%d", &pid);
		printf("%s : Stop process with PID %d\n", __FUNCTION__, pid);
		kill(pid, SIGKILL);
		fclose(fptr);
	}

	return ret;
}

zcfgRet_t zyUtilMacStrToNum(const char *macStr, uint8_t *macNum)
{
	char *pToken = NULL;
	char *pLast = NULL;
	char *buf;
	int i;

	if(macNum == NULL || macStr == NULL) {
		return ZCFG_INVALID_ARGUMENTS;
	}

	if((buf = (char *)malloc(MAC_STR_LEN+1)) == NULL) {
		zcfgLog(ZCFG_LOG_ERR, "%s : malloc of %d bytes failed\n", __FUNCTION__, MAC_STR_LEN+1);
		return ZCFG_INTERNAL_ERROR;
	}

	/* need to copy since strtok_r updates string */
	strcpy(buf, macStr);

	/* Mac address has the following format
	 * xx:xx:xx:xx:xx:xx where x is hex number
	 */
	pToken = strtok_r(buf, ":", &pLast);
	macNum[0] = (uint8_t)strtol(pToken, (char **)NULL, 16);
	for (i = 1; i < MAC_ADDR_LEN; i++) {
		pToken = strtok_r(NULL, ":", &pLast);
		macNum[i] = (uint8_t)strtol(pToken, (char **)NULL, 16);
	}

	free(buf);

	return ZCFG_SUCCESS;
}

zcfgRet_t zyUtilMacNumToStr(const uint8_t *macNum, char *macStr)
{
	if(macNum == NULL || macStr == NULL) {
		return ZCFG_INVALID_ARGUMENTS;
	}

	sprintf(macStr, "%2.2x:%2.2x:%2.2x:%2.2x:%2.2x:%2.2x",
			(uint8_t) macNum[0], (uint8_t) macNum[1], (uint8_t) macNum[2],
			(uint8_t) macNum[3], (uint8_t) macNum[4], (uint8_t) macNum[5]);

   return ZCFG_SUCCESS;
}

#ifdef BRCM_PLATFORM
#ifdef SUPPORT_LANVLAN
zcfgRet_t zyUtilISetIfState(char *ifName, bool up)
{
	int sockfd = 0;
	struct ifreq ifr;
	zcfgRet_t ret = ZCFG_SUCCESS;

	if(ifName == NULL) {
        zcfgLog(ZCFG_LOG_ERR, "%s : Cannot bring up NULL interface\n", __FUNCTION__);
		ret = ZCFG_INTERNAL_ERROR;
	}
	else {
		/* Create a channel to the NET kernel. */
		if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
            zcfgLog(ZCFG_LOG_ERR, "%s : Cannot create socket to the NET kernel\n", __FUNCTION__);
			ret = ZCFG_INTERNAL_ERROR;
		}
		else {
			strncpy(ifr.ifr_name, ifName, IFNAMSIZ);
            // get interface flags
			if(ioctl(sockfd, SIOCGIFFLAGS, &ifr) != -1) {
				if(up)
					ifr.ifr_flags |= IFF_UP;
				else
					ifr.ifr_flags &= (~IFF_UP);

				if(ioctl(sockfd, SIOCSIFFLAGS, &ifr) < 0) {
					zcfgLog(ZCFG_LOG_ERR, "%s : Cannot ioctl SIOCSIFFLAGS on the socket\n", __FUNCTION__);
					ret = ZCFG_INTERNAL_ERROR;
				}
			}
			else {
				zcfgLog(ZCFG_LOG_ERR, "%s : Cannot ioctl SIOCGIFFLAGS on the socket\n", __FUNCTION__);
				ret = ZCFG_INTERNAL_ERROR;
			}

			close(sockfd);
		}
	}

	return ret;
}
#endif

static uint32_t getCrc32(unsigned char *pdata, uint32_t size, uint32_t crc)
{
	while (size-- > 0)
		crc = (crc >> 8) ^ Crc32_table[(crc ^ *pdata++) & 0xff];

	return crc;
}

int nvramDataWrite(NVRAM_DATA *nvramData)
{
	int boardFd = 0;
	int rc = 0;
	unsigned int offset = 0;
	BOARD_IOCTL_PARMS ioctlParms;
	uint32_t crc = CRC32_INIT_VALUE;

	nvramData->ulCheckSum = 0;
	crc = getCrc32((unsigned char *)nvramData, sizeof(NVRAM_DATA), crc);
	nvramData->ulCheckSum = crc;

	boardFd = open(BOARD_DEVICE_NAME, O_RDWR);

	if(boardFd != -1) {
		ioctlParms.string = nvramData;
		ioctlParms.strLen = sizeof(NVRAM_DATA);
		ioctlParms.offset = offset;
		ioctlParms.action = NVRAM;
		ioctlParms.buf    = NULL;
		ioctlParms.result = -1;

		rc = ioctl(boardFd, BOARD_IOCTL_FLASH_WRITE, &ioctlParms);
		close(boardFd);

		if(rc < 0) {
			printf("%s Set NVRAM Failure\n", __FUNCTION__);
			return -1;
		}
	}
	else {
		return -1;
	}

	return 0;
}

int nvramDataGet(NVRAM_DATA *nvramData)
{
	int boardFd = 0;
	int rc = 0;
	unsigned int offset = 0;
	BOARD_IOCTL_PARMS ioctlParms;

	boardFd = open(BOARD_DEVICE_NAME, O_RDWR);

	if(boardFd != -1) {
		ioctlParms.string = nvramData;
		ioctlParms.strLen = sizeof(NVRAM_DATA);
		ioctlParms.offset = offset;
		ioctlParms.action = NVRAM;
		ioctlParms.buf    = NULL;
		ioctlParms.result = -1;

		rc = ioctl(boardFd, BOARD_IOCTL_FLASH_READ, &ioctlParms);
		close(boardFd);

		if(rc < 0) {
			printf("%s Get NVRAM Failure\n", __FUNCTION__);
			return -1;
		}
	}
	else {
		return -1;
	}

	return 0;
}

zcfgRet_t zyUtilIGetSerailNum(char *sn)
{
	NVRAM_DATA nvramData;

	memset(&nvramData, 0, sizeof(NVRAM_DATA));

	if(nvramDataGet(&nvramData) < 0)
		return ZCFG_INTERNAL_ERROR;

	strcpy(sn, nvramData.SerialNumber);
	return ZCFG_SUCCESS;
}

zcfgRet_t zyUtilIGetBaseMAC(char *mac)
{
	NVRAM_DATA nvramData;

	memset(&nvramData, 0, sizeof(NVRAM_DATA));

	if(nvramDataGet(&nvramData) < 0)
		return ZCFG_INTERNAL_ERROR;

        sprintf(mac ,"%02X%02X%02X%02X%02X%02X", 
			nvramData.ucaBaseMacAddr[0],
			nvramData.ucaBaseMacAddr[1],
        	nvramData.ucaBaseMacAddr[2],
        	nvramData.ucaBaseMacAddr[3],
        	nvramData.ucaBaseMacAddr[4],
        	nvramData.ucaBaseMacAddr[5]
	);
	return ZCFG_SUCCESS;
}

zcfgRet_t zyUtilIGetProductName(char *pdname)
{
	NVRAM_DATA nvramData;

	memset(&nvramData, 0, sizeof(NVRAM_DATA));

	if(nvramDataGet(&nvramData) < 0)
		return ZCFG_INTERNAL_ERROR;

	strcpy(pdname, nvramData.ProductName);
	return ZCFG_SUCCESS;
}

zcfgRet_t zyUtilIGetFirmwareVersion(char *fwversion)
{
	NVRAM_DATA nvramData;

	memset(&nvramData, 0, sizeof(NVRAM_DATA));

	if(nvramDataGet(&nvramData) < 0)
		return ZCFG_INTERNAL_ERROR;

	strcpy(fwversion, nvramData.FirmwareVersion);
	return ZCFG_SUCCESS;
}

zcfgRet_t zyUtilIGetSerialNumber(char *serianumber)
{
	NVRAM_DATA nvramData;

	memset(&nvramData, 0, sizeof(NVRAM_DATA));

	if(nvramDataGet(&nvramData) < 0)
		return ZCFG_INTERNAL_ERROR;

	strcpy(serianumber, nvramData.SerialNumber);
	return ZCFG_SUCCESS;
}
#endif
