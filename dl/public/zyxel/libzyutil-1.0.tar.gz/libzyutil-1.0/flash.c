#define _XOPEN_SOURCE 500

#include "zcfg_common.h"
#include "zyutil.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <mtd/mtd-user.h>
#include <errno.h>
#include "zcfg_system.h"
#if 0 //#ifdef ZYXEL_WWAN
#define ZY_WWANPACKAGE_MAXSIZE	131072  // (1024*128) bytes
#define WWANPACKAGE_HEADER_LEN	32  // theoretically speaking 31 is match
#define FW_WWANPACKAGE_FILE	"/etc/fw_wwanpackage"
#define RUN_WWANPACKAGE_FILE	"/var/wwan/run_wwanpackage"
#endif

/* size of read/write buffer */
#define BUFSIZE (64 * 1024)

static struct nand_oobinfo none_oobinfo = {
	.useecc = MTD_NANDECC_OFF,
};

static int zyUtilOpen(const char *pathname, int flags)
{
	int fd;

	fd = open(pathname, flags);
	if(fd < 0) {
        printf("Try to open %s\n", pathname);
		if(flags & O_RDWR)
			printf("Read/Write access\n");
        else if(flags & O_RDONLY)
			printf("Read access\n");
        else if(flags & O_WRONLY)
			printf("Write access\n");

        printf("%s : %m\n", __FUNCTION__);
		return -1;
	}

	return fd;
}

static int zyUtilRead(int fd, const char *filename, void *buf, size_t count)
{
	ssize_t result;

	result = read(fd, buf, count);
	if (count != result) {
		if (result < 0) {
			printf("While reading data from %s: %m\n", filename);
			return -1;
		}

		printf("Short read count returned while reading from %s\n", filename);
		return -1;
	}

	return 0;
}

zcfgRet_t zyUtilMtdDevGetByName(char *mtdname, char *mtddev)
{
	zcfgRet_t ret = ZCFG_NOT_FOUND;
	FILE *fptr = NULL;
	char mtd[8], size[12], erasesize[12], name[16], tmpname[16];
	int len = 0;
#if 1 //#ifdef ZYXEL_WWAN
	FILE *fp = NULL;

	if(!strcmp(mtdname, WWAN_PARTITION_NAME)){
		fp = popen("cat /proc/mtd > /tmp/mtd", "r");
		if(fp != NULL)
			pclose(fp);
	}
	else 
#endif
	system("cat /proc/mtd > /tmp/mtd");

    if((fptr = fopen("/tmp/mtd", "r")) == NULL) {
        printf("Can't open file\n");
    }
	else {
		sprintf(tmpname, "\"%s\"", mtdname);

		fscanf(fptr, "%s%s%s%s", mtd, size, erasesize, name);
		while(!feof(fptr)) {
			if(strstr(mtd, "dev") != NULL) { //skip first line
				fscanf(fptr, "%s%s%s%s", mtd, size, erasesize, name);
				continue;
			}

			if(!strcmp(name, tmpname)) {
				// Delete ':'
				len = strlen(mtd);
				mtd[len-1] = '\0';
				sprintf(mtddev, "/dev/%s", mtd);
				ret = ZCFG_SUCCESS;
				printf("Find MTD Device %s with name %s\n", mtddev, mtdname);
				break;
			}

			fscanf(fptr, "%s%s%s%s", mtd, size, erasesize, name);
        }

        fclose(fptr);
	}

	remove("/tmp/mtd");
	return ret;
}

zcfgRet_t zyUtilWriteBufToFlash(char *devName, void *buf, uint32_t buf_size)
{
	int devFd = -1, i = 0;
	ssize_t result;
	size_t size, written;
	struct mtd_info_user mtd;
	struct erase_info_user erase;
	unsigned char dest[BUFSIZE];

	/* Open MTD device */
	if((devFd = zyUtilOpen(devName, O_SYNC | O_RDWR)) == -1) {
		return ZCFG_INTERNAL_ERROR;
	}

	/* get some info about the flash device */
	if(ioctl(devFd, MEMGETINFO, &mtd) < 0) {
        printf("This doesn't seem to be a valid MTD flash device!\n");
		close(devFd);
		return ZCFG_INTERNAL_ERROR;
	}

	/* Check if it fit into the device/partition? */
	if(buf_size > mtd.size) {
        printf("won't fit into %s!\n", devName);
		close(devFd);
		return ZCFG_INTERNAL_ERROR;
	}

	/* Erase enough blocks */
	erase.start = 0;
	erase.length = buf_size & ~(mtd.erasesize - 1);
	if(buf_size % mtd.erasesize)
		erase.length += mtd.erasesize;

	/* erase the whole chunk in one shot */
	if(ioctl(devFd, MEMERASE, &erase) < 0) {
		printf("While erasing blocks from 0x%.8x-0x%.8x on %s: %m\n", (unsigned int) erase.start,(unsigned int) (erase.start + erase.length), devName);
		close(devFd);
		return ZCFG_INTERNAL_ERROR;
	}

	printf("Erased %u / %uk bytes\n", erase.length, buf_size);

	/* Write the entire file to flash */
	size = buf_size;
	i = BUFSIZE;
	written = 0;
	while(size) {
        if(size < BUFSIZE)
			i = size;

		/* write to device */
		result = write(devFd, (buf+written), i);
		if(i != result) {
			if (result < 0) {
				printf("While writing data to 0x%.8x-0x%.8x on %s: %m\n", written, written+i, devName);
				close(devFd);
				return ZCFG_INTERNAL_ERROR;
			}

			printf("Short write count returned while writing to x%.8x-0x%.8x on %s: %d/%u bytes written to flash\n",
                      written, written+i, devName, written+result, buf_size);

			close(devFd);
			return ZCFG_INTERNAL_ERROR;
		}

		written += i;
		size -= i;
	}

	/* Verify */
	if(lseek(devFd, 0L, SEEK_SET) < 0) {
		printf("While seeking to start of %s: %m\n", devName);
	}

	size = buf_size;
	i = BUFSIZE;
	written = 0;
	while(size) {
		if(size < BUFSIZE)
			i = size;

		/* read from device */
		zyUtilRead(devFd, devName, dest, i);

		/* compare buffers */
		if(memcmp((buf+written), dest, i)) {
			printf("File does not seem to match flash data. First mismatch at 0x%.8x-0x%.8x\n", written, written + i);
			close(devFd);
			return ZCFG_INTERNAL_ERROR;
		}

		written += i;
		size -= i;
	}

	close(devFd);
    return ZCFG_SUCCESS;
}

#ifndef NEW_MTD_DRIVER 
int zyUtilReadBufFromFlash(char *devName, void *buf, uint32_t buf_size)
{
	int oobinfochanged = 0;
	unsigned long start_addr = 0;
	unsigned long ofs, end_addr = 0;
	unsigned long long blockstart = 1;
	int devFd = -1;
	struct mtd_info_user mtd;
	struct nand_oobinfo old_oobinfo;
	int ret, pagesize, badblock = 0;
	unsigned char readbuf[4096];

	/* Open MTD device */
	if((devFd = zyUtilOpen(devName, O_RDONLY)) == -1) {
		return -1;
	}

	/* Fill in MTD device capability structure */
	if(ioctl(devFd, MEMGETINFO, &mtd) != 0) {
		printf("This doesn't seem to be a valid MTD flash device!\n");
		close(devFd);
		return -1;
	}

	printf("mtd.oobsize %d mtd.writesize %d\n", mtd.oobsize, mtd.writesize);

	/* Make sure device page sizes are valid */
	if (!(mtd.oobsize == 128 && mtd.writesize == 4096) &&
		!(mtd.oobsize == 64 && mtd.writesize == 2048) &&
		!(mtd.oobsize == 32 && mtd.writesize == 1024) &&
		!(mtd.oobsize == 16 && mtd.writesize == 512) &&
		!(mtd.oobsize == 8 && mtd.writesize == 256)) {
		printf("Unknown flash (not normal NAND)\n");
		close(devFd);
		return -1;
	}

#if 0
	/* Read the real oob length */
	oob.length = mtd.oobsize;
#endif
	/* No ecc*/
	ret = ioctl(devFd, MTDFILEMODE, (void *) MTD_MODE_RAW);
	if(ret == 0) {
		oobinfochanged = 2;
	}
	else {
		switch(errno) {
			case ENOTTY:
				if(ioctl(devFd, MEMGETOOBSEL, &old_oobinfo) != 0) {
					perror("MEMGETOOBSEL");
					close(devFd);
					return -1;
				}

				if(ioctl(devFd, MEMSETOOBSEL, &none_oobinfo) != 0) {
					perror("MEMSETOOBSEL");
					close(devFd);
					return -1;
				}

				oobinfochanged = 1;
				break;
			default:
				perror("MTDFILEMODE");
				close(devFd);
				return -1;
		}
	}

	/* Initialize start/end addresses and block size */
	end_addr = start_addr + buf_size;

	pagesize = mtd.writesize;

	/* Dump the flash contents */
	for (ofs = start_addr; ofs < end_addr ; ofs+=pagesize) {
		// new eraseblock , check for bad block
		if (blockstart != (ofs & (~mtd.erasesize + 1))) {
			blockstart = ofs & (~mtd.erasesize + 1);
			if ((badblock = ioctl(devFd, MEMGETBADBLOCK, &blockstart)) < 0) {
				perror("ioctl(MEMGETBADBLOCK)");
				goto closeall;
			}
		}

		if (badblock) {
				continue;
		}
		else {
			/* Read page data and exit on failure */
			if (pread(devFd, readbuf, pagesize, ofs) != pagesize) {
				perror("pread");
				goto closeall;
			}
		}

		if(buf_size < pagesize) {
			memcpy(buf, readbuf, buf_size);
		}
		else {
			memcpy(buf, readbuf, pagesize);
			buf += pagesize;
			buf_size -= pagesize;
		}
	}

	/* reset oobinfo */
	if(oobinfochanged == 1) {
		if(ioctl(devFd, MEMSETOOBSEL, &old_oobinfo) != 0) {
			perror ("MEMSETOOBSEL");
			close(devFd);
			return -1;
		}
	}

	/* Close the output file and MTD device */
	close(devFd);

	return 0;

closeall:
	/* The new mode change is per file descriptor ! */
	if(oobinfochanged == 1) {
		if(ioctl(devFd, MEMSETOOBSEL, &old_oobinfo) != 0)  {
			perror("MEMSETOOBSEL");
		}
	}

	close(devFd);
	return -1;
}
#else
int zyUtilReadBufFromFlash(char *devName, void *buf, uint32_t buf_size)
{
	int oobinfochanged = 0;
	unsigned long start_addr = 0;
	unsigned long ofs, end_addr = 0;
	unsigned long long blockstart = 1;
	int devFd = -1;
	struct mtd_info_user mtd;
	struct nand_oobinfo old_oobinfo;
	int ret, pagesize, badblock = 0;
	unsigned char readbuf[4096];

	/* Open MTD device */
	if((devFd = zyUtilOpen(devName, O_RDONLY)) == -1) {
		return -1;
	}

	/* Fill in MTD device capability structure */
	if(ioctl(devFd, MEMGETINFO, &mtd) != 0) {
		printf("This doesn't seem to be a valid MTD flash device!\n");
		close(devFd);
		return -1;
	}

	printf("mtd.oobsize %d mtd.writesize %d\n", mtd.oobsize, mtd.writesize);

	/* Make sure device page sizes are valid */
	if (!(mtd.oobsize == 128 && mtd.writesize == 4096) &&
		!(mtd.oobsize == 64 && mtd.writesize == 2048) &&
		!(mtd.oobsize == 32 && mtd.writesize == 1024) &&
		!(mtd.oobsize == 16 && mtd.writesize == 512) &&
		!(mtd.oobsize == 8 && mtd.writesize == 256)) {
		printf("Unknown flash (not normal NAND)\n");
		close(devFd);
		return -1;
	}

#if 0
	/* Read the real oob length */
	oob.length = mtd.oobsize;
#endif
	/* No ecc*/
	if(ioctl(devFd, MTDFILEMODE, (void *) MTD_FILE_MODE_RAW) != 0) {
		perror("MTDFILEMODE");
		goto closeall;
	}

	/* Initialize start/end addresses and block size */
	end_addr = start_addr + buf_size;

	pagesize = mtd.writesize;

	/* Dump the flash contents */
	for (ofs = start_addr; ofs < end_addr ; ofs+=pagesize) {
		// new eraseblock , check for bad block
		if (blockstart != (ofs & (~mtd.erasesize + 1))) {
			blockstart = ofs & (~mtd.erasesize + 1);
			if ((badblock = ioctl(devFd, MEMGETBADBLOCK, &blockstart)) < 0) {
				perror("ioctl(MEMGETBADBLOCK)");
				goto closeall;
			}
		}

		if (badblock) {
				continue;
		}
		else {
			/* Read page data and exit on failure */
			if (pread(devFd, readbuf, pagesize, ofs) != pagesize) {
				perror("pread");
				goto closeall;
			}
		}

		if(buf_size < pagesize) {
			memcpy(buf, readbuf, buf_size);
		}
		else {
			memcpy(buf, readbuf, pagesize);
			buf += pagesize;
			buf_size -= pagesize;
		}
	}
#ifndef NEW_MTD_DRIVER
	/* reset oobinfo */
	if(oobinfochanged == 1) {
		if(ioctl(devFd, MEMSETOOBSEL, &old_oobinfo) != 0) {
			perror ("MEMSETOOBSEL");
			close(devFd);
			return -1;
		}
	}
#endif
	/* Close the output file and MTD device */
	close(devFd);

	return 0;

closeall:
#ifndef NEW_MTD_DRIVER
	/* The new mode change is per file descriptor ! */
	if(oobinfochanged == 1) {
		if(ioctl(devFd, MEMSETOOBSEL, &old_oobinfo) != 0)  {
			perror("MEMSETOOBSEL");
		}
	}
#endif
	close(devFd);
	return -1;
}
#endif

#if 1 //#ifdef ZYXEL_WWAN
int zyUtilMtdErase(const char *mtd)
{
	int fd;
	struct mtd_info_user mtdInfo;
	struct erase_info_user mtdEraseInfo;
	
	/* Open MTD device */
	if((fd = zyUtilOpen(mtd, O_SYNC | O_RDWR)) == -1) {
		fprintf(stderr, "Could not open mtd device: %s\n", mtd);
		return ZCFG_INTERNAL_ERROR;
	}
	
	/* Fill in MTD device capability structure */
	if(ioctl(fd, MEMGETINFO, &mtdInfo)) {
		fprintf(stderr, "Could not get MTD device info from %s\n", mtd);
		close(fd);
		exit(1);
	}

	mtdEraseInfo.length = mtdInfo.erasesize;

	/* Erase flash */
	for (mtdEraseInfo.start = 0;
		 mtdEraseInfo.start < mtdInfo.size;
		 mtdEraseInfo.start += mtdInfo.erasesize) {

		ioctl(fd, MEMUNLOCK, &mtdEraseInfo);
		if(ioctl(fd, MEMERASE, &mtdEraseInfo)) {
			fprintf(stderr, "Could not erase MTD device: %s\n", mtd);
			close(fd);
			exit(1);
		}
	}

	close(fd);
	return 0;

}


/*______________________________________________________________________________
**	zy_updateWWANPackage
**
**	descriptions:
**		update run time WWAN Package.
**
**
**	parameters:
**
**
**	return:
**		1: Fail
**		0: OK
**____________________________________________________________________________
*/
int
zyUtilUpdateWWANPackage(void)
{
	int fd, i, length;
	char *packageBuf = NULL, *bufPoint = NULL, *flashwwan;
	char fwPkgRevision[16], flashPkgRevision[16], cmd_buf[128], mtddev[16];
	zcfgRet_t ret; 
	FILE *fp = NULL;
	//SINT32 filesize = 0;

	/* get FW WWAN Package REVISION */
	fwPkgRevision[0] = '\0';
	fd = open(FW_WWANPACKAGE_FILE, O_RDONLY);
	if(fd < 0){
		printf("Error: %s, open FW_WWANPACKAGE_FILE fail!\n", __func__);
	}
	else{
		packageBuf = calloc(WWANPACKAGE_HEADER_LEN, sizeof(char));	
		if (packageBuf == NULL)
		{
			printf("packageBuf allocation failed.\n");
			return 1;
		}
		if (read(fd, packageBuf, WWANPACKAGE_HEADER_LEN) != WWANPACKAGE_HEADER_LEN)
	    {
	        printf("Error: %s read function fail.\n", __func__);
		 	free(packageBuf);
	        return 1;
	    }

		if(!(bufPoint = strstr(packageBuf, "REVISION:"))){
			printf("Error: %s, FW isn't a WWAN Package!\n", __func__);
		}
		else{
			bufPoint = strstr(bufPoint, ":");
			bufPoint++;
			while(*(bufPoint) == ' '){
				bufPoint++;
			}
			for(i = 0; (bufPoint[i] == '.') || ((bufPoint[i] >= '0') && (bufPoint[i] <= '9')); i++){
				fwPkgRevision[i] = bufPoint[i];
			}
			fwPkgRevision[i] = '\0';
		}
		bufPoint = NULL;
		free(packageBuf);
		close(fd);
	}


	/* get Flash WWAN Package REVISION */
    flashPkgRevision[0] = '\0';
	flashwwan = calloc(ZY_WWANPACKAGE_MAXSIZE, sizeof(char));
	if(flashwwan == NULL){
		printf("Error: %s, flashwwan allocation failed!\n", __func__);
		//free(flashwwan);
		return 1;
	}
	
	if((ret = zyUtilMtdDevGetByName(WWAN_PARTITION_NAME, mtddev)) != ZCFG_SUCCESS)
	{
		printf("Error: %s, Can't get WWAN MTD!\n", __func__);
	}
	else{
		packageBuf = calloc(WWANPACKAGE_HEADER_LEN, sizeof(char));
		if(packageBuf == NULL){
			printf("packageBuf allocation failed.\n");
			return 1;
		}
		zyUtilReadBufFromFlash(mtddev, (void *)flashwwan, ZY_WWANPACKAGE_MAXSIZE);
	    if (flashwwan[0] == '\0')
	    {
			printf("Notice: %s, WWAN MTD is empty!\n", __func__);
	    }
		if(strncpy(packageBuf, flashwwan, WWANPACKAGE_HEADER_LEN) == NULL ){
			printf("%s: Could not get Revision\n", __func__);
			if(flashwwan != NULL)
				free(flashwwan);
			return 1;
		}
		else {
			if(!(bufPoint = strstr(packageBuf, "REVISION:"))){
				printf("Notice: %s, No WWAN Package in Flash!\n", __func__);
			}
			else{
				bufPoint = strstr(bufPoint, ":");
				bufPoint++;
				while(*(bufPoint) == ' '){
					bufPoint++;
				}
				for(i = 0; (bufPoint[i] == '.') || ((bufPoint[i] >= '0') && (bufPoint[i] <= '9')); i++){
					flashPkgRevision[i] = bufPoint[i];
				}
				flashPkgRevision[i] = '\0';
			}
			bufPoint = NULL;
			free(packageBuf);
			}
	}
	
	/* use newer Revision */
	if((fwPkgRevision[0] == '\0') && (flashPkgRevision[0] == '\0')){
		printf("%s: Could not get Revision\n", __func__);
		return 1;
	}
	else{
		/*sprintf(cmd_buf, "rm -rf %s", RUN_WWANPACKAGE_FILE);
		system(cmd_buf);*/
		unlink(RUN_WWANPACKAGE_FILE);
		if (strcmp(flashPkgRevision, fwPkgRevision) > 0){
#if 1
			//printf("%s: USE Flash WWAN Package\n", __func__); //debug
			bufPoint = strstr(flashwwan, "END");
			length = (bufPoint - flashwwan);
		    fd = open(RUN_WWANPACKAGE_FILE, O_WRONLY|O_TRUNC|O_CREAT);
			if(fd < 0){
				printf("Error: %s, open file fail!\n", __func__);
				unlink(RUN_WWANPACKAGE_FILE);
				return 1;
			}
			if(write(fd, flashwwan, length) != length){
				printf("Error: %s write fail!\n", __func__);
				unlink(RUN_WWANPACKAGE_FILE);
				return 1;
			}
			close(fd);
			bufPoint = NULL;
			//free(flashwwan);
#else
			sprintf(cmd_buf, "cp %s %s", TMP_WWANPACKAGE_FILE, RUN_WWANPACKAGE_FILE);
			system(cmd_buf);
#endif
		}
		else{
			//printf("%s: USE FW WWAN Package\n", __func__); //debug
			sprintf(cmd_buf, "cp %s %s", FW_WWANPACKAGE_FILE, RUN_WWANPACKAGE_FILE);
			//system(cmd_buf);
			fp = popen(cmd_buf, "r");
			if(fp == NULL){
				printf("copy fw_wwanpackage fail\n");
			}
			else
				pclose(fp);
		}
		if(flashwwan != NULL)
			free(flashwwan);
	}
	return 0;
}

#endif
