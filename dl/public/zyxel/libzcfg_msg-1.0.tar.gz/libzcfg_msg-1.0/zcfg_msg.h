#ifndef _ZCFG_MSG_H
#define _ZCFG_MSG_H
#include "zcfg_common.h"
#include "zcfg_eid.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define ERROR_APPLY_MSG -1

#define ZCFG_NO_WAIT_REPLY (1 << 31)

/* ZCFG message type with waiting reply*/
#define REQUEST_GET_NEXT_OBJ                0
#define RESPONSE_NO_MORE_INSTANCE           1
#define REQUEST_GET_OBJ                     2
#define RESPONSE_GET_SUCCESS                3
#define RESPONSE_GET_EMPTY                  4
#define RESPONSE_GET_FAIL                   5
#define REQUEST_SET_OBJ                     6
#define REQUEST_SET_MULTI_OBJ               7
#define REQUEST_ADD_INSTANCE                8
#define REQUEST_DEL_INSTANCE                9
#define REQUEST_FIRMWARE_UPGRADE            10
#define REQUEST_RESTORE_DEFAULT             11
#define RESPONSE_SUCCESS                    12
#define RESPONSE_FAIL                       13
#define REQUEST_GET_NEXT_SUB                14
#define REQUEST_GET_PARAM_ATTR              15
#define REQUEST_SET_PARAM_ATTR              16
#define RESPONSE_WRITE_OBJ_SUCCESS          17
#define RESPONSE_WRITE_OBJ_FAIL             18
#define ZCFG_MSG_DELAY_APPLY                19
#define ZCFG_MSG_RE_APPLY                   20
#define REQUEST_SET_WITHOUT_APPLY           21
#define REQUEST_ROMD_UPGRADE                22
#define REQUEST_GET_OBJ_WITHOUT_UPDATE      23
#define REQUEST_CONFIG_BACKUP               24
#define ZCFG_MSG_UPNP_PORTMAP_GET           25
#define ZCFG_MSG_DHCPD_OPTION               26
#define REQUEST_GET_NEXT_OBJ_WITHOUT_UPDATE 27
#define REQUEST_GET_NEXT_SUB_WITHOUT_UPDATE 28
#define ZCFG_MSG_VOICE_STATS_GET            29
#define ZCFG_MSG_VOICE_CONTROL              30
#define ZCFG_MSG_VOICE_DEBUG_AND_TEST       31
#define REQUEST_REINIT_MACLESS_PROVISIONING 32

#define ZCFG_MSG_REQUEST_TR98_MAPPING       99	/*Request for tr181 object name related with tr98*/
#define ZCFG_MSG_REQUEST_TR181_MAPPING      100	/*Request for tr98 object name related with tr181*/

/*Test Use*/
#define ZCFG_MSG_REPLY				101
#define ZCFG_MSG_HELLO				102
#define ZCFG_MSG_NO_REPLY			(101 | ZCFG_NO_WAIT_REPLY)

/* ZCFG message type without waiting reply*/
#define ZCFG_MSG_LAN_IP_CONNECTION_UP           (1  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_DHCPC_BOUND                    (2  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_DHCPC_DECONFIG                 (3  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_DHCPC_RELEASE                  (4  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_PPPD_EVENT                     (5  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_WAN_IP_CONNECTION_UP           (6  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_WAN_LINK_STATUS                (7  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_PARAMETER_CHANGED_NOTIFY       (8  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_WAN_PPP_CONNECTION_UP          (9  | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_WAN_CONNECTION_READY           (10 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_WAN_CONNECTION_LOST            (11 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_LAN_MAC_CONTROL_EVENT          (12 | ZCFG_NO_WAIT_REPLY) /*For MAC Filter*/
#define ZCFG_MSG_VOICE_CONNECTION_CHANGE        (13 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VOICE_CONNECTION_LOST          (14 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VOICE_DYNAMIC_INSTANCE_CHANGED (15 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VOICE_STATIC_CONFIG_CHANGED    (16 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VOICE_CONFIG_SAVED             (17 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_INIT_WAN_LINK_INFO             (18 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_REBOOT_SYSTEM                  (19 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_PING_MSG                       (20 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_TRACERT_MSG                    (21 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_DHCP6C_STATE_CHANGED           (22 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_MGABDEV_DETECT                 (23 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_RA_INFO                        (24 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_MGMT_NAT_DETECT                (25 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_MGMT_NAT_CLEAR                 (26 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_MGMT_UDP_CONNREQ               (27 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_MGMT_DIAGNOSTIC_COMPLETE       (28 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_NSLOOKUP_MSG                   (29 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_ATM_OAM_F5_COMPLETE            (30 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_ATM_OAM_F4_COMPLETE            (31 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VC_AUTOHUNT_START              (32 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VC_AUTOHUNT_STOP               (33 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_HTTP_TIMEOUT_CONFIG            (34 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_NTP_SYNC_SUCCESS               (35 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_STB_VENDOR_ID_FIND             (36 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_AUTO_PROVISION                 (37 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_TR64_DEVICE_UPDATE             (38 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_INIT_DATAMODEL_FIN             (39 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VLAN_AUTOHUNT_START			(40 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VLAN_AUTOHUNT_STOP				(41 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VLAN_HUNT_SUCCESS				(42 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VLAN_HUNT_FAIL					(43 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_VLAN_HUNT_SET_TIMEOUT			(44 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_MGMT_CONNECT_UPDATE            (45 | ZCFG_NO_WAIT_REPLY)
#define ZCFG_MSG_DOWNLOAD_DIAG_COMPLETE_EVENT   (46 | ZCFG_NO_WAIT_REPLY)




/* end ZCFG message type */

#define ZCFG_ADDRESS_PREFIX "/tmp/zcfg_sockaddr"
#define ZCFG_MSG_BACKLOG 5

typedef struct zcfgMsg_s {
	uint32_t type;
	uint32_t oid;
	uint8_t srcEid;
	uint8_t dstEid;
	uint16_t length;
	int32_t clientPid;
	int32_t statCode;
	char reserve[28];
	objIndex_t objIid[1];
}zcfgMsg_t;

void zcfgEidInit(zcfgEid_t eid, char *);
zcfgRet_t zcfgMsgServerInit();
zcfgRet_t zcfgMsgReqRecv(zcfgMsg_t **recvBuf, uint32_t timeout_msec);
zcfgRet_t zcfgMsgRepSend(zcfgMsg_t *sendMsg);
zcfgRet_t zcfgMsgSendAndGetReply(zcfgMsg_t *sendMsg, zcfgMsg_t **replyMsg, uint32_t timeout_msec);
#endif
