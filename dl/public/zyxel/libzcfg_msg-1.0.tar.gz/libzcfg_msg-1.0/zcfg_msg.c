#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>

#include "zcfg_msg.h"
#include "zcfg_debug.h"

#define MSG_DEBUG 0

int myEid = -1;
int myMsgfd = -1;
/*
 *  Function Name: zcfgEidInit
 *  Description: Used by process to register its entity id. 
 *
 */
void zcfgEidInit(zcfgEid_t eid, char *moduleName)
{
	if(moduleName != NULL) {
		/* Open a connection to the syslog server */
		openlog(moduleName, LOG_NOWAIT, LOG_USER);
	}

	zcfgLog(ZCFG_LOG_NOTICE, "Register EID %d\n", eid);

	myEid = eid;
}
/*
 *  Function Name: zcfgMsgServerInit
 *  Description: If a process wants to be a message server, it can use this function
 *               to initialize socket.
 */
zcfgRet_t zcfgMsgServerInit()
{
	int len;
	struct sockaddr_un saun;

	if( myEid == -1 ){
		zcfgLog(ZCFG_LOG_ERR, "Invalid eid. In %s\n", __FUNCTION__);
		return ZCFG_INVALID_EID;
	}

	/* open a message socket for receiving regular message */
#if 0
	if ((myMsgfd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
		zcfgLog(ZCFG_LOG_ERR, "create message socket error. In %s\n", __FUNCTION__);
		perror("server: socket");
		myMsgfd = -1;
		return ZCFG_INTERNAL_ERROR;
	}
#else
	if ((myMsgfd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
		zcfgLog(ZCFG_LOG_ERR, "create message socket error. In %s\n", __FUNCTION__);
		perror("server: socket");
		myMsgfd = -1;
		return ZCFG_INTERNAL_ERROR;
	}
#endif
	saun.sun_family = AF_UNIX;
	sprintf(saun.sun_path, "%s%d", ZCFG_ADDRESS_PREFIX, myEid);
	unlink(saun.sun_path);
	len = sizeof(saun);
	if (bind(myMsgfd, (struct sockaddr*)&saun, len) < 0) {
		zcfgLog(ZCFG_LOG_ERR, "bind message socket error. In %s\n", __FUNCTION__);
		perror("server: bind");
		close(myMsgfd);
		return ZCFG_INTERNAL_ERROR;
	}
#if 0
	if (listen(myMsgfd, ZCFG_MSG_BACKLOG) < 0) {
		zcfgLog(ZCFG_LOG_ERR, "listen message socket error. In %s\n", __FUNCTION__);
		perror("server: listen");
		close(myMsgfd);
		return ZCFG_INTERNAL_ERROR;
	}
#endif
	return ZCFG_SUCCESS;
}
/*
 *  Function Name: zcfgMsgReqRecv
 *  Description: Used by message server to receive a message from other
 *               processes.
 *
 */
zcfgRet_t zcfgMsgReqRecv(zcfgMsg_t **recvBuf, uint32_t timeout_msec)
{
	int result, fromlen, rcvSize, clientPid;
	struct timeval tmpTv, *tv = NULL;
	struct sockaddr_un clientaddr;
	zcfgMsg_t rcvMsg;
	fd_set fdR;

	if( myEid == -1 ){
		zcfgLog(ZCFG_LOG_ERR, "Invalid eid. In %s\n", __FUNCTION__);
		return ZCFG_INVALID_EID;
	}

	if( myMsgfd == -1 ){
		zcfgLog(ZCFG_LOG_ERR, "Invalid socket fd. In %s\n", __FUNCTION__);
		return ZCFG_INTERNAL_ERROR;
	}

	FD_ZERO(&fdR);
	FD_SET(myMsgfd, &fdR);

	if(timeout_msec) {
		tmpTv.tv_sec = timeout_msec/1000;
		tmpTv.tv_usec = timeout_msec*1000;
		tv = &tmpTv;
	}
#if MSG_DEBUG
	zcfgLog(ZCFG_LOG_DEBUG, "%s : Wait connection...\n", __FUNCTION__);
#endif
	result = select(myMsgfd+1, &fdR, NULL, NULL, tv);
	/* check the select result */
	switch(result) {
		case 0:
			zcfgLog(ZCFG_LOG_WARNING, "Timeout\n");
			return ZCFG_TIMEOUT;
		case -1:
			perror("select:");
			return ZCFG_INTERNAL_ERROR;
		default:
			break;
	}

	if(FD_ISSET(myMsgfd, &fdR)) { //Is there a new connection coming?
#if MSG_DEBUG
		zcfgLog(ZCFG_LOG_INFO, "%s : a new connection coming...\n", __FUNCTION__);
#endif
		fromlen = sizeof(clientaddr);
		rcvSize = recvfrom(myMsgfd, (char *)(&rcvMsg), sizeof(zcfgMsg_t), MSG_PEEK, (struct sockaddr*)&clientaddr, &fromlen);
		if(rcvSize != sizeof(zcfgMsg_t)){
			zcfgLog(ZCFG_LOG_ERR, "%s : recvfrom fail. Error is %s\n", __FUNCTION__, strerror(errno));
			//close(myMsgfd);
			return ZCFG_INTERNAL_ERROR;
		}
		else {
			sscanf(clientaddr.sun_path, "%*[^-]-%u", &clientPid);
		}

		/* malloc recv buf size according to length field in msg header */
		if((*recvBuf = (zcfgMsg_t *)malloc(sizeof(zcfgMsg_t)+rcvMsg.length)) == NULL){
			zcfgLog(ZCFG_LOG_ERR, "fail to allocate receive buffer. In %s\n", __FUNCTION__);
			//close(new_fd);
			//close(myMsgfd);
			return ZCFG_INTERNAL_ERROR;
		}

		/* copy header to recv buf */
		memset((void *)(*recvBuf), 0, sizeof(zcfgMsg_t)+rcvMsg.length);
		//memcpy(*recvBuf, &rcvMsg, sizeof(zcfgMsg_t));
		//buf = *recvBuf + 1;
#if 0
		rcvSize = recv(new_fd, (char *)buf, rcvMsg.length, 0);
#else
		fromlen = sizeof(clientaddr);
		rcvSize = recvfrom(myMsgfd, (char *)(*recvBuf), sizeof(zcfgMsg_t)+rcvMsg.length, 0, (struct sockaddr*)&clientaddr, &fromlen);
#endif
		if(rcvSize != (sizeof(zcfgMsg_t)+rcvMsg.length)){
			zcfgLog(ZCFG_LOG_ERR, "%s : recvfrom fail. Error is %s\n", __FUNCTION__, strerror(errno));
			//close(new_fd);
			//close(myMsgfd);
			free(*recvBuf);
			return ZCFG_INTERNAL_ERROR;
		}
#if 0
		if(rcvMsg.type & ZCFG_NO_WAIT_REPLY) {
			zcfgLog(ZCFG_LOG_DEBUG, "No need to send reply message back\n");
			//((zcfgMsg_t *)(*recvBuf))->connFd = -1;
			//close(new_fd);
			//close(myMsgfd);
		}
		else {
#if MSG_DEBUG
			zcfgLog(ZCFG_LOG_DEBUG, "Need to send reply message back\n");
#endif
			//((zcfgMsg_t *)(*recvBuf))->connFd = new_fd;
			//((zcfgMsg_t *)(*recvBuf))->connFd = myMsgfd;
			((zcfgMsg_t *)(*recvBuf))->clientPid = clientPid;
		}
#else
		((zcfgMsg_t *)(*recvBuf))->clientPid = clientPid;
#endif
		return ZCFG_SUCCESS;		
	}
	else {
		zcfgLog(ZCFG_LOG_ERR, "Error file descriptor. In %s\n", __FUNCTION__);
		return ZCFG_INTERNAL_ERROR;
	}
}
/*
 *  Function Name: zcfgMsgRepSend
 *  Description: Used by message server to send a response back to the process.
 *
 */
zcfgRet_t zcfgMsgRepSend(zcfgMsg_t *sendMsg)
{
	int sendSize = 0, len = 0;
	struct sockaddr_un clientaddr;

	if( myEid == -1 ){
		zcfgLog(ZCFG_LOG_ERR, "Invalid eid\n");
		free(sendMsg);
		return ZCFG_INVALID_EID;
	}
#if 0
	sendSize = send(sendMsg->connFd, (char *)sendMsg, sizeof(zcfgMsg_t) + sendMsg->length, MSG_NOSIGNAL);
#else
	clientaddr.sun_family = AF_UNIX;
	sprintf(clientaddr.sun_path, "%s%hhu-%d", ZCFG_ADDRESS_PREFIX, sendMsg->dstEid, sendMsg->clientPid);
	len = sizeof(clientaddr);
	sendSize = sendto(myMsgfd, (char *)sendMsg, sizeof(zcfgMsg_t) + sendMsg->length, 0, (struct sockaddr*)&clientaddr, len);
#endif
	if(sendSize != (sizeof(zcfgMsg_t) + sendMsg->length)){
		zcfgLog(ZCFG_LOG_ERR, "%s : sendto %s fail. Error is %s\n", __FUNCTION__, clientaddr.sun_path, strerror(errno));
		//close(sendMsg->connFd);
		free(sendMsg);
		return ZCFG_INTERNAL_ERROR;
	}
#if MSG_DEBUG
	zcfgLog(ZCFG_LOG_DEBUG, "message transmission success !!\n");
#endif
	//close(sendMsg->connFd);
	free(sendMsg);
	return ZCFG_SUCCESS;
}
/*
 *  Function Name: zcfgMsgSendAndGetReply
 *  Description: Used by client to send a message to the server process and get a response.
 *
 */
zcfgRet_t zcfgMsgSendAndGetReply(zcfgMsg_t *sendMsg, zcfgMsg_t **replyMsg, uint32_t timeout_msec)
{
	int fd, rc;
	zcfgMsg_t rcvMsg, *msgHdr;
	struct sockaddr_un saun;
	struct sockaddr_un serveraddr, clientaddr;
	struct timeval tmpTv, *tv = NULL;
	int len, sendSize, rcvSize;
	fd_set readFds;
	zcfgRet_t ret;
	int flags;

	if( myEid == -1 ){
		zcfgLog(ZCFG_LOG_ERR, "Invalid eid\n");
		return ZCFG_INVALID_EID;
	}

	memset(&rcvMsg, 0, sizeof(zcfgMsg_t));

	if ((fd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
		zcfgLog(ZCFG_LOG_ERR, "%s : create socket fail. Error is %s\n", __FUNCTION__, strerror(errno));
		free(sendMsg);
   	    return ZCFG_INTERNAL_ERROR;
	}

	/*nonblocking operation*/
	flags = fcntl(fd, F_GETFL, 0);
	fcntl(fd, F_SETFL, flags | O_NONBLOCK);

	clientaddr.sun_family = AF_UNIX;
	sprintf(clientaddr.sun_path, "%s%d-%d", ZCFG_ADDRESS_PREFIX, myEid, getpid());

   	len = sizeof(clientaddr);

	if (bind(fd, (struct sockaddr*)&clientaddr, len) < 0) {
		zcfgLog(ZCFG_LOG_ERR, "%s : bind error. Error is %s\n", __FUNCTION__, strerror(errno));
		perror("client: bind");
		close(fd);
		unlink(clientaddr.sun_path);
		return -1;
	}

	saun.sun_family = AF_UNIX;
	sprintf(saun.sun_path, "%s%hhu", ZCFG_ADDRESS_PREFIX, sendMsg->dstEid);
	len = sizeof(saun);

	msgHdr = (zcfgMsg_t*)sendMsg;
	msgHdr->srcEid = myEid; 
	sendSize = sendto(fd, (char *)sendMsg, sizeof(zcfgMsg_t) + sendMsg->length, 0, (struct sockaddr*)&saun, len);
	if(sendSize != (sizeof(zcfgMsg_t) + sendMsg->length)){
		zcfgLog(ZCFG_LOG_ERR, "%s : sendto %s fail. Error is %s\n", __FUNCTION__, saun.sun_path, strerror(errno));
		close(fd);
		free(sendMsg);
		unlink(clientaddr.sun_path);
		return ZCFG_INTERNAL_ERROR;
	}

	/*Check whether it needs to wait reply message*/
	if(sendMsg->type & ZCFG_NO_WAIT_REPLY) {
		free(sendMsg);
		close(fd);
		unlink(clientaddr.sun_path);
		return ZCFG_SUCCESS_AND_NO_REPLY;
	}

	free(sendMsg);

	/* timeout processing  */
	FD_ZERO(&readFds);
	FD_SET(fd, &readFds);

	if(timeout_msec){
		tmpTv.tv_sec = timeout_msec/1000;
		tmpTv.tv_usec = timeout_msec*1000;
		tv = &tmpTv;
	}

	/* starting timer and wait data available */
	rc = select(fd+1, &readFds, NULL, NULL, tv);
	if ((rc == 1) && (FD_ISSET(fd, &readFds))) {
		/* receive message header first */
		rcvSize = recvfrom(fd, (char *)(&rcvMsg), sizeof(zcfgMsg_t), MSG_PEEK, (struct sockaddr*)&serveraddr, &len);
		if(rcvSize != sizeof(zcfgMsg_t)){
			zcfgLog(ZCFG_LOG_ERR, "message header reception error. In %s\n", __FUNCTION__);
			close(fd);
			unlink(clientaddr.sun_path);
			return ZCFG_INTERNAL_ERROR;
		}

		/* malloc recv buf size according to length field in msg header */
		if((*replyMsg = (zcfgMsg_t *)malloc(sizeof(zcfgMsg_t)+rcvMsg.length)) == NULL){
			zcfgLog(ZCFG_LOG_ERR, "fail to allocate receive buffer. In %s\n", __FUNCTION__);
			close(fd);
			unlink(clientaddr.sun_path);
			return ZCFG_INTERNAL_ERROR;
		}

		memset((void *)(*replyMsg), 0, sizeof(zcfgMsg_t)+rcvMsg.length);

		rcvSize = recvfrom(fd, (char *)(*replyMsg), sizeof(zcfgMsg_t)+rcvMsg.length, 0, (struct sockaddr*)&serveraddr, &len);
		if(rcvSize != (sizeof(zcfgMsg_t)+rcvMsg.length)){
			zcfgLog(ZCFG_LOG_ERR, "message payload reception error. In %s\n", __FUNCTION__);
			close(fd);
			unlink(clientaddr.sun_path);
			free(*replyMsg);
			return ZCFG_INTERNAL_ERROR;
		}

		ret = ZCFG_SUCCESS;
	}
	else {
		zcfgLog(ZCFG_LOG_ERR, "%s : %s\n", __FUNCTION__, strerror(errno));
		ret = ZCFG_TIMEOUT;
	}

	close(fd);
	unlink(clientaddr.sun_path);
	return ret;
}
