#ifndef _ZCFG_MSG_VOICE_H
#define _ZCFG_MSG_VOICE_H
#include "zcfg_common.h"

#define ZCFG_MSG_VOICE_REPLY_WAIT_TIMEOUT 2000 //ms

#define VOICE_STATS_REQ_REGISTRATION_STATUS	(1 << 0)
#define VOICE_STATS_REQ_MWI_STATUS			(1 << 1)
#define VOICE_STATS_REQ_CALL_STATE			(1 << 2)
#define VOICE_STATS_REQ_FXS_HOOK_STATUS		(1 << 3)
typedef struct voiceStatsReq_s {
	uint16_t	bitFlag;

	uint16_t	registerStatus; //bitmap: each bit (from the LSB) is corresponding to one SIP account/line. Markup dedicated bit to indicate requesting its corresponding SIP account/line's SIP Registration Status. This is designed to support 16 SIP accounts/lines - SIP-00 ~ SIP-15.
	uint16_t	mwiStatus; //bitmap: each bit (from the LSB) is corresponding to one SIP account/line. Markup dedicated bit to indicate requesting its corresponding SIP account/line's MWI Status. This is designed to support 16 SIP accounts/lines - SIP-00 ~ SIP-15.
	uint16_t	callState; //bitmap: each bit (from the LSB) is corresponding to one Call. Markup dedicated bit to indicate requesting its corresponding Call's Operation State. This is designed to support 10 Concurrent Calls - SIP-00 ~ SIP-09.
	uint8_t	fxsHookState; //bitmap: each bit (from the LSB) is corresponding to one FXS phone port. Markup dedicated bit to indicate requesting its corresponding FXS phone port's Hood State. This is designed to support 8 FXS phone ports - FXS-00 ~ FXS-07.
} voiceStatsReq_t;

#define VOICE_STATS_RSP_REGISTRATION_STATUS_SET1	(1 << 0)
#define VOICE_STATS_RSP_REGISTRATION_STATUS_SET2	(1 << 1)
#define VOICE_STATS_RSP_MWI_STATUS					(1 << 2)
#define VOICE_STATS_RSP_CALL_STATE					(1 << 3)
#define VOICE_STATS_RSP_FXS_HOOK_STATUS				(1 << 4)
//------
#define VOICE_STATS_RSP_REGISTRATION_STATUS_SET_SIZE	8
#define VOICE_STATS_RSP_REGISTRATION_STATUS_MASK		0x0f
#define VOICE_STATS_RSP_REGISTRATION_STATUS_SHIFT_UNIT	4
#define VOICE_STATS_RSP_CALL_STATE_MASK			0x07
#define VOICE_STATS_RSP_CALL_STATE_SHIFT_UNIT	3
typedef struct voiceStatsRsp_s {
	uint16_t bitFlag;

	//NOTE: the following definitions SHOULD sync with those corresponding global variables in the 'vcm.c' of the ZyIMS VoIP's config system.
	uint32_t registerStatusSet1; //bitmap: every successive 4bit (from the LSB) as a set, which can represent 10 statuses, is corresponding to one SIP account/line. This set can handle 8 SIP accounts/lines - SIP-00 ~ SIP-08.
	uint32_t registerStatusSet2; //bitmap: every successive 4bit (from the LSB) as a set, which can represent 10 statuses, is corresponding to one SIP account/line. This set can handle 8 SIP accounts/lines - SIP-08 ~ SIP-15.
	//------
	uint16_t mwiStatus; //bitmap: each bit (from the LSB), which represents NoMWI=0 & IsMWI=1, is corresponding to one SIP account/line. This can handle 16 SIP accounts/lines - SIP-00 ~ SIP-15.
	uint32_t callState; //bitmap: every successive 3bit (from the LSB) as a set, which can represent 8 states, is corresponding to one Call. This can handle 10 Concurrent Calls - Call-00 ~ Call-09.
	uint8_t  fxsHookState; //bitmap: each bit (from the LSB), which represents OnHooked=0 & OffHooked=1, is corresponding to one FXS phone port. This can handle 8 FXS phone ports - FXS-00 ~ FXS-07.
} voiceStatsRsp_t;

//Michael.20131125.001.B: Add.
#define VOICE_CONTROL_REQ_CONVENTIONAL_VOIP_CLI		(1 << 0)
#define VOICE_CONTROL_REQ_SIP_REGISTER				(1 << 1)
//------
#define VOICE_CONTROL_REQ_SIP_REGISTER_SIP_ACCT_MAX	16
#define VOICE_CONTROL_REQ_SIP_REGISTER_NO_ACTION		0
#define VOICE_CONTROL_REQ_SIP_REGISTER_DO_REGISTER		1
#define VOICE_CONTROL_REQ_SIP_REGISTER_DO_DEREGISTER	2
#define VOICE_CONTROL_REQ_SIP_REGISTER_ACTION_MASK			0x03
#define VOICE_CONTROL_REQ_SIP_REGISTER_ACTION_SHIFT_UNIT	2
typedef struct voiceCtrlReq_s {
	uint32_t	bitFlag;

	//NOTE: No fixed (string-type) parameter for the conventional VoIP CLI command string is defined here, because it will be appended at the end of the structure as a payload.
	uint32_t	sipRegisterAct; //bitmap: every successive 2bit (from the LSB) as a set, which can represent 4 statuses, is corresponding to one SIP account/line's register action. Markup dedicated set to indicate requesting its corresponding SIP account/line's SIP regiter action. This is designed to support 16 SIP accounts/lines - SIP-00 ~ SIP-15.
} voiceCtrlReq_t;


#define VOICE_CONTROL_RSP_CONVENTIONAL_VOIP_CLI		(1 << 0)
#define VOICE_CONTROL_RSP_SIP_REGISTER				(1 << 1)
//------
#define VOICE_CONTROL_RSP_ACT_SUCCESS	0
#define VOICE_CONTROL_RSP_ACT_FAIL		1
typedef struct voiceCtrlRsp_s {
	uint32_t bitFlag;

	//NOTE: No fixed (string-type) parameter for the conventional VoIP CLI result string is defined here, because it will be appended at the end of the structure as a payload.
	uint16_t	sipRegisterActResult; //bitmap: each bit (from the LSB), which represents ActionSuccess=0 & ActionFail=1, is corresponding to one SIP account/line's register action result.
} voiceCtrlRsp_t;
//Michael.20131125.001.B: Add.

#endif //_ZCFG_MSG_VOICE_H
