

typedef struct dal_param_s {
	char		*paraName;
	json_type 	type;
	int			min;  //if min ==0 and max ==0, skip check
	int			max;
	int			(*validate)(int);
}dal_param_t;

enum { 
	dal_Add = 0,
	dal_Edit,
	dal_Delete
};

enum { 
	dalType_boolean = 0,
	dalType_int,
	dalType_string,
	dalType_v4Addr,
	dalType_v4Mask,
	dalType_v6Addr,
	dalType_v6AddrPrefix
};


