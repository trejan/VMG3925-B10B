#include <ctype.h>
#include <json/json.h>
//#include <json/json_object.h>
#include <time.h>

#include "zcfg_common.h"
#include "zcfg_fe_rdm_string.h"
#include "zcfg_fe_rdm_struct.h"
#include "zcfg_rdm_oid.h"
#include "zcfg_rdm_obj.h"
#include "zcfg_debug.h"
//#include "zcfg_eid.h"
#include "zcfg_msg.h"
#include "zcfg_fe_dal_common.h"

#define JSON_OBJ_COPY(json_object) json_tokener_parse(json_object_to_json_string(json_object))

dal_param_t WAN_param[]={
	{"Name",				dalType_string,	1,	32,	NULL},
	//{"Enable",				json_type_boolean,	0,	0,	NULL},
	{"Type",				dalType_string,	3,	4,	NULL},	//ATM/PTM/ETH/GPON
	{"Mode",				dalType_string,	9,	10,	NULL},	//IP_Routed/IP_Bridged
	{"Encapsulation",		dalType_string,	4,	5,	NULL},  //IPoE/IPoA/PPPoE/PPPoA
	{"ipMode",				dalType_string,	4,	9,	NULL},  //IPv4/DualStack/IPv6
	//atmLink
	{"vpivci",				dalType_string,	1,	256,	NULL},
	{"AtmEncapsulation",	dalType_string,	1,	6,	NULL},
	{"QoSClass",			dalType_string,	3,	8,	NULL},  //UBR/CBR/VBR-nrt/VBR-rt
	{"atmPeakCellRate",		dalType_int,	0,	0,	NULL},
	{"atmSustainedCellRate",dalType_int,	0,	0,	NULL},
	{"atmMaxBurstSize",		dalType_int,	0,	0,	NULL},
	//GPON
	{"slidValue",			dalType_int,	0,	0,	NULL},
	//VLAN term
	{"VLANEnable",			dalType_boolean,	0,	0,	NULL},
	{"VLANID",				dalType_int,		-1,	4094,	NULL},
	{"VLANPriority",		dalType_int,		-1,	7,	NULL},
	//ppp Iface
	{"pppUsername",			dalType_string,	0,	0,	NULL},
	{"pppPassword",			dalType_string,	0,	0,	NULL},
	{"ConnectionTrigger",	dalType_string,	0,	0,	NULL}, //AlwaysOn/OnDemand
	{"IdleDisconnectTime",	dalType_int,	0,	0,	NULL},
	{"pppoePassThrough",	dalType_boolean,	0,	0,	NULL},
	//Nat
	{"NatEnable",			dalType_boolean,	0,	0,	NULL},
	{"FullConeEnabled",		dalType_boolean,	0,	0,	NULL},
	//IGMP/MLD
	{"IGMPEnable",			dalType_boolean,	0,	0,	NULL},
	{"MLDEnable",			dalType_boolean,	0,	0,	NULL},
	//DNS
	{"ipDnsStatic",			dalType_boolean,	0,	0,	NULL},
	{"DNSServer",			dalType_string,	0,	0,	NULL},
	{"ip6DnsStatic",		dalType_boolean,	0,	0,	NULL},
	{"DNS6Server",			dalType_string,	0,	0,	NULL},
	//router
	{"sysGwEnable",			dalType_boolean,	0,	0,	NULL},
	{"sysGw6Enable",		dalType_boolean,	0,	0,	NULL},
	//6RD
	{"Enable_6RD",			dalType_boolean,	0,	0,	NULL},
	{"v6RD_Type",			dalType_string,	0,	0,	NULL}, //dhcp/static
	{"SPIPv6Prefix",		dalType_string,	0,	0,	NULL},
	{"IPv4MaskLength",		dalType_int,	0,	32,	NULL},
	{"BorderRelayIPv4Addresses",dalType_v4Addr,	0,	0,	NULL},
	//DSLite
	{"DSLiteEnable",		dalType_boolean,	0,	0,	NULL},
	{"DSLiteType",			dalType_string,	0,	0,	NULL},
	{"DSLiteRelayIPv6Addresses",	dalType_string,	0,	0,	NULL},
	//ipIface or pppIface
	{"MaxMTUSize",			dalType_int,	0,	0,	NULL},
	//Address, gateway, DHCP
	{"ipStatic",			dalType_boolean,	0,	0,	NULL},
	{"IPAddress",			dalType_v4Addr,	0,	0,	NULL},
	{"SubnetMask",			dalType_v4Mask,	0,	0,	NULL},
	{"GatewayIPAddress",	dalType_v4Addr,	0,	0,	NULL},
	{"ip6Static",			dalType_boolean,	0,	0,	NULL},
	{"IP6Address",			dalType_v6AddrPrefix,	0,	0,	NULL},
	{"NextHop",				dalType_v6Addr,	0,	0,	NULL},
	//DHCP
	{"option43Enable",		dalType_boolean,	0,	0,	NULL},
	{"option120Enable",		dalType_boolean,	0,	0,	NULL},
	{"option121Enable",		dalType_boolean,	0,	0,	NULL},
	{"option60Enable",		dalType_boolean,	0,	0,	NULL},
	{"option60Value",		dalType_string,	0,	0,	NULL},
	{"option61Enable",		dalType_boolean,	0,	0,	NULL},
	{"option61Value",		dalType_string,	0,	0,	NULL},
	{"option125Enable",		dalType_boolean,	0,	0,	NULL},
	{"option125Value",		dalType_string,	0,	0,	NULL},
	{NULL,					0,	0,	0,	NULL},
};


char currLowerLayers[128] = {0};
char ipIfacePath[32] = {0};

bool isAdd = false;
bool isDelete = false;

const char *Name, *Type, *Mode, *Encapsulation, *ipMode, *v6RD_Type;
bool ipStatic, ip6Static, Enable_6RD;

char CurrType[16] = {0};
char CurrMode[16] = {0};
char CurrEncapsulation[16] = {0};
char CurrIpMode[16] = {0};
char CurrV6RD_Type[16] = {0};
bool CurrIpStatic = false, CurrIp6Static = false, CurrEnable_6RD = false;


struct json_object *atmLinkObj = NULL;
struct json_object *atmLinkQosObj = NULL;
struct json_object *ptmLinkObj = NULL;
struct json_object *ethIfaceObj = NULL;
struct json_object *ethLinkObj = NULL;
struct json_object *vlanTermObj = NULL;
struct json_object *pppIfaceObj = NULL;
struct json_object *ipIfaceObj = NULL;
struct json_object *v4ClientObj = NULL;
struct json_object *opt43Obj = NULL;
struct json_object *opt120Obj = NULL;
struct json_object *opt121Obj = NULL;
struct json_object *opt212Obj = NULL;
struct json_object *opt60Obj = NULL;
struct json_object *opt61Obj = NULL;
struct json_object *opt125Obj = NULL;
struct json_object *igmpObj = NULL;
struct json_object *mldObj = NULL;
struct json_object *natIntfObj = NULL;
struct json_object *ripObj = NULL;
struct json_object *dnsClientSrv4Obj = NULL;
struct json_object *dnsClientSrv6Obj = NULL;
struct json_object *dynamicDnsClientSrv4Obj = NULL;
struct json_object *dynamicDnsClientSrv6Obj = NULL;
struct json_object *routerObj = NULL;
struct json_object *v4FwdObj = NULL;
struct json_object *v6FwdObj = NULL;
//struct json_object *dynamicV4FwdObj = NULL;
//struct json_object *dynamicV6FwdObj = NULL;
struct json_object *v4AddrObj = NULL;
struct json_object *v6AddrObj = NULL;
struct json_object *dnsObj = NULL;

objIndex_t atmLinkIid = {0};
objIndex_t atmLinkQosIid = {0};
objIndex_t ptmLinkIid = {0};
objIndex_t ethIfaceIid = {0};
objIndex_t ethLinkIid = {0};
objIndex_t vlanTermIid = {0};
objIndex_t pppIfaceIid = {0};
objIndex_t ipIfaceIid = {0};
objIndex_t v4ClientIid = {0};
objIndex_t opt43Iid = {0};
objIndex_t opt120Iid = {0};
objIndex_t opt121Iid = {0};
objIndex_t opt212Iid = {0};
objIndex_t opt60Iid = {0};
objIndex_t opt61Iid = {0};
objIndex_t opt125Iid = {0};
objIndex_t igmpIid = {0};
objIndex_t mldIid = {0};
objIndex_t natIntfIid = {0};
objIndex_t ripIid = {0};
objIndex_t dnsClientSrv4Iid = {0};
objIndex_t dnsClientSrv6Iid = {0};
objIndex_t dynamicDnsClientSrv4Iid = {0};
objIndex_t dynamicDnsClientSrv6Iid = {0};
objIndex_t routerIid = {0};
objIndex_t v4FwdIid = {0};
objIndex_t v6FwdIid = {0};
objIndex_t v4AddrIid = {0};
objIndex_t v6AddrIid = {0};
objIndex_t dnsIid = {0};

time_t t1, t2;

//the length of delim must be 1 or function may not work well
bool genNewInterface(char *delim, char *newInterface, const char *oldInterface, const char *targetIntf, bool add){
	bool changed = false, firstEnter = true, findTarget = false;
	char buff[512] = {0}, *intf = NULL, *tmp_ptr = NULL;

	strcpy(buff, oldInterface);
	intf = strtok_r(buff, delim, &tmp_ptr);
	while(intf != NULL){
		if(!strcmp(intf, targetIntf))
			findTarget = true;
		intf = strtok_r(NULL, delim, &tmp_ptr);
	}
	
	if(add && !findTarget){
		strcpy(newInterface, oldInterface);
		if(newInterface[0] != '\0' && newInterface[strlen(newInterface)-1] != *delim)
			strcat(newInterface, delim);
		strcat(newInterface, targetIntf);
		changed = true;
	}
	else if(!add && findTarget){
		tmp_ptr = NULL;
		intf = NULL;
		strcpy(buff, oldInterface);
			
		intf = strtok_r(buff, delim, &tmp_ptr);
		while(intf != NULL){
			if(*intf != '\0' && !strstr(intf, targetIntf)){
				if(!firstEnter && intf != NULL){
					strcat(newInterface, delim);
				}
				strcat(newInterface, intf);
				firstEnter = false;
			}
			intf = strtok_r(NULL, delim, &tmp_ptr);
		}
		changed = true;
	}

	return changed;
}

bool getSpecificObj(zcfg_offset_t oid, char *key, json_type type, void *value, objIndex_t *outIid, struct json_object **outJobj)
{
	objIndex_t iid;
	struct json_object *Obj = NULL;
	struct json_object *pramJobj;
	bool found = false;

	IID_INIT(iid);
	while(zcfgFeObjJsonGetNextWithoutUpdate(oid, &iid, &Obj) == ZCFG_SUCCESS) {
		pramJobj = json_object_object_get(Obj, key);
		if(pramJobj != NULL){
			if(type == json_type_string){
				if(!strcmp((const char*)value, json_object_get_string(pramJobj))){
					found = true;
				}
			}
			else{
				if(*(int*)value == json_object_get_int(pramJobj))
					found = true;
			}
			
			if(found){
				if(outIid) memcpy(outIid, &iid, sizeof(objIndex_t));
				if(outJobj) *outJobj = Obj;
				else json_object_put(Obj);
				break;
			}
		}
		json_object_put(Obj);
	}

	return found;
}

//find key2 in Jobj2, if it exist add it to Jobj1 as key1
int replaceParam(struct json_object *Jobj1, char *key1, struct json_object *Jobj2, char *key2){
	struct json_object *pramJobj = NULL;

	pramJobj = json_object_object_get(Jobj2, key2);
	if(pramJobj){
		json_object_object_add(Jobj1, key1, JSON_OBJ_COPY(pramJobj));
		return 1;
	}
	return 0;
}

static zcfgRet_t AddandCheckDefaultParam(struct json_object *Jobj){

	if(Type == NULL){
		json_object_object_add(Jobj, "Type", json_object_new_string("ATM"));
		Type = json_object_get_string(json_object_object_get(Jobj, "Type"));
	}
	else if(strcmp(Type, "ATM") && 
			strcmp(Type, "PTM") && 
			strcmp(Type, "ETH") && 
			strcmp(Type, "GPON")){
		return ZCFG_INVALID_PARAM_VALUE;
	}

	if(strcmp(Type, "ATM")){
		if(json_object_object_get(Jobj, "QoSClass") == NULL)
			json_object_object_add(Jobj, "QoSClass", json_object_new_string("UBR"));
	}

	if(Mode == NULL){
		json_object_object_add(Jobj, "Mode", json_object_new_string("IP_Routed"));
		Mode = json_object_get_string(json_object_object_get(Jobj, "Mode"));
	}
	else if(strcmp(Mode, "IP_Routed") && strcmp(Mode, "IP_Bridged")){
		return ZCFG_INVALID_PARAM_VALUE;
	}

	if(json_object_get_boolean(json_object_object_get(Jobj, "VLANEnable")) == false){
		json_object_object_add(Jobj, "VLANID", json_object_new_int(-1));
		json_object_object_add(Jobj, "VLANPriority", json_object_new_int(-1));
	}
	
	if(!strcmp(Mode, "IP_Bridged")){
		return ZCFG_SUCCESS;
	}

	if(Encapsulation == NULL || *Encapsulation == '\0'){
		json_object_object_add(Jobj, "Encapsulation", json_object_new_string("IPoE"));
		Encapsulation = json_object_get_string(json_object_object_get(Jobj, "Encapsulation"));
	}
	else if(strcmp(Encapsulation, "IPoE") &&
			strcmp(Encapsulation, "IPoA") &&
			strcmp(Encapsulation, "PPPoE") &&
			strcmp(Encapsulation, "PPPoA")){
		return ZCFG_INVALID_PARAM_VALUE;
	}

	if(!strcmp(Encapsulation, "PPPoE") || !strcmp(Encapsulation, "PPPoA")){
		if(json_object_object_get(Jobj, "ConnectionTrigger") == NULL)
			json_object_object_add(Jobj, "ConnectionTrigger", json_object_new_string("AlwaysOn"));
		if(json_object_object_get(Jobj, "MaxMTUSize") == NULL)
			json_object_object_add(ipIfaceObj, "MaxMTUSize", json_object_new_int(1492));
	}
	else{ //IPoE/IPoA
		if(json_object_object_get(Jobj, "MaxMTUSize") == NULL)
			json_object_object_add(ipIfaceObj, "MaxMTUSize", json_object_new_int(1500));
	}

	if(ipMode == NULL){//IPv4/DualStack/IPv6
		json_object_object_add(Jobj, "ipMode", json_object_new_string("IPv4"));
		ipMode = json_object_get_string(json_object_object_get(Jobj, "ipMode"));
	}
	else if(strcmp(ipMode, "IPv4") &&
			strcmp(ipMode, "IPv6") &&
			strcmp(ipMode, "DualStack")){
		return ZCFG_INVALID_PARAM_VALUE;
	}
	
	if(json_object_object_get(Jobj, "NatEnable") == NULL)
		json_object_object_add(Jobj, "NatEnable", json_object_new_boolean(true));
	
	if(!strcmp(ipMode, "IPv4")){
		if(Enable_6RD){
			if(v6RD_Type == NULL){
				json_object_object_add(Jobj, "v6RD_Type", json_object_new_string("dhcp"));
				v6RD_Type = json_object_get_string(json_object_object_get(Jobj, "v6RD_Type"));
			}
			else if(strcmp(v6RD_Type, "dhcp") && strcmp(v6RD_Type, "static")){
				return ZCFG_INVALID_PARAM_VALUE;
			}

			if(!strcmp(v6RD_Type, "dhcp"))
				json_object_object_add(Jobj, "option212Enable", json_object_new_boolean(true));
		}
	}
	if(!strcmp(ipMode, "IPv6")){//dslite
	}

	

	return ZCFG_SUCCESS;
}

static bool isXTMLinkHasReference(struct json_object *Jobj){
	char atmLinkPath[16] = {0};
	const char *LowerLayer = NULL;
	zcfg_offset_t oid;
	objIndex_t iid;
	struct json_object *Obj;
	zcfg_offset_t currRefOid; 
	objIndex_t currRefIid;

	printf("isXTMLinkHasReference\n");

	if(!strcmp(CurrType, "ATM") && (atmLinkObj != NULL))
		sprintf(atmLinkPath, "ATM.Link.%u", atmLinkIid.idx[0]);
	else if(!strcmp(CurrType, "PTM") && (ptmLinkObj != NULL))
		sprintf(atmLinkPath, "PTM.Link.%u", ptmLinkIid.idx[0]);
	else
		return true;

	printf("atmLinkPath=%s\n", atmLinkPath);
	
	IID_INIT(currRefIid);
	if(!strcmp(CurrEncapsulation, "PPPoA")){
		currRefOid = RDM_OID_PPP_IFACE; 
		memcpy(&currRefIid, &pppIfaceIid, sizeof(objIndex_t));
	}
	else if(!strcmp(CurrEncapsulation, "IPoA")){
		currRefOid = RDM_OID_IP_IFACE; 
		memcpy(&currRefIid, &ipIfaceIid, sizeof(objIndex_t));
	}
	else{//IPoE or PPPoE
		currRefOid = RDM_OID_ETH_LINK; 
		memcpy(&currRefIid, &ethLinkIid, sizeof(objIndex_t));
	}

	printf("currRefOid=%d\n", currRefOid);

	oid = RDM_OID_ETH_LINK;
	IID_INIT(iid);
	while(zcfgFeObjJsonGetNextWithoutUpdate(oid, &iid, &Obj) == ZCFG_SUCCESS) {
		LowerLayer = json_object_get_string(json_object_object_get(Obj, "LowerLayers"));
		if((LowerLayer != NULL) && !strcmp(LowerLayer, atmLinkPath)){
			if((oid != currRefOid) || memcmp(&iid, &currRefIid, sizeof(objIndex_t))){
				json_object_put(Obj);
				printf("line=%d\n", __LINE__);
				return true;
			}
		}
		json_object_put(Obj);
	}

	if(!strcmp(CurrType, "PTM")){
		printf("isXTMLinkHasReference false\n");
		return false;
	}

	oid = RDM_OID_PPP_IFACE;
	IID_INIT(iid);
	while(zcfgFeObjJsonGetNextWithoutUpdate(oid, &iid, &Obj) == ZCFG_SUCCESS) {
		LowerLayer = json_object_get_string(json_object_object_get(Obj, "LowerLayers"));
		if((LowerLayer != NULL) && !strcmp(LowerLayer, atmLinkPath)){
			if((oid != currRefOid) || memcmp(&iid, &currRefIid, sizeof(objIndex_t))){
				json_object_put(Obj);
				printf("line=%d\n", __LINE__);
				return true;
			}
		}
		json_object_put(Obj);
	}

	oid = RDM_OID_IP_IFACE;
	IID_INIT(iid);
	while(zcfgFeObjJsonGetNextWithoutUpdate(oid, &iid, &Obj) == ZCFG_SUCCESS) {
		LowerLayer = json_object_get_string(json_object_object_get(Obj, "LowerLayers"));
		if((LowerLayer != NULL) && !strcmp(LowerLayer, atmLinkPath)){
			if((oid != currRefOid) || memcmp(&iid, &currRefIid, sizeof(objIndex_t))){
				json_object_put(Obj);
				printf("line=%d\n", __LINE__);
				return true;
			}
		}
		json_object_put(Obj);
	}

	printf("isXTMLinkHasReference false\n");
	return false;
	
}

zcfgRet_t editAtmObjects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	bool isNewAtmObj = false;
	const char *vpivci = json_object_get_string(json_object_object_get(Jobj, "vpivci"));
	const char *currVpivci;

	if(isAdd && vpivci == NULL){ //add case
		printf("need vpivci\n");
		return ZCFG_INVALID_PARAM_VALUE;
	}
	
	if(!isAdd){ //edit case
		currVpivci = json_object_get_string(json_object_object_get(atmLinkObj, "DestinationAddress"));
		if(vpivci != NULL && strcmp(currVpivci, vpivci)){
			if(!isXTMLinkHasReference(Jobj)){
				zcfgFeObjJsonDel(RDM_OID_ATM_LINK, &atmLinkIid, NULL);
			}
			zcfgFeJsonObjFree(atmLinkObj);
		}
		else{
			//do nothing. If vpivci == NULL or vpivci == currVpivci, it means vci/vpi are not changed
		}
	}
	
	if(!isAdd && atmLinkObj != NULL){
		//edit case and vci/vpi are not changed, no need to re-get atm object.
	}
	else if(!getSpecificObj(RDM_OID_ATM_LINK, "DestinationAddress", json_type_string, vpivci, &atmLinkIid, &atmLinkObj)){
		//edit or add case, need new atmLink obj.
		IID_INIT(atmLinkIid);
		zcfgFeObjJsonAdd(RDM_OID_ATM_LINK, &atmLinkIid, NULL);
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK, &atmLinkIid, &atmLinkObj);
		isNewAtmObj = true;
		replaceParam(atmLinkObj, "DestinationAddress", Jobj, "vpivci");
	}
	sprintf(currLowerLayers, "ATM.Link.%u", atmLinkIid.idx[0]);

	if(atmLinkQosObj == NULL)
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK_QOS, &atmLinkIid, &atmLinkQosObj);
	
	if(isNewAtmObj){ //set defalult values
		json_object_object_add(atmLinkObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(atmLinkObj, "Encapsulation", json_object_new_string("LLC"));
		json_object_object_add(atmLinkObj, "LowerLayers", json_object_new_string("DSL.Channel.1"));
	}

	/* set atmQos object first */
	replaceParam(atmLinkQosObj, "QoSClass", Jobj, "QoSClass");
	replaceParam(atmLinkQosObj, "MaximumBurstSize", Jobj, "atmMaxBurstSize");
	replaceParam(atmLinkQosObj, "SustainableCellRate", Jobj, "atmSustainedCellRate");
	replaceParam(atmLinkQosObj, "PeakCellRate", Jobj, "atmPeakCellRate");
	memcpy(&atmLinkQosIid, &atmLinkIid, sizeof(objIndex_t));

	if(!isAdd && Mode == NULL){
		Mode = CurrMode;
	}
	if(!strcmp(Mode, "IP_Bridged")){
		json_object_object_add(atmLinkObj, "LinkType", json_object_new_string("EoA"));
	}
	else{ //IP_Routed
		if(!strcmp(Encapsulation, "PPPoE") || !strcmp(Encapsulation, "IPoE")){
			json_object_object_add(atmLinkObj, "LinkType", json_object_new_string("EoA"));
		}
		else{
			json_object_object_add(atmLinkObj, "LinkType", json_object_new_string(Encapsulation));
		}
	}
	replaceParam(atmLinkObj, "Encapsulation", Jobj, "AtmEncapsulation");

	return ret;
}

zcfgRet_t editPtmObjects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;

	if(!isAdd){ //do nothing for edit case
		sprintf(currLowerLayers, "PTM.Link.%u", ptmLinkIid.idx[0]);
		if(ptmLinkObj) {zcfgFeJsonObjFree(ptmLinkObj);}
		return ret;
	}
		
	IID_INIT(ptmLinkIid);
	if(zcfgFeObjJsonGetNextWithoutUpdate(RDM_OID_PTM_LINK, &ptmLinkIid, &ptmLinkObj) != ZCFG_SUCCESS){
		IID_INIT(ptmLinkIid);
		zcfgFeObjJsonAdd(RDM_OID_PTM_LINK, &ptmLinkIid, NULL);
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_PTM_LINK, &ptmLinkIid, &ptmLinkObj);

		json_object_object_add(ptmLinkObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(ptmLinkObj, "X_ZYXEL_QueueShapingBurstSize", json_object_new_int(3000));
		json_object_object_add(ptmLinkObj, "X_ZYXEL_ConnectionMode", json_object_new_string("VlanMuxMode"));
		json_object_object_add(ptmLinkObj, "X_ZYXEL_SchedulerAlgorithm", json_object_new_string("WRR"));
		json_object_object_add(ptmLinkObj, "X_ZYXEL_EnableADSLPtm", json_object_new_boolean(true));
		json_object_object_add(ptmLinkObj, "LowerLayers", json_object_new_string("DSL.Channel.2"));
		
	}
	sprintf(currLowerLayers, "PTM.Link.%u", ptmLinkIid.idx[0]);

	return ret;
}

#if 0
zcfgRet_t editGponObjects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t iid;
	struct json_object *opticalIntfObj = NULL;
	int Enable = 1;

	if(getSpecificObj(RDM_OID_ONU, "Upstream", json_type_boolean, &Enable, &iid, &opticalIntfObj))
		sprintf(currLowerLayers, "Optical.Interface.%u", iid.idx[0]);
	else
		return ZCFG_INTERNAL_ERROR;

	
	json_object_put(opticalIntfObj);
	return ret;
}
#endif

zcfgRet_t editPhyLayerObjects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	objIndex_t iid;
	int value;
	
	if(!strcmp(Type, "ATM")){
		ret = editAtmObjects(Jobj);
	}
	else if(!strcmp(Type, "PTM")){
		ret = editPtmObjects(Jobj);
	}
	else if(!strcmp(Type, "ETH")){
		value = 1;
		if(getSpecificObj(RDM_OID_ETH_IFACE, "Upstream", json_type_boolean, &value, &iid, NULL))
			sprintf(currLowerLayers, "Ethernet.Interface.%u", iid.idx[0]);
		else
			currLowerLayers[0] = '\0';
	}
	//else if(!strcmp(Type, "GPON")){
	//	ret = editGponObjects(Jobj);
	//}

	return ret;
}

zcfgRet_t editEthLinkObject(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;

	if(!strcmp(Mode, "IP_Routed") && (!strcmp(Encapsulation, "IPoA") || !strcmp(Encapsulation, "PPPoA")))
		return ret;

	if(isAdd){// add case
		IID_INIT(ethLinkIid);
		if((ret = zcfgFeObjJsonAdd(RDM_OID_ETH_LINK, &ethLinkIid, NULL)) != ZCFG_SUCCESS)
			return ret;
		if((ret = zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ETH_LINK, &ethLinkIid, &ethLinkObj)) != ZCFG_SUCCESS)
			return ret;
	}

	json_object_object_add(ethLinkObj, "Enable", json_object_new_boolean(true));
	json_object_object_add(ethLinkObj, "LowerLayers", json_object_new_string(currLowerLayers));
	if(Type && !strcmp(Type, "ETH"))
		json_object_object_add(ethLinkObj, "X_ZYXEL_OrigEthWAN", json_object_new_boolean(true));
	
	sprintf(currLowerLayers, "Ethernet.Link.%u", ethLinkIid.idx[0]);
	
	return ret;
}

zcfgRet_t editVlanTermObject(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;

	if(!strcmp(Mode, "IP_Routed") && (!strcmp(Encapsulation, "IPoA") || !strcmp(Encapsulation, "PPPoA")))
		return ret;

	if(isAdd){
		IID_INIT(vlanTermIid);
		if((ret = zcfgFeObjJsonAdd(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, NULL)) != ZCFG_SUCCESS)
			return ret;
		if((ret = zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, &vlanTermObj)) != ZCFG_SUCCESS)
			return ret;
	}
	
	json_object_object_add(vlanTermObj, "Enable", json_object_new_boolean(true));
	json_object_object_add(vlanTermObj, "LowerLayers", json_object_new_string(currLowerLayers));

	replaceParam(vlanTermObj, "X_ZYXEL_VLANEnable", Jobj, "VLANEnable");
	replaceParam(vlanTermObj, "VLANID", Jobj, "VLANID");
	replaceParam(vlanTermObj, "X_ZYXEL_VLANPriority", Jobj, "VLANPriority");
	
	sprintf(currLowerLayers, "Ethernet.VLANTermination.%u", vlanTermIid.idx[0]);
	
	return ret;
}

zcfgRet_t editNatSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//objIndex_t iid;
	zcfg_offset_t oid;
	//struct json_object *obj = NULL;
	bool CurrNatEnabled=false, CurrFullConeEnabled=false;
	bool NatEnable=false, FullConeEnabled=false;
	struct json_object *pramJobj = NULL;
	
	if(natIntfObj != NULL){
		CurrNatEnabled = true;
		CurrFullConeEnabled = json_object_get_boolean(json_object_object_get(natIntfObj, "X_ZYXEL_FullConeEnabled"));
	}

	pramJobj = json_object_object_get(Jobj, "NatEnable");
	if(pramJobj)
		NatEnable = json_object_get_boolean(pramJobj);
	else
		NatEnable = CurrNatEnabled;

	if(NatEnable){
		pramJobj = json_object_object_get(Jobj, "FullConeEnabled");
		if(pramJobj)
			FullConeEnabled = json_object_get_boolean(pramJobj);
		else
			FullConeEnabled = CurrFullConeEnabled;
	}

	printf("CurrNatEnabled=%d NatEnable=%d\n", CurrNatEnabled, NatEnable);
	printf("CurrFullConeEnabled=%d FullConeEnabled=%d\n", CurrFullConeEnabled, FullConeEnabled);

	if(CurrNatEnabled && NatEnable){ //enable to enable
		if(FullConeEnabled != CurrFullConeEnabled){
			json_object_object_add(natIntfObj, "X_ZYXEL_FullConeEnabled", json_object_new_boolean(FullConeEnabled));
		}else{
			if(natIntfObj) {zcfgFeJsonObjFree(natIntfObj);}
			if(ripObj){zcfgFeJsonObjFree(ripObj);}
		}
	}
	else if(CurrNatEnabled && !NatEnable){ ////enable to disable
		json_object_object_add(natIntfObj, "Enable", json_object_new_boolean(false));
		json_object_object_add(natIntfObj, "FullConeEnabled", json_object_new_boolean(false));
		json_object_object_add(natIntfObj, "Interface", json_object_new_string(""));

		//enable rip
		if(ripObj){zcfgFeJsonObjFree(ripObj);}
		oid = RDM_OID_ROUTING_RIP_INTF_SET;
		if(!getSpecificObj(oid, "Interface", json_type_string, "", &ripIid, &ripObj)){
			IID_INIT(ripIid);
			zcfgFeObjJsonAdd(oid, &ripIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &ripIid, &ripObj);
		}
		json_object_object_add(ripObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(ripObj, "Interface", json_object_new_string(ipIfacePath));
		json_object_object_add(ripObj, "X_ZyXEL_Version", json_object_new_string("RIPv2"));
		json_object_object_add(ripObj, "X_ZyXEL_RipOpMode", json_object_new_string("Active"));	
	}
	else if(!CurrNatEnabled && NatEnable){ //disable to enable or add WAN case
		oid = RDM_OID_NAT_INTF_SETTING;
		if(!getSpecificObj(oid, "Interface", json_type_string, "", &natIntfIid, &natIntfObj)){
			IID_INIT(natIntfIid);
			zcfgFeObjJsonAdd(oid, &natIntfIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &natIntfIid, &natIntfObj);
		}
		json_object_object_add(natIntfObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(natIntfObj, "Interface", json_object_new_string(ipIfacePath));
		replaceParam(natIntfObj, "X_ZYXEL_FullConeEnabled", Jobj, "FullConeEnabled");

		//disable rip
		if(ripObj){
			json_object_object_add(ripObj, "Enable", json_object_new_boolean(false));
			json_object_object_add(ripObj, "Interface", json_object_new_string(""));
		}
	}
	else{//disable to disable (or add WAN case without enable NAT, so need to add rip obj)
		if(natIntfObj){zcfgFeJsonObjFree(natIntfObj);}
		if(ripObj) {zcfgFeJsonObjFree(ripObj);}

		if(isAdd){
			oid = RDM_OID_ROUTING_RIP_INTF_SET;
			if(!getSpecificObj(oid, "Interface", json_type_string, "", &ripIid, &ripObj)){
				IID_INIT(ripIid);
				zcfgFeObjJsonAdd(oid, &ripIid, NULL);
				zcfgFeObjJsonGetWithoutUpdate(oid, &ripIid, &ripObj);
			}
			json_object_object_add(ripObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(ripObj, "Interface", json_object_new_string(ipIfacePath));
			json_object_object_add(ripObj, "X_ZyXEL_Version", json_object_new_string("RIPv2"));
			json_object_object_add(ripObj, "X_ZyXEL_RipOpMode", json_object_new_string("Active"));
		}
	}

	return ret;
}

zcfgRet_t editDnsSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	zcfg_offset_t oid;
	struct json_object *pramJobj = NULL;
	bool isIp4DnsObjAdd = false;
	bool ipDnsStatic=false, ip6DnsStatic=false;
	bool CurrIpDnsStatic=false, CurrIp6DnsStatic=false;
	const char *DNSServer;
	const char *CurrDNSServer;

	if(dnsClientSrv4Obj != NULL) CurrIpDnsStatic = true;
	if(dnsClientSrv6Obj != NULL) CurrIp6DnsStatic = true;	

	pramJobj = json_object_object_get(Jobj, "ipDnsStatic");
	if(pramJobj)
		ipDnsStatic = json_object_get_boolean(pramJobj);
	else
		ipDnsStatic = CurrIpDnsStatic;

	pramJobj = json_object_object_get(Jobj, "ip6DnsStatic");
	if(pramJobj)
		ip6DnsStatic = json_object_get_boolean(pramJobj);
	else
		ip6DnsStatic = CurrIp6DnsStatic;
	
	printf("CurrIpDnsStatic=%d ipDnsStatic=%d\n", CurrIpDnsStatic, ipDnsStatic);
	printf("CurrIp6DnsStatic=%d ip6DnsStatic=%d\n", CurrIp6DnsStatic, ip6DnsStatic);

	if(CurrIpDnsStatic && ipDnsStatic){ //enable to enable
		DNSServer = json_object_get_string(json_object_object_get(Jobj, "DNSServer"));
		CurrDNSServer = json_object_get_string(json_object_object_get(dnsClientSrv4Obj, "DNSServer"));
		if(strcmp(DNSServer, CurrDNSServer)){
			json_object_object_add(dnsClientSrv4Obj, "DNSServer", json_object_new_string(DNSServer));
		}
		else{
			if(dnsClientSrv4Obj) {zcfgFeJsonObjFree(dnsClientSrv4Obj);}
		}
	}
	else if(CurrIpDnsStatic && !ipDnsStatic){ ////enable to disable
		//json_object_object_add(dnsClientSrv4Obj, "Enable", json_object_new_boolean(false));
		json_object_object_add(dnsClientSrv4Obj, "Interface", json_object_new_string(""));
	}
	else if(!CurrIpDnsStatic && ipDnsStatic){ //disable to enable
		if(dnsClientSrv4Obj) {zcfgFeJsonObjFree(dnsClientSrv4Obj);} //should not happened, just to make sure no memory leak.

		isIp4DnsObjAdd = true;
		oid = RDM_OID_DNS_CLIENT_SRV;
		if(!getSpecificObj(oid, "Interface", json_type_string, "", &dnsClientSrv4Iid, &dnsClientSrv4Obj)){
			IID_INIT(dnsClientSrv4Iid);
			zcfgFeObjJsonAdd(oid, &dnsClientSrv4Iid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &dnsClientSrv4Iid, &dnsClientSrv4Obj);
		}
		json_object_object_add(dnsClientSrv4Obj, "Enable", json_object_new_boolean(true));
		json_object_object_add(dnsClientSrv4Obj, "Interface", json_object_new_string(ipIfacePath));
		json_object_object_add(dnsClientSrv4Obj, "X_ZYXEL_Type", json_object_new_string("Static"));
		replaceParam(dnsClientSrv4Obj, "DNSServer", Jobj, "DNSServer");
	}
	else{//do nothing for disable to disable
		if(dnsClientSrv4Obj) {zcfgFeJsonObjFree(dnsClientSrv4Obj);}
	}

	if(CurrIp6DnsStatic && ip6DnsStatic){ //enable to enable
		DNSServer = json_object_get_string(json_object_object_get(Jobj, "DNS6Server"));
		CurrDNSServer = json_object_get_string(json_object_object_get(dnsClientSrv6Obj, "DNSServer"));
		if(strcmp(DNSServer, CurrDNSServer)){
			json_object_object_add(dnsClientSrv6Obj, "DNSServer", json_object_new_string(DNSServer));
		}else{
			if(dnsClientSrv6Obj) {zcfgFeJsonObjFree(dnsClientSrv6Obj);}
		}
	}
	else if(CurrIp6DnsStatic && !ip6DnsStatic){ ////enable to disable
		//json_object_object_add(dnsClientSrv6Obj, "Enable", json_object_new_boolean(false));
		json_object_object_add(dnsClientSrv6Obj, "Interface", json_object_new_string(""));
		
	}
	else if(!CurrIp6DnsStatic && ip6DnsStatic){ //disable to enable
		if(dnsClientSrv6Obj) {zcfgFeJsonObjFree(dnsClientSrv6Obj);} //should not happened, just to make sure no memory leak.
		oid = RDM_OID_DNS_CLIENT_SRV;
		if(isIp4DnsObjAdd){ // if v4dns obj was added before, do not try to get empty obj!
			IID_INIT(dnsClientSrv6Iid);
			zcfgFeObjJsonAdd(oid, &dnsClientSrv6Iid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &dnsClientSrv6Iid, &dnsClientSrv6Obj);
		}
		else if(!getSpecificObj(oid, "Interface", json_type_string, "", &dnsClientSrv6Iid, &dnsClientSrv6Obj)){
			IID_INIT(dnsClientSrv6Iid);
			zcfgFeObjJsonAdd(oid, &dnsClientSrv6Iid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &dnsClientSrv6Iid, &dnsClientSrv6Obj);
		}
		json_object_object_add(dnsClientSrv6Obj, "Enable", json_object_new_boolean(true));
		json_object_object_add(dnsClientSrv6Obj, "Interface", json_object_new_string(ipIfacePath));
		json_object_object_add(dnsClientSrv6Obj, "X_ZYXEL_Type", json_object_new_string("Static"));
		replaceParam(dnsClientSrv6Obj, "DNSServer", Jobj, "DNS6Server");
	}
	else{//do nothing for disable to disable
		if(dnsClientSrv6Obj) {zcfgFeJsonObjFree(dnsClientSrv6Obj);}
	}

	return ret;
}

zcfgRet_t addStaticAddrSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//objIndex_t iid;
	zcfg_offset_t oid;
	//struct json_object *obj = NULL;
	struct json_object *pramJobj = NULL;
	//const char *Encapsulation, *ipMode;
	bool ipStatic = false, ip6Static = false;

	/* static ipv4*/
	pramJobj=json_object_object_get(Jobj, "ipStatic");
	if(pramJobj)
		ipStatic = json_object_get_boolean(pramJobj);
	if(strcmp(ipMode, "IPv6") && (!strcmp(Encapsulation, "IPoA")|| ipStatic)){
		oid = RDM_OID_ROUTING_ROUTER_V4_FWD;
		if(!getSpecificObj(oid, "Interface", json_type_string, "", &v4FwdIid, &v4FwdObj)){
			IID_INIT(v4FwdIid);
			v4FwdIid.level = 1;
			v4FwdIid.idx[0] = 1;
			zcfgFeObjJsonAdd(oid, &v4FwdIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &v4FwdIid, &v4FwdObj);
		}
		json_object_object_add(v4FwdObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v4FwdObj, "Interface", json_object_new_string(ipIfacePath));
		replaceParam(v4FwdObj, "GatewayIPAddress", Jobj, "GatewayIPAddress");
		//if((ret = zcfgFeObjJsonSetWithoutApply(oid, &v4FwdIid, obj, NULL)) != ZCFG_SUCCESS)
		//	printf("set oid:%d fail, line=%d, ret=%d\n", oid, __LINE__, ret);
		//json_object_put(obj);

		oid = RDM_OID_IP_IFACE_V4_ADDR;
		IID_INIT(v4AddrIid);
		v4AddrIid.level = 1;
		sscanf(ipIfacePath, "IP.Interface.%hhu", &v4AddrIid.idx[0]);
		zcfgFeObjJsonAdd(oid, &v4AddrIid, NULL);
		zcfgFeObjJsonGetWithoutUpdate(oid, &v4AddrIid, &v4AddrObj);
		json_object_object_add(v4AddrObj, "Enable", json_object_new_boolean(true));
		replaceParam(v4AddrObj, "IPAddress", Jobj, "IPAddress");
		replaceParam(v4AddrObj, "SubnetMask", Jobj, "SubnetMask");
		//if((ret = zcfgFeObjJsonSetWithoutApply(oid, &v4AddrIid, obj, NULL)) != ZCFG_SUCCESS)
		//	printf("set oid:%d fail, line=%d, ret=%d\n", oid, __LINE__, ret);
		//json_object_put(obj);
	}

	/* static ipv6*/
	pramJobj=json_object_object_get(Jobj, "ip6Static");
	if(pramJobj)
		ip6Static = json_object_get_boolean(pramJobj);
	if(strcmp(ipMode, "IPv4") && ip6Static){
		oid = RDM_OID_ROUTING_ROUTER_V6_FWD;
		if(!getSpecificObj(oid, "Interface", json_type_string, "", &v6FwdIid, &v6FwdObj)){
			IID_INIT(v6FwdIid);
			v6FwdIid.level = 1;
			v6FwdIid.idx[0] = 1;
			zcfgFeObjJsonAdd(oid, &v6FwdIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &v6FwdIid, &v6FwdObj);
		}
		json_object_object_add(v6FwdObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v6FwdObj, "Interface", json_object_new_string(ipIfacePath));
		replaceParam(v6FwdObj, "NextHop", Jobj, "NextHop");
		//if((ret = zcfgFeObjJsonSetWithoutApply(oid, &v6FwdIid, v6FwdObj, NULL)) != ZCFG_SUCCESS)
		//	printf("set oid:%d fail, line=%d, ret=%d\n", oid, __LINE__, ret);
		//json_object_put(v6FwdObj);

		oid = RDM_OID_IP_IFACE_V6_ADDR;
		IID_INIT(v6AddrIid);
		v6AddrIid.level = 1;
		sscanf(ipIfacePath, "IP.Interface.%hhu", &v6AddrIid.idx[0]);
		zcfgFeObjJsonAdd(oid, &v6AddrIid, NULL);
		zcfgFeObjJsonGetWithoutUpdate(oid, &v6AddrIid, &v6AddrObj);
		json_object_object_add(v6AddrObj, "Enable", json_object_new_boolean(true));
		replaceParam(v6AddrObj, "IPAddress", Jobj, "IP6Address");
		//if((ret = zcfgFeObjJsonSetWithoutApply(oid, &v6AddrIid, v6AddrObj, NULL)) != ZCFG_SUCCESS)
		//	printf("set oid:%d fail, line=%d, ret=%d\n", oid, __LINE__, ret);
		//json_object_put(v6AddrObj);
	}

	return ret;
}

zcfgRet_t editStaticAddrSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	zcfg_offset_t oid;
	struct json_object *pramJobj = NULL;
	bool ipStatic = false, ip6Static = false;
	const char *IPAddress, *SubnetMask, *GatewayIPAddress;
	const char *CurrIPAddress, *CurrSubnetMask, *CurrGatewayIPAddress;
	const char *IP6Address, *NextHop;
	const char *CurrIP6Address, *CurrNextHop;

	pramJobj = json_object_object_get(Jobj, "ipStatic");
	if(pramJobj)
		ipStatic = json_object_get_boolean(pramJobj);
	else
		ipStatic = CurrIpStatic;

	pramJobj = json_object_object_get(Jobj, "ip6Static");
	if(pramJobj)
		ip6Static = json_object_get_boolean(pramJobj);
	else
		ip6Static = CurrIp6Static;

	printf("CurrIpStatic=%d ipStatic=%d\n", CurrIpStatic, ipStatic);
	printf("CurrIp6Static=%d ip6Static=%d\n", CurrIp6Static, ip6Static);

	if(CurrIpStatic){
		if(v4AddrObj == NULL){
			IID_INIT(v4AddrIid);
			v4AddrIid.level = 1;
			sscanf(ipIfacePath, "IP.Interface.%hhu", &v4AddrIid.idx[0]);
			zcfgFeObjJsonAdd(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, &v4AddrObj);
		}
		json_object_object_add(v4AddrObj, "AddressingType", json_object_new_string("Static"));
	}

	//static v4ip
	if(CurrIpStatic && ipStatic){ //enable to enable
		//v4 addr
		IPAddress = json_object_get_string(json_object_object_get(Jobj, "IPAddress"));
		SubnetMask = json_object_get_string(json_object_object_get(Jobj, "SubnetMask"));
		GatewayIPAddress = json_object_get_string(json_object_object_get(Jobj, "GatewayIPAddress"));
		if(GatewayIPAddress == NULL){GatewayIPAddress = "";}
		
		CurrIPAddress = json_object_get_string(json_object_object_get(v4AddrObj, "IPAddress"));
		CurrSubnetMask = json_object_get_string(json_object_object_get(v4AddrObj, "SubnetMask"));
		CurrGatewayIPAddress = json_object_get_string(json_object_object_get(v4FwdObj, "GatewayIPAddress"));
			
		if(strcmp(IPAddress, CurrIPAddress) || strcmp(SubnetMask, CurrSubnetMask)){
			json_object_object_add(v4AddrObj, "IPAddress", json_object_new_string(IPAddress));
			json_object_object_add(v4AddrObj, "SubnetMask", json_object_new_string(SubnetMask));
		}else{
			if(v4AddrObj) {zcfgFeJsonObjFree(v4AddrObj);}
		}

		//v4 fwd
		if(v4FwdObj){
			if(strcmp(GatewayIPAddress, CurrGatewayIPAddress)){
				json_object_object_add(v4FwdObj, "GatewayIPAddress", json_object_new_string(GatewayIPAddress));
			}
			else{
				if(v4FwdObj) {zcfgFeJsonObjFree(v4FwdObj);}
			}
		}
	}
	else if(CurrIpStatic && !ipStatic){ ////enable to disable
		//v4 addr, disable or delete or do nothing?
		json_object_object_add(v4AddrObj, "Enable", json_object_new_boolean(false));
		//v4 fwd
		json_object_object_add(v4FwdObj, "Interface", json_object_new_string(""));
	}
	else if(!CurrIpStatic && ipStatic){ //disable to enable
		if(v4AddrObj == NULL){
			oid = RDM_OID_IP_IFACE_V4_ADDR;
			IID_INIT(v4AddrIid);
			v4AddrIid.level = 1;
			sscanf(ipIfacePath, "IP.Interface.%hhu", &v4AddrIid.idx[0]);
			zcfgFeObjJsonAdd(oid, &v4AddrIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &v4AddrIid, &v4AddrObj);
		}
		json_object_object_add(v4AddrObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v4AddrObj, "AddressingType", json_object_new_string("Static"));
		replaceParam(v4AddrObj, "IPAddress", Jobj, "IPAddress");
		replaceParam(v4AddrObj, "SubnetMask", Jobj, "SubnetMask");


		if(v4FwdObj == NULL){
			oid = RDM_OID_ROUTING_ROUTER_V4_FWD;
			if(!getSpecificObj(oid, "Interface", json_type_string, "", &v4FwdIid, &v4FwdObj)){
				IID_INIT(v4FwdIid);
				v4FwdIid.level = 1;
				v4FwdIid.idx[0] = 1;
				zcfgFeObjJsonAdd(oid, &v4FwdIid, NULL);
				zcfgFeObjJsonGetWithoutUpdate(oid, &v4FwdIid, &v4FwdObj);
			}
		}
		json_object_object_add(v4FwdObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v4FwdObj, "Origin", json_object_new_string("Static"));
		json_object_object_add(v4FwdObj, "Interface", json_object_new_string(ipIfacePath));
		json_object_object_add(v4FwdObj, "DestIPAddress", json_object_new_string(""));
		json_object_object_add(v4FwdObj, "DestSubnetMask", json_object_new_string(""));
		replaceParam(v4FwdObj, "GatewayIPAddress", Jobj, "GatewayIPAddress");
	}
	else{//do nothing for disable to disable
		if(v4AddrObj) {zcfgFeJsonObjFree(v4AddrObj);}
		if(v4FwdObj) {zcfgFeJsonObjFree(v4FwdObj);}
	}

	//static v6ip
	if(CurrIp6Static && ip6Static){ //enable to enable
		//v6 addr
		IP6Address = json_object_get_string(json_object_object_get(Jobj, "IP6Address"));
		NextHop = json_object_get_string(json_object_object_get(Jobj, "NextHop"));
		CurrIP6Address = json_object_get_string(json_object_object_get(v6AddrObj, "IPAddress"));
		CurrNextHop = json_object_get_string(json_object_object_get(v6FwdObj, "NextHop"));
		
		if(strcmp(IP6Address, CurrIP6Address)){
			json_object_object_add(v6AddrObj, "IPAddress", json_object_new_string(IP6Address));
		}else{
			if(v6AddrObj) {zcfgFeJsonObjFree(v6AddrObj);}
		}

		//v6 fwd
		if(v6FwdObj){
			if(strcmp(NextHop, CurrNextHop)){
				json_object_object_add(v6FwdObj, "NextHop", json_object_new_string(NextHop));
			}
			else{
				if(v6FwdObj) {zcfgFeJsonObjFree(v6FwdObj);}
			}
		}
		
	}
	else if(CurrIp6Static && !ip6Static){ ////enable to disable
		//v4 addr, disable or delete or do nothing?
		json_object_object_add(v6AddrObj, "Enable", json_object_new_boolean(false));
		//v4 fwd
		json_object_object_add(v6FwdObj, "Interface", json_object_new_string(""));
	}
	else if(!CurrIp6Static && ip6Static){ //disable to enable
		if(v6AddrObj == NULL){
			oid = RDM_OID_IP_IFACE_V6_ADDR;
			IID_INIT(v6AddrIid);
			v6AddrIid.level = 1;
			sscanf(ipIfacePath, "IP.Interface.%hhu", &v6AddrIid.idx[0]);
			zcfgFeObjJsonAdd(oid, &v6AddrIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &v6AddrIid, &v6AddrObj);
		}
		json_object_object_add(v6AddrObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v6AddrObj, "Origin", json_object_new_string("Static"));
		replaceParam(v6AddrObj, "IPAddress", Jobj, "IP6Address");


		if(v6FwdObj == NULL){
			oid = RDM_OID_ROUTING_ROUTER_V6_FWD;
			if(!getSpecificObj(oid, "Interface", json_type_string, "", &v6FwdIid, &v6FwdObj)){
				IID_INIT(v6FwdIid);
				v6FwdIid.level = 1;
				v6FwdIid.idx[0] = 1;
				zcfgFeObjJsonAdd(oid, &v6FwdIid, NULL);
				zcfgFeObjJsonGetWithoutUpdate(oid, &v6FwdIid, &v6FwdObj);
			}
		}
		json_object_object_add(v6FwdObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v6FwdObj, "Origin", json_object_new_string("Static"));
		json_object_object_add(v6FwdObj, "Interface", json_object_new_string(ipIfacePath));
		json_object_object_add(v6FwdObj, "DestIPPrefix", json_object_new_string("::/0"));
		replaceParam(v6FwdObj, "NextHop", Jobj, "NextHop");
	}
	else{//do nothing for disable to disable
		if(v6AddrObj) {zcfgFeJsonObjFree(v6AddrObj);}
		if(v6FwdObj) {zcfgFeJsonObjFree(v6FwdObj);}
	}

	return ret;
}

zcfgRet_t getDhcpv4ClientOpt(objIndex_t *dhcpv4ClinetIid){
	zcfg_offset_t oid;
	objIndex_t iid;
	struct json_object *obj = NULL;
	int tag;
	
	IID_INIT(iid);
	oid = RDM_OID_DHCPV4_REQ_OPT;
	while(zcfgFeSubInObjJsonGetNextWithoutUpdate(oid, dhcpv4ClinetIid, &iid, &obj)== ZCFG_SUCCESS) {
		tag = json_object_get_int(json_object_object_get(obj, "Tag"));
		if(tag == 43){
			memcpy(&opt43Iid, &iid, sizeof(objIndex_t));
			opt43Obj = obj;
		}
		else if(tag == 120){
			memcpy(&opt120Iid, &iid, sizeof(objIndex_t));
			opt120Obj = obj;
		}
		else if(tag == 121){
			memcpy(&opt121Iid, &iid, sizeof(objIndex_t));
			opt121Obj = obj;
		}
		else if(tag == 212){
			memcpy(&opt212Iid, &iid, sizeof(objIndex_t));
			opt212Obj = obj;
		}
		else
			json_object_put(obj);
	}

	IID_INIT(iid);
	oid = RDM_OID_DHCPV4_SENT_OPT;
	while(zcfgFeSubInObjJsonGetNextWithoutUpdate(oid, dhcpv4ClinetIid, &iid, &obj)== ZCFG_SUCCESS) {
		tag = json_object_get_int(json_object_object_get(obj, "Tag"));
		if(tag == 60){
			memcpy(&opt60Iid, &iid, sizeof(objIndex_t));
			opt60Obj = obj;
		}
		else if(tag == 61){
			memcpy(&opt61Iid, &iid, sizeof(objIndex_t));
			opt61Obj = obj;
		}
		else if(tag == 125){
			memcpy(&opt125Iid, &iid, sizeof(objIndex_t));
			opt125Obj = obj;
		}
		else
			json_object_put(obj);
	}

	return ZCFG_SUCCESS;
}

zcfgRet_t setDhcpReqOption(struct json_object *Jobj, struct json_object **optObj, objIndex_t *optIid, objIndex_t *dhcpClientIid, int Tag, char *Alias){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//char optEnableName[32] = {0};
	zcfg_offset_t oid;
	//const char *ipMode, *v6RD_Type;
	//bool Enable_6RD, Enable = false;

	oid = RDM_OID_DHCPV4_REQ_OPT;
	
#if 0
	sprintf(optEnableName, "option%dEnable", Tag); //ex. option43Enable
	ipMode = json_object_get_string(json_object_object_get(Jobj, "ipMode"));
	Enable_6RD = json_object_get_boolean(json_object_object_get(Jobj, "Enable_6RD"));
	v6RD_Type = json_object_get_string(json_object_object_get(Jobj, "v6RD_Type"));

	if(Tag == 212){ //6RD
		if(!strcmp(ipMode, "IPv4") && Enable_6RD && !strcmp(v6RD_Type, "dhcp"))
			Enable = true;
	}else{
		Enable = json_object_get_boolean(json_object_object_get(Jobj, optEnableName));
	}
#endif

	if(*optObj){
		//if(Enable)
		json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
		//else
		//json_object_object_add(*optObj, "Enable", json_object_new_boolean(false));
		
		//zcfgFeObjJsonSetWithoutApply(oid, optIid, *optObj, NULL);
	}
	else{
		//if(Enable){
			memcpy(optIid, dhcpClientIid, sizeof(objIndex_t));
			zcfgFeObjJsonAdd(oid, optIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, optIid, optObj);
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Tag", json_object_new_int(Tag));
			json_object_object_add(*optObj, "Alias", json_object_new_string(Alias));
			//zcfgFeObjJsonSetWithoutApply(oid, optIid, *optObj, NULL);
		//}
	}

	return ret;
}

zcfgRet_t setDhcpSentOption(struct json_object *Jobj, struct json_object **optObj, objIndex_t *optIid, objIndex_t *dhcpClientIid, int Tag){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//char optEnableName[32] = {0};
	char optValueName[32] = {0};
	zcfg_offset_t oid;
	//bool Enable = false;
	
	oid = RDM_OID_DHCPV4_SENT_OPT;
	//sprintf(optEnableName, "option%dEnable", Tag); //ex. option60Enable
	sprintf(optValueName, "option%dValue", Tag); //ex. option60Value
	//Enable = json_object_get_boolean(json_object_object_get(Jobj, optEnableName));

	if(*optObj){
		json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
		replaceParam(*optObj, "Value", Jobj, optValueName);
		//zcfgFeObjJsonSetWithoutApply(oid, optIid, *optObj, NULL);
	}
	else{
		//if(Enable){
			memcpy(optIid, dhcpClientIid, sizeof(objIndex_t));
			zcfgFeObjJsonAdd(oid, optIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, optIid, optObj);
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Tag", json_object_new_int(Tag));
			replaceParam(*optObj, "Value", Jobj, optValueName);
			//zcfgFeObjJsonSetWithoutApply(oid, optIid, *optObj, NULL);
		//}
	}

	return ret;
}

zcfgRet_t addDhcpSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	zcfg_offset_t oid;
	objIndex_t iid;
	//objIndex_t v4ClientIid;
	//objIndex_t opt43Iid = {0}, opt120Iid = {0}, opt121Iid = {0}, opt212Iid = {0};
	//objIndex_t opt60Iid = {0}, opt61Iid = {0}, opt125Iid = {0};
	struct json_object *obj = NULL;
	//struct json_object *v4ClientObj = NULL;
	//struct json_object *opt43obj = NULL, *opt120obj = NULL, *opt121obj = NULL, *opt212obj = NULL;
	//struct json_object *opt60obj = NULL, *opt61obj = NULL, *opt125obj = NULL;
	//const char *Encapsulation, *ipMode;
	//bool ipStatic;
	bool option43Enable=false, option120Enable=false, option121Enable=false, option212Enable=false;
	bool option60Enable=false, option61Enable=false, option125Enable=false;
	int tag;

	if(!strcmp(Encapsulation, "PPPoA") || !strcmp(Encapsulation, "PPPoE"))
		return ret;

	option43Enable = json_object_get_boolean(json_object_object_get(Jobj, "option43Enable"));
	option120Enable = json_object_get_boolean(json_object_object_get(Jobj, "option120Enable"));
	option121Enable = json_object_get_boolean(json_object_object_get(Jobj, "option121Enable"));
	if(!strcmp(ipMode, "IPv4") && Enable_6RD && !strcmp(v6RD_Type, "dhcp"))
		option212Enable = json_object_get_boolean(json_object_object_get(Jobj, "option212Enable"));
	
	option60Enable = json_object_get_boolean(json_object_object_get(Jobj, "option60Enable"));
	option61Enable = json_object_get_boolean(json_object_object_get(Jobj, "option61Enable"));
	option125Enable = json_object_get_boolean(json_object_object_get(Jobj, "option125Enable"));
	
	if(strcmp(ipMode, "IPv6") && strcmp(Encapsulation, "IPoA") && !ipStatic){
		if(!getSpecificObj(RDM_OID_DHCPV4_CLIENT, "Interface", json_type_string, "", &v4ClientIid, &v4ClientObj)){
			IID_INIT(v4ClientIid);
			zcfgFeObjJsonAdd(RDM_OID_DHCPV4_CLIENT, &v4ClientIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(RDM_OID_DHCPV4_CLIENT, &v4ClientIid, &v4ClientObj);
		}

		//option 43, 120, 121, 212
		IID_INIT(iid);
		oid = RDM_OID_DHCPV4_REQ_OPT;
		while(zcfgFeSubInObjJsonGetNextWithoutUpdate(oid, &v4ClientIid, &iid, &obj)== ZCFG_SUCCESS) {
			tag = json_object_get_int(json_object_object_get(obj, "Tag"));
			if(tag == 43 && option43Enable){
				memcpy(&opt43Iid, &iid, sizeof(objIndex_t));
				opt43Obj = obj;
			}
			else if(tag == 120 && option120Enable){
				memcpy(&opt120Iid, &iid, sizeof(objIndex_t));
				opt120Obj = obj;
			}
			else if(tag == 121 && option121Enable){
				memcpy(&opt121Iid, &iid, sizeof(objIndex_t));
				opt121Obj = obj;
			}
			else if(tag == 212 && option212Enable){
				memcpy(&opt212Iid, &iid, sizeof(objIndex_t));
				opt212Obj = obj;
			}
			else
				json_object_put(obj);
		}

		if(option43Enable) setDhcpReqOption(Jobj, &opt43Obj, &opt43Iid, &v4ClientIid, 43, "acsinfo");
		if(option120Enable) setDhcpReqOption(Jobj, &opt120Obj, &opt120Iid, &v4ClientIid, 120, "sipsrv");
		if(option121Enable) setDhcpReqOption(Jobj, &opt121Obj, &opt121Iid, &v4ClientIid, 121, "sroute");
		if(option212Enable) setDhcpReqOption(Jobj, &opt212Obj, &opt212Iid, &v4ClientIid, 212, "");
		
		//if(opt43Obj) json_object_put(opt43Obj);
		//if(opt120Obj) json_object_put(opt120Obj);
		//if(opt121Obj) json_object_put(opt121Obj);
		//if(opt212Obj) json_object_put(opt212Obj);


		//option 60, 61, 125
		IID_INIT(iid);
		oid = RDM_OID_DHCPV4_SENT_OPT;
		while(zcfgFeSubInObjJsonGetNextWithoutUpdate(oid, &v4ClientIid, &iid, &obj)== ZCFG_SUCCESS) {
			tag = json_object_get_int(json_object_object_get(obj, "Tag"));
			if(tag == 60 && option60Enable){
				memcpy(&opt60Iid, &iid, sizeof(objIndex_t));
				opt60Obj = obj;
			}
			else if(tag == 61 && option61Enable){
				memcpy(&opt61Iid, &iid, sizeof(objIndex_t));
				opt61Obj = obj;
			}
			else if(tag == 125 && option125Enable){
				memcpy(&opt125Iid, &iid, sizeof(objIndex_t));
				opt125Obj = obj;
			}
			else
				json_object_put(obj);
		}

		if(option60Enable) setDhcpSentOption(Jobj, &opt60Obj, &opt60Iid, &v4ClientIid, 60);
		if(option61Enable) setDhcpSentOption(Jobj, &opt61Obj, &opt61Iid, &v4ClientIid, 61);
		if(option125Enable) setDhcpSentOption(Jobj, &opt125Obj, &opt125Iid, &v4ClientIid, 125);
		
		//if(opt60Obj) json_object_put(opt60Obj);
		//if(opt61Obj) json_object_put(opt61Obj);
		//if(opt125Obj) json_object_put(opt125Obj);

		//set DHCPv4 Client
		json_object_object_add(v4ClientObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v4ClientObj, "Interface", json_object_new_string(ipIfacePath));
		//ret = zcfgFeObjJsonSet(RDM_OID_DHCPV4_CLIENT, &v4ClientIid, v4ClientObj, NULL);
		//json_object_put(v4ClientObj);
	}

	return ret;
}


zcfgRet_t editDhcpReqOption(struct json_object *Jobj, struct json_object **optObj, objIndex_t *optIid, objIndex_t *dhcpClientIid, int Tag, char *Alias){
	zcfgRet_t ret = ZCFG_SUCCESS;
	char optEnableName[32] = {0};
	zcfg_offset_t oid;
	//const char *ipMode, *v6RD_Type;
	bool optEnable = false, CurrOptEnable = false;
	struct json_object *pramJobj = NULL;
	bool needSet = false;

	oid = RDM_OID_DHCPV4_REQ_OPT;

	if(*optObj){
		if(json_object_get_boolean(json_object_object_get(*optObj, "Enable")))
			CurrOptEnable = true;
	}
	
	sprintf(optEnableName, "option%dEnable", Tag); //ex. option43Enable
	pramJobj = json_object_object_get(Jobj, optEnableName);
	if(pramJobj)
		optEnable = json_object_get_boolean(pramJobj);
	else
		optEnable = CurrOptEnable;

	if(CurrOptEnable && !optEnable){ //enable to disable
		if(*optObj){
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(false));
			json_object_object_add(*optObj, "Value", json_object_new_string(""));
			needSet = true;
		}
	}
	else if(!CurrOptEnable && optEnable){ //disable to enable
		if(*optObj){
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Alias", json_object_new_string(Alias));
		}
		else{
			memcpy(optIid, dhcpClientIid, sizeof(objIndex_t));
			zcfgFeObjJsonAdd(oid, optIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, optIid, optObj);
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Tag", json_object_new_int(Tag));
			json_object_object_add(*optObj, "Alias", json_object_new_string(Alias));
		}
		needSet = true;
	}

	if(!needSet){
		if(*optObj) {zcfgFeJsonObjFree(*optObj);}
	}

	return ret;
}

zcfgRet_t editDhcpSentOption(struct json_object *Jobj, struct json_object **optObj, objIndex_t *optIid, objIndex_t *dhcpClientIid, int Tag){
	zcfgRet_t ret = ZCFG_SUCCESS;
	char optEnableName[32] = {0};
	char optValueName[32] = {0};
	zcfg_offset_t oid;
	//const char *ipMode, *v6RD_Type;
	bool optEnable = false, CurrOptEnable = false;
	const char *CurrValue = "", *Value = NULL;
	struct json_object *pramJobj = NULL;
	bool needSet = false;
	
	oid = RDM_OID_DHCPV4_SENT_OPT;
	
	if(*optObj){
		CurrOptEnable = json_object_get_boolean(json_object_object_get(*optObj, "Enable"));
		CurrValue = json_object_get_string(json_object_object_get(*optObj, "Value"));
		if(CurrValue == NULL)
			CurrValue = "";
	}
	
	sprintf(optEnableName, "option%dEnable", Tag); //ex. option60Enable
	pramJobj = json_object_object_get(Jobj, optEnableName);
	if(pramJobj)
		optEnable = json_object_get_boolean(pramJobj);
	else
		optEnable = CurrOptEnable;

	sprintf(optValueName, "option%dValue", Tag); //ex. option60Value
	pramJobj = json_object_object_get(Jobj, optValueName);
	if(pramJobj)
		Value = json_object_get_string(pramJobj);
	else
		Value = CurrValue;

	if(CurrOptEnable && optEnable){//enable to enable
		if(*optObj && strcmp(CurrValue, Value)){
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Value", json_object_new_string(Value));
			needSet = true;
		}
	}
	else if(CurrOptEnable && !optEnable){ //enable to disable
		if(*optObj){
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(false));
			json_object_object_add(*optObj, "Value", json_object_new_string(""));
			needSet = true;
		}
	}
	else if(!CurrOptEnable && optEnable){ //disable to enable
		if(*optObj){
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Value", json_object_new_string(Value));
		}
		else{
			memcpy(optIid, dhcpClientIid, sizeof(objIndex_t));
			zcfgFeObjJsonAdd(oid, optIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, optIid, optObj);
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Tag", json_object_new_int(Tag));
			json_object_object_add(*optObj, "Value", json_object_new_string(Value));

			memcpy(optIid, dhcpClientIid, sizeof(objIndex_t));
			zcfgFeObjJsonAdd(oid, optIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, optIid, optObj);
			json_object_object_add(*optObj, "Enable", json_object_new_boolean(true));
			json_object_object_add(*optObj, "Tag", json_object_new_int(Tag));
			replaceParam(*optObj, "Value", Jobj, optValueName);
		}
		needSet = true;
	}

	if(!needSet)
		if(*optObj) {zcfgFeJsonObjFree(*optObj);}

	return ret;
}

void editDhcpOption(struct json_object *Jobj, int action){

	if(action == dal_Delete){
		json_object_object_add(Jobj, "option43Enable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "option120Enable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "option121Enable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "option212Enable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "option60Enable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "option61Enable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "option125Enable", json_object_new_boolean(false));
	}

	editDhcpReqOption(Jobj, &opt43Obj, &opt43Iid, &v4ClientIid, 43, "acsinfo");
	editDhcpReqOption(Jobj, &opt120Obj, &opt120Iid, &v4ClientIid, 120, "sipsrv");
	editDhcpReqOption(Jobj, &opt121Obj, &opt121Iid, &v4ClientIid, 121, "sroute");
	editDhcpReqOption(Jobj, &opt212Obj, &opt212Iid, &v4ClientIid, 212, "");
	editDhcpSentOption(Jobj, &opt60Obj, &opt60Iid, &v4ClientIid, 60);
	editDhcpSentOption(Jobj, &opt61Obj, &opt61Iid, &v4ClientIid, 61);
	editDhcpSentOption(Jobj, &opt125Obj, &opt125Iid, &v4ClientIid, 125);
	
}

zcfgRet_t editDhcpSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	zcfg_offset_t oid;
	struct json_object *pramJobj = NULL;
	bool dhcpEnable = false;
	bool CrrrDhcpEnable = false;
	bool setObj = false;

	printf("editDhcpSetting\n");
	
	if(v4ClientObj != NULL) CrrrDhcpEnable = true;

	pramJobj = json_object_object_get(Jobj, "ipStatic");
	if(pramJobj)
		dhcpEnable = !json_object_get_boolean(pramJobj);
	else
		dhcpEnable = CrrrDhcpEnable;

	if(CrrrDhcpEnable && dhcpEnable){
		printf("enable to enable\n");
		editDhcpOption(Jobj, dal_Edit);
	}
	else if(CrrrDhcpEnable && !dhcpEnable){
		editDhcpOption(Jobj, dal_Delete);
		json_object_object_add(v4ClientObj, "Interface", json_object_new_string(""));
		setObj = true;
	}
	else if(!CrrrDhcpEnable && dhcpEnable){
		oid = RDM_OID_DHCPV4_CLIENT;
		if(!getSpecificObj(oid, "Interface", json_type_string, "", &v4ClientIid, &v4ClientObj)){
			IID_INIT(v4ClientIid);
			zcfgFeObjJsonAdd(oid, &v4ClientIid, NULL);
			zcfgFeObjJsonGetWithoutUpdate(oid, &v4ClientIid, &v4ClientObj);
		}
		json_object_object_add(v4ClientObj, "Enable", json_object_new_boolean(true));
		json_object_object_add(v4ClientObj, "Interface", json_object_new_string(ipIfacePath));
		setObj = true;
		
		getDhcpv4ClientOpt(&v4ClientIid);
		editDhcpOption(Jobj, dal_Add);
	}

	if(!setObj){
		if(v4ClientObj) {zcfgFeJsonObjFree(v4ClientObj);}
	}

	return ret;
}

zcfgRet_t editIgmpMldSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//objIndex_t iid;
	//struct json_object *obj = NULL;
	const char *Interface = NULL;
	char newInterface[320] = {0};
	struct json_object *pramJobj = NULL;
	bool igmpEnable = false, mldEnable = false;
	bool CurrIgmpEnable = false, CurrMldEnable = false;
	
	if(igmpObj == NULL){ //add case
		IID_INIT(igmpIid);
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ZY_IGMP, &igmpIid, &igmpObj);
	}
	if(mldObj == NULL){ //add case
		IID_INIT(mldIid);
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ZY_MLD, &mldIid, &mldObj);
	}
		
	Interface = json_object_get_string(json_object_object_get(igmpObj, "Interface"));
	if(strstr(Interface, ipIfacePath))
		CurrIgmpEnable = true;

	Interface = json_object_get_string(json_object_object_get(mldObj, "Interface"));
	if(strstr(Interface, ipIfacePath))
		CurrMldEnable = true;

	pramJobj = json_object_object_get(Jobj, "IGMPEnable");
	if(pramJobj)
		igmpEnable = json_object_get_boolean(pramJobj);
	else
		igmpEnable = CurrIgmpEnable;

	pramJobj = json_object_object_get(Jobj, "MLDEnable");
	if(pramJobj)
		mldEnable = json_object_get_boolean(pramJobj);
	else
		mldEnable = CurrMldEnable;
	

	/* IGMP */
	Interface = json_object_get_string(json_object_object_get(igmpObj, "Interface"));
	if(CurrIgmpEnable && igmpEnable){ //enable to enable
		if(igmpObj) {zcfgFeJsonObjFree(igmpObj);}
	}
	else if(CurrIgmpEnable && !igmpEnable){ ////enable to disable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, false)){
			json_object_object_add(igmpObj, "Interface", json_object_new_string(newInterface));
		}
		else{
			if(igmpObj) {zcfgFeJsonObjFree(igmpObj);}
		}
	}
	else if(!CurrIgmpEnable && igmpEnable){ //disable to enable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, true)){
			json_object_object_add(igmpObj, "Interface", json_object_new_string(newInterface));
		}
		else{
			if(igmpObj) {zcfgFeJsonObjFree(igmpObj);}
		}
	}
	else{//do nothing for disable to disable
		if(igmpObj) {zcfgFeJsonObjFree(igmpObj);}
	}


	/* MLD */
	Interface = json_object_get_string(json_object_object_get(mldObj, "Interface"));
	if(CurrMldEnable && mldEnable){ //enable to enable
		if(mldObj) {zcfgFeJsonObjFree(mldObj);}
	}
	else if(CurrMldEnable && !mldEnable){ ////enable to disable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, false)){
			json_object_object_add(mldObj, "Interface", json_object_new_string(newInterface));
		}
		else{
			if(mldObj) {zcfgFeJsonObjFree(mldObj);}
		}
	}
	else if(!CurrMldEnable && mldEnable){ //disable to enable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, true)){
			json_object_object_add(mldObj, "Interface", json_object_new_string(newInterface));
		}
		else{
			if(mldObj) {zcfgFeJsonObjFree(mldObj);}
		}
	}
	else{//do nothing for disable to disable
		if(mldObj) {zcfgFeJsonObjFree(mldObj);}
	}

	return ret;
}

zcfgRet_t editDefaultGwSetting(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//objIndex_t iid;
	//struct json_object *obj = NULL;
	const char *Interface = NULL;
	char newInterface[320] = {0};
	struct json_object *pramJobj = NULL;
	bool v4GwEnable = false, v6GwEnable = false;
	bool CurrV4GwEnable = false, CurrV6GwEnable = false;
	bool needSet = false;
	
	if(routerObj == NULL){ //add case
		IID_INIT(routerIid);
		routerIid.level = 1;
		routerIid.idx[0] = 1;
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ROUTING_ROUTER, &routerIid, &routerObj);
	}
		
	Interface = json_object_get_string(json_object_object_get(routerObj, "X_ZYXEL_ActiveDefaultGateway"));
	if(strstr(Interface, ipIfacePath))
		CurrV4GwEnable = true;

	Interface = json_object_get_string(json_object_object_get(routerObj, "X_ZYXEL_ActiveV6DefaultGateway"));
	if(strstr(Interface, ipIfacePath))
		CurrV6GwEnable = true;

	pramJobj = json_object_object_get(Jobj, "sysGwEnable");
	if(pramJobj)
		v4GwEnable = json_object_get_boolean(pramJobj);
	else
		v4GwEnable = CurrV4GwEnable;

	pramJobj = json_object_object_get(Jobj, "sysGw6Enable");
	if(pramJobj)
		v6GwEnable = json_object_get_boolean(pramJobj);
	else
		v6GwEnable = CurrV6GwEnable;

	printf("CurrV4GwEnable=%d v4GwEnable=%d\n", CurrV4GwEnable, v4GwEnable);
	printf("CurrV6GwEnable=%d v6GwEnable=%d\n", CurrV6GwEnable, v6GwEnable);

	Interface = json_object_get_string(json_object_object_get(routerObj, "X_ZYXEL_ActiveDefaultGateway"));
	if(CurrV4GwEnable && !v4GwEnable){ ////enable to disable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, false)){
			json_object_object_add(routerObj, "X_ZYXEL_ActiveDefaultGateway", json_object_new_string(newInterface));
			needSet = true;
		}
	}
	else if(!CurrV4GwEnable && v4GwEnable){ //disable to enable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, true)){
			json_object_object_add(routerObj, "X_ZYXEL_ActiveDefaultGateway", json_object_new_string(newInterface));
			needSet = true;
		}
	}

	Interface = json_object_get_string(json_object_object_get(routerObj, "X_ZYXEL_ActiveV6DefaultGateway"));
	if(CurrV6GwEnable && !v6GwEnable){ ////enable to disable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, false)){
			json_object_object_add(routerObj, "X_ZYXEL_ActiveV6DefaultGateway", json_object_new_string(newInterface));
			needSet = true;
		}
	}
	else if(!CurrV6GwEnable && v6GwEnable){ //disable to enable
		if(genNewInterface(",", newInterface, Interface, ipIfacePath, true)){
			json_object_object_add(routerObj, "X_ZYXEL_ActiveV6DefaultGateway", json_object_new_string(newInterface));
			needSet = true;
		}
	}

	if(!needSet){
		if(routerObj) {zcfgFeJsonObjFree(routerObj);}
	}

	return ret;
}


zcfgRet_t editPppIfaceObject(struct json_object *Jobj, struct json_object *ipIfaceObj, objIndex_t *ipIfaceIid){
	zcfgRet_t ret = ZCFG_SUCCESS;

	if(isAdd || pppIfaceObj == NULL){ //add case
		IID_INIT(pppIfaceIid);
		if((ret = zcfgFeObjJsonAdd(RDM_OID_PPP_IFACE, &pppIfaceIid, NULL)) != ZCFG_SUCCESS)
			return ret;
		if((ret = zcfgFeObjJsonGetWithoutUpdate(RDM_OID_PPP_IFACE, &pppIfaceIid, &pppIfaceObj)) != ZCFG_SUCCESS)
			return ret;
	}
	
	//set ppp obj defalult values
	json_object_object_add(pppIfaceObj, "Enable", json_object_new_boolean(true));
	json_object_object_add(pppIfaceObj, "X_ZYXEL_ConnectionId", json_object_new_int(ipIfaceIid->idx[0] - 1));
	json_object_object_add(pppIfaceObj, "X_ZYXEL_IPR2_MARKING", json_object_new_int(ipIfaceIid->idx[0] - 1));
	json_object_object_add(pppIfaceObj, "MaxMRUSize", json_object_new_int(1492));
	json_object_object_add(pppIfaceObj, "LowerLayers", json_object_new_string(currLowerLayers));

	// need to set ipIface object first
	sprintf(currLowerLayers, "PPP.Interface.%u", pppIfaceIid.idx[0]);
	json_object_object_add(ipIfaceObj, "LowerLayers", json_object_new_string(currLowerLayers));
	
	sprintf(currLowerLayers, "IP.Interface.%u", ipIfaceIid->idx[0]);
	
	//set ppp parameter
	replaceParam(pppIfaceObj, "Username", Jobj, "pppUsername");
	replaceParam(pppIfaceObj, "Password", Jobj, "pppPassword");
	replaceParam(pppIfaceObj, "MaxMRUSize", Jobj, "MaxMTUSize");
	replaceParam(pppIfaceObj, "ConnectionTrigger", Jobj, "ConnectionTrigger");
	replaceParam(pppIfaceObj, "IdleDisconnectTime", Jobj, "IdleDisconnectTime");
	if(json_object_get_boolean(json_object_object_get(Jobj, "pppoePassThrough")) == true)
		json_object_object_add(pppIfaceObj, "X_ZYXEL_ConnectionType", json_object_new_string("PPPoE_Bridged"));
	else
		json_object_object_add(pppIfaceObj, "X_ZYXEL_ConnectionType", json_object_new_string("IP_Routed"));
	
	if(json_object_get_boolean(json_object_object_get(Jobj, "ipStatic")))
		replaceParam(pppIfaceObj, "X_ZYXEL_LocalIPAddress", Jobj, "IPAddress");
	else
		json_object_object_add(pppIfaceObj, "X_ZYXEL_ConnectionType", json_object_new_string("0.0.0.0"));

	if(strcmp(ipMode, "IPv4")){
		json_object_object_add(pppIfaceObj, "IPv6CPEnable", json_object_new_boolean(true));
	}
	if(strcmp(ipMode, "IPv6")){
		json_object_object_add(pppIfaceObj, "IPCPEnable", json_object_new_boolean(true));
	}

	return ret;
}

zcfgRet_t addLayer3Objects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	//objIndex_t ipIfaceIid;
	//struct json_object *ipIfaceObj = NULL;
	//const char *Name, *Mode, *Encapsulation, *ipMode;
	//objIndex_t dnsIid;
	//struct json_object *dnsObj = NULL;

	printf("line:%d\n", __LINE__);

	IID_INIT(ipIfaceIid);
	if((ret = zcfgFeObjJsonAdd(RDM_OID_IP_IFACE, &ipIfaceIid, NULL)) != ZCFG_SUCCESS)
		return ret;
	if((ret = zcfgFeObjJsonGetWithoutUpdate(RDM_OID_IP_IFACE, &ipIfaceIid, &ipIfaceObj)) != ZCFG_SUCCESS)
		return ret;

	printf("line:%d\n", __LINE__);

	//Name = json_object_get_string(json_object_object_get(Jobj, "Name"));
	//Mode = json_object_get_string(json_object_object_get(Jobj, "Mode"));

	//set defalult values
	json_object_object_add(ipIfaceObj, "Enable", json_object_new_boolean(true));//set to false here, trigger to true after WAN add comlete
	json_object_object_add(ipIfaceObj, "X_ZYXEL_ConnectionId", json_object_new_int(ipIfaceIid.idx[0] - 1));
	json_object_object_add(ipIfaceObj, "X_ZYXEL_IPR2_MARKING", json_object_new_int(ipIfaceIid.idx[0] - 1));

	//set Name and Mode
	json_object_object_add(ipIfaceObj, "X_ZYXEL_SrvName", json_object_new_string(Name));
	json_object_object_add(ipIfaceObj, "X_ZYXEL_ConnectionType", json_object_new_string(Mode));

	printf("line:%d\n", __LINE__);

	if(!strcmp(Mode, "IP_Bridged")){
		json_object_object_add(ipIfaceObj, "LowerLayers", json_object_new_string(currLowerLayers));
		//ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIfaceIid, ipIfaceObj, NULL);
		//json_object_put(ipIfaceObj);
		return ret;
	}
	printf("line:%d\n", __LINE__);
	sprintf(ipIfacePath, "IP.Interface.%u", ipIfaceIid.idx[0]);

	//routting mode, need to set Nat and Static DNS before set IP and PPP.
	editNatSetting(Jobj);
	editDnsSetting(Jobj);
	
	printf("line:%d\n", __LINE__);
	if(!strcmp(ipMode, "IPv4")){
		json_object_object_add(ipIfaceObj, "IPv4Enable", json_object_new_boolean(true));
		replaceParam(ipIfaceObj, "X_ZYXEL_Enable_6RD", Jobj, "Enable_6RD");
		replaceParam(ipIfaceObj, "X_ZYXEL_6RD_Type", Jobj, "v6RD_Type");
		replaceParam(ipIfaceObj, "X_ZYXEL_SPIPv6Prefix", Jobj, "SPIPv6Prefix");
		replaceParam(ipIfaceObj, "X_ZYXEL_IPv4MaskLength", Jobj, "IPv4MaskLength");
		replaceParam(ipIfaceObj, "X_ZYXEL_BorderRelayIPv4Addresses", Jobj, "BorderRelayIPv4Addresses");
	}
	if(!strcmp(ipMode, "IPv6")){
		json_object_object_add(ipIfaceObj, "IPv6Enable", json_object_new_boolean(true));
		replaceParam(ipIfaceObj, "X_ZYXEL_Enable_DSLite", Jobj, "DSLiteEnable");
		replaceParam(ipIfaceObj, "X_ZYXEL_DSLite_Type", Jobj, "DSLiteType");
		replaceParam(ipIfaceObj, "X_ZYXEL_DSLiteRelayIPv6Addresses", Jobj, "DSLiteRelayIPv6Addresses");
	}
	else if(!strcmp(ipMode, "DualStack")){
		json_object_object_add(ipIfaceObj, "IPv4Enable", json_object_new_boolean(true));
		json_object_object_add(ipIfaceObj, "IPv6Enable", json_object_new_boolean(true));
	}

	if(!strcmp(Encapsulation, "PPPoE") || !strcmp(Encapsulation, "PPPoA")){
		ret = editPppIfaceObject(Jobj, ipIfaceObj, &ipIfaceIid);
	}
	else{
		replaceParam(ipIfaceObj, "MaxMTUSize", Jobj, "MaxMTUSize");
		json_object_object_add(ipIfaceObj, "LowerLayers", json_object_new_string(currLowerLayers));
		//ret = zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIfaceIid, ipIfaceObj, NULL);
		printf("line:%d\n", __LINE__);
		sprintf(currLowerLayers, "IP.Interface.%u", ipIfaceIid.idx[0]);
		addStaticAddrSetting(Jobj);
		addDhcpSetting(Jobj);
    	printf("line=%d\n", __LINE__);
	}
	//json_object_put(ipIfaceObj);

	editIgmpMldSetting(Jobj);
	editDefaultGwSetting(Jobj);
	
	IID_INIT(dnsIid);
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_DNS, &dnsIid, &dnsObj);
	//ret = zcfgFeObjJsonSet(RDM_OID_DNS, &dnsIid, dnsObj, NULL);
	//json_object_put(dnsObj);

	printf("line=%d\n", __LINE__);
	
	return ret;
}

zcfgRet_t editLayer3Objects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;

	printf("line:%d\n", __LINE__);

	if(isAdd){
		IID_INIT(ipIfaceIid);
		if((ret = zcfgFeObjJsonAdd(RDM_OID_IP_IFACE, &ipIfaceIid, NULL)) != ZCFG_SUCCESS)
			return ret;
		if((ret = zcfgFeObjJsonGetWithoutUpdate(RDM_OID_IP_IFACE, &ipIfaceIid, &ipIfaceObj)) != ZCFG_SUCCESS)
			return ret;

		sprintf(ipIfacePath, "IP.Interface.%u", ipIfaceIid.idx[0]);

		IID_INIT(dnsIid);
		zcfgFeObjJsonGetWithoutUpdate(RDM_OID_DNS, &dnsIid, &dnsObj);
	}

	printf("line:%d\n", __LINE__);

	json_object_object_add(ipIfaceObj, "Enable", json_object_new_boolean(true));
	json_object_object_add(ipIfaceObj, "X_ZYXEL_ConnectionId", json_object_new_int(ipIfaceIid.idx[0] - 1));
	json_object_object_add(ipIfaceObj, "X_ZYXEL_IPR2_MARKING", json_object_new_int(ipIfaceIid.idx[0] - 1));
	
	json_object_object_add(ipIfaceObj, "X_ZYXEL_SrvName", json_object_new_string(Name));
	json_object_object_add(ipIfaceObj, "X_ZYXEL_ConnectionType", json_object_new_string(Mode));

	printf("line:%d\n", __LINE__);

	if(!strcmp(Mode, "IP_Bridged")){
		json_object_object_add(ipIfaceObj, "LowerLayers", json_object_new_string(currLowerLayers));
		return ret;
	}
	
	printf("line:%d\n", __LINE__);
	if(!strcmp(ipMode, "IPv4")){
		json_object_object_add(ipIfaceObj, "IPv4Enable", json_object_new_boolean(true));
		json_object_object_add(ipIfaceObj, "IPv6Enable", json_object_new_boolean(false));
		replaceParam(ipIfaceObj, "X_ZYXEL_Enable_6RD", Jobj, "Enable_6RD");
		replaceParam(ipIfaceObj, "X_ZYXEL_6RD_Type", Jobj, "v6RD_Type");
		replaceParam(ipIfaceObj, "X_ZYXEL_SPIPv6Prefix", Jobj, "SPIPv6Prefix");
		replaceParam(ipIfaceObj, "X_ZYXEL_IPv4MaskLength", Jobj, "IPv4MaskLength");
		replaceParam(ipIfaceObj, "X_ZYXEL_BorderRelayIPv4Addresses", Jobj, "BorderRelayIPv4Addresses");
		json_object_object_add(ipIfaceObj, "X_ZYXEL_Enable_DSLite", json_object_new_boolean(false));
	}
	if(!strcmp(ipMode, "IPv6")){
		json_object_object_add(ipIfaceObj, "IPv4Enable", json_object_new_boolean(false));
		json_object_object_add(ipIfaceObj, "IPv6Enable", json_object_new_boolean(true));
		replaceParam(ipIfaceObj, "X_ZYXEL_Enable_DSLite", Jobj, "DSLiteEnable");
		replaceParam(ipIfaceObj, "X_ZYXEL_DSLite_Type", Jobj, "DSLiteType");
		replaceParam(ipIfaceObj, "X_ZYXEL_DSLiteRelayIPv6Addresses", Jobj, "DSLiteRelayIPv6Addresses");
		json_object_object_add(ipIfaceObj, "X_ZYXEL_Enable_6RD", json_object_new_boolean(false));
	}
	else if(!strcmp(ipMode, "DualStack")){
		json_object_object_add(ipIfaceObj, "IPv4Enable", json_object_new_boolean(true));
		json_object_object_add(ipIfaceObj, "IPv6Enable", json_object_new_boolean(true));
		json_object_object_add(ipIfaceObj, "X_ZYXEL_Enable_6RD", json_object_new_boolean(false));
		json_object_object_add(ipIfaceObj, "X_ZYXEL_Enable_DSLite", json_object_new_boolean(false));
	}

	if(!strcmp(Encapsulation, "PPPoE") || !strcmp(Encapsulation, "PPPoA")){
		ret = editPppIfaceObject(Jobj, ipIfaceObj, &ipIfaceIid);
	}
	else{
		json_object_object_add(ipIfaceObj, "MaxMTUSize", json_object_new_int(1500));
		replaceParam(ipIfaceObj, "MaxMTUSize", Jobj, "MaxMTUSize");
		json_object_object_add(ipIfaceObj, "LowerLayers", json_object_new_string(currLowerLayers));
		sprintf(currLowerLayers, "IP.Interface.%u", ipIfaceIid.idx[0]);
	}

   	printf("line=%d\n", __LINE__);

	editNatSetting(Jobj);
	editDnsSetting(Jobj);
	editStaticAddrSetting(Jobj);
	editDhcpSetting(Jobj);
	editIgmpMldSetting(Jobj);
	editDefaultGwSetting(Jobj);

	printf("line=%d\n", __LINE__);
	
	return ret;
}

zcfgRet_t setAllObjects(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	
	if(atmLinkQosObj) zcfgFeObjJsonSet(RDM_OID_ATM_LINK_QOS, &atmLinkQosIid, atmLinkQosObj, NULL);
	if(atmLinkObj)zcfgFeObjJsonSet(RDM_OID_ATM_LINK, &atmLinkIid, atmLinkObj, NULL);
	if(ptmLinkObj)zcfgFeObjJsonSet(RDM_OID_PTM_LINK, &ptmLinkIid, ptmLinkObj, NULL);
	if(ethLinkObj)zcfgFeObjJsonSet(RDM_OID_ETH_LINK, &ethLinkIid, ethLinkObj, NULL);
	if(vlanTermObj)zcfgFeObjJsonSet(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, vlanTermObj, NULL);
	if(!strcmp(Mode, "IP_Bridged")){
		printf("IP_Bridged\n");
		if(ipIfaceObj)zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIfaceIid, ipIfaceObj, NULL);
#if 0
		if(!isAdd && !strcmp(CurrMode, "IP_Routed")){ //route to bridge case , need to restart or reload service?
			if(igmpObj)zcfgFeObjJsonSet(RDM_OID_ZY_IGMP, &igmpIid, igmpObj, NULL);
			if(mldObj)zcfgFeObjJsonSet(RDM_OID_ZY_MLD, &mldIid, mldObj, NULL);
			if(dnsObj)zcfgFeObjJsonSet(RDM_OID_DNS, &dnsIid, dnsObj, NULL);
		}
#endif
		return ret;
	}
	
	if(natIntfObj)zcfgFeObjJsonSetWithoutApply(RDM_OID_NAT_INTF_SETTING, &natIntfIid, natIntfObj, NULL);
	if(ripObj)zcfgFeObjJsonSetWithoutApply(RDM_OID_ROUTING_RIP_INTF_SET, &ripIid, ripObj, NULL);
	if(dnsClientSrv4Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DNS_CLIENT_SRV, &dnsClientSrv4Iid, dnsClientSrv4Obj, NULL);
	if(dnsClientSrv6Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DNS_CLIENT_SRV, &dnsClientSrv6Iid, dnsClientSrv6Obj, NULL);
	if(ipIfaceObj)zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIfaceIid, ipIfaceObj, NULL);
	if(pppIfaceObj)zcfgFeObjJsonSet(RDM_OID_PPP_IFACE, &pppIfaceIid, pppIfaceObj, NULL);
	if(v4FwdObj)zcfgFeObjJsonSetWithoutApply(RDM_OID_ROUTING_ROUTER_V4_FWD, &v4FwdIid, v4FwdObj, NULL);
	if(v4AddrObj)zcfgFeObjJsonSetWithoutApply(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, v4AddrObj, NULL);
	if(v6FwdObj)zcfgFeObjJsonSetWithoutApply(RDM_OID_ROUTING_ROUTER_V6_FWD, &v6FwdIid, v6FwdObj, NULL);
	if(v6AddrObj)zcfgFeObjJsonSetWithoutApply(RDM_OID_IP_IFACE_V6_ADDR, &v6AddrIid, v6AddrObj, NULL);
	if(opt43Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_REQ_OPT, &opt43Iid, opt43Obj, NULL);
	if(opt120Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_REQ_OPT, &opt120Iid, opt120Obj, NULL);
	if(opt121Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_REQ_OPT, &opt121Iid, opt121Obj, NULL);
	if(opt212Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_REQ_OPT, &opt212Iid, opt212Obj, NULL);
	if(opt60Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_SENT_OPT, &opt60Iid, opt60Obj, NULL);
	if(opt61Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_SENT_OPT, &opt61Iid, opt61Obj, NULL);
	if(opt125Obj)zcfgFeObjJsonSetWithoutApply(RDM_OID_DHCPV4_SENT_OPT, &opt125Iid, opt125Obj, NULL);
	if(v4ClientObj)zcfgFeObjJsonSet(RDM_OID_DHCPV4_CLIENT, &v4ClientIid, v4ClientObj, NULL);
	if(igmpObj)zcfgFeObjJsonSet(RDM_OID_ZY_IGMP, &igmpIid, igmpObj, NULL);
	if(mldObj)zcfgFeObjJsonSet(RDM_OID_ZY_MLD, &mldIid, mldObj, NULL);
	if(routerObj)zcfgFeObjJsonSet(RDM_OID_ROUTING_ROUTER, &routerIid, routerObj, NULL);
	if(dnsObj)zcfgFeObjJsonSet(RDM_OID_DNS, &dnsIid, dnsObj, NULL);
	
	return ret;
}

zcfgRet_t freeAllObjects(){
	zcfgRet_t ret = ZCFG_SUCCESS;

	if(atmLinkQosObj) json_object_put(atmLinkQosObj);
	if(atmLinkObj) json_object_put(atmLinkObj);
	if(ptmLinkObj) json_object_put(ptmLinkObj);
	if(ethLinkObj) json_object_put(ethLinkObj);
	if(vlanTermObj) json_object_put(vlanTermObj);
	if(pppIfaceObj) json_object_put(pppIfaceObj);
	if(ipIfaceObj) json_object_put(ipIfaceObj);
	if(natIntfObj) json_object_put(natIntfObj);
	if(ripObj) json_object_put(ripObj);
	if(dnsClientSrv4Obj) json_object_put(dnsClientSrv4Obj);
	if(dnsClientSrv6Obj) json_object_put(dnsClientSrv6Obj);
	if(v4FwdObj) json_object_put(v4FwdObj);
	if(v4AddrObj) json_object_put(v4AddrObj);
	if(v6FwdObj) json_object_put(v6FwdObj);
	if(v6AddrObj) json_object_put(v6AddrObj);
	if(opt43Obj) json_object_put(opt43Obj);
	if(opt120Obj) json_object_put(opt120Obj);
	if(opt121Obj) json_object_put(opt121Obj);
	if(opt212Obj) json_object_put(opt212Obj);
	if(opt60Obj) json_object_put(opt60Obj);
	if(opt61Obj) json_object_put(opt61Obj);
	if(opt125Obj) json_object_put(opt125Obj);
	if(v4ClientObj) json_object_put(v4ClientObj);
	if(igmpObj) json_object_put(igmpObj);
	if(mldObj) json_object_put(mldObj);
	if(routerObj) json_object_put(routerObj);
	if(dnsObj) json_object_put(dnsObj);
	if(ethIfaceObj) json_object_put(ethIfaceObj);
	if(dynamicDnsClientSrv4Obj) json_object_put(dynamicDnsClientSrv4Obj);
	if(dynamicDnsClientSrv6Obj) json_object_put(dynamicDnsClientSrv6Obj);
	
	return ret;
}


void getBasicInfo(struct json_object *Jobj){
	Name = json_object_get_string(json_object_object_get(Jobj, "Name"));
	Type = json_object_get_string(json_object_object_get(Jobj, "Type"));
	Mode = json_object_get_string(json_object_object_get(Jobj, "Mode"));
	Encapsulation = json_object_get_string(json_object_object_get(Jobj, "Encapsulation"));
	ipMode = json_object_get_string(json_object_object_get(Jobj, "ipMode"));
	ipStatic = json_object_get_boolean(json_object_object_get(Jobj, "ipStatic"));
	ip6Static = json_object_get_boolean(json_object_object_get(Jobj, "ip6Static"));
	Enable_6RD = json_object_get_boolean(json_object_object_get(Jobj, "Enable_6RD"));
	v6RD_Type = json_object_get_string(json_object_object_get(Jobj, "v6RD_Type"));
}

void initGlobalObjects(){
	
	atmLinkObj = NULL;
	atmLinkQosObj = NULL;
	ptmLinkObj = NULL;
	ethIfaceObj = NULL;
	ethLinkObj = NULL;
	vlanTermObj = NULL;
	pppIfaceObj = NULL;
	ipIfaceObj = NULL;
	v4ClientObj = NULL;
	opt43Obj = NULL;
	opt120Obj = NULL;
	opt121Obj = NULL;
	opt212Obj = NULL;
	opt60Obj = NULL;
	opt61Obj = NULL;
	opt125Obj = NULL;
	igmpObj = NULL;
	mldObj = NULL;
	natIntfObj = NULL;
	ripObj = NULL;
	dnsClientSrv4Obj = NULL;
	dnsClientSrv6Obj = NULL;
	dynamicDnsClientSrv4Obj = NULL;
	dynamicDnsClientSrv6Obj = NULL;
	routerObj = NULL;
	v4FwdObj = NULL;
	v6FwdObj = NULL;
	//dynamicV4FwdObj = NULL;
	//dynamicV6FwdObj = NULL;
	v4AddrObj = NULL;
	v6AddrObj = NULL;
	dnsObj = NULL;

	IID_INIT(atmLinkIid);
	IID_INIT(atmLinkQosIid);
	IID_INIT(ptmLinkIid);
	IID_INIT(ethIfaceIid);
	IID_INIT(ethLinkIid);
	IID_INIT(vlanTermIid);
	IID_INIT(pppIfaceIid);
	IID_INIT(ipIfaceIid);
	IID_INIT(v4ClientIid);
	IID_INIT(opt43Iid);
	IID_INIT(opt120Iid);
	IID_INIT(opt121Iid);
	IID_INIT(opt212Iid);
	IID_INIT(opt60Iid);
	IID_INIT(opt61Iid);
	IID_INIT(opt125Iid);
	IID_INIT(igmpIid);
	IID_INIT(mldIid);
	IID_INIT(natIntfIid);
	IID_INIT(ripIid);
	IID_INIT(dnsClientSrv4Iid);
	IID_INIT(dnsClientSrv6Iid);
	IID_INIT(dynamicDnsClientSrv4Iid);
	IID_INIT(dynamicDnsClientSrv6Iid);
	IID_INIT(routerIid);
	IID_INIT(v4FwdIid);
	IID_INIT(v6FwdIid);
	IID_INIT(v4AddrIid);
	IID_INIT(v6AddrIid);
	IID_INIT(dnsIid);
	
}

zcfgRet_t getCurrentConfig(struct json_object *Jobj){
	zcfgRet_t ret = ZCFG_SUCCESS;
	const char *HigherLayer;
	const char *LowerLayer;
	struct json_object *obj = NULL;
	struct json_object *pramJobj = NULL;
	objIndex_t iid;
	int count = 0;
	bool v4enable, v6enable, Enable;
	const char *Interface;
	const char *AddressingType;
	const char *DestIPAddress;
	const char *DestSubnetMask;
	const char *Origin;
	const char *DestIPPrefix;
	const char *DNSServer;
	const char * X_ZYXEL_Type;

	//check if target WAN exist
	if(!getSpecificObj(RDM_OID_IP_IFACE, "X_ZYXEL_SrvName", json_type_string, Name, &ipIfaceIid, &ipIfaceObj))
		return ZCFG_REQUEST_REJECT;
	
	sprintf(ipIfacePath, "IP.Interface.%u", ipIfaceIid.idx[0]);
	LowerLayer = json_object_get_string(json_object_object_get(ipIfaceObj, "LowerLayers"));
	strcpy(CurrMode, json_object_get_string(json_object_object_get(ipIfaceObj, "X_ZYXEL_ConnectionType")));

	HigherLayer = "IP.Interface.";
	while(count < 4){
		printf("count=%d\n", count);
		printf("HigherLayer=%s\n", HigherLayer);
		printf("LowerLayer=%s\n", LowerLayer);
		
		count++;
		if(!strncmp(HigherLayer, "IP.Interface.", 13)){
			if(!strncmp(LowerLayer, "PPP.Interface.", 14)){
				pppIfaceIid.level = 1;
				sscanf(LowerLayer, "PPP.Interface.%hhu", &pppIfaceIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_PPP_IFACE, &pppIfaceIid, &pppIfaceObj);
				HigherLayer = LowerLayer;
				LowerLayer = json_object_get_string(json_object_object_get(pppIfaceObj, "LowerLayers"));
			}
			else if(!strncmp("Ethernet.VLANTermination.", LowerLayer, 25)){
				vlanTermIid.level = 1;
				sscanf(LowerLayer, "Ethernet.VLANTermination.%hhu", &vlanTermIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, &vlanTermObj);
				HigherLayer = LowerLayer;
				LowerLayer = json_object_get_string(json_object_object_get(vlanTermObj, "LowerLayers"));
				strcpy(CurrEncapsulation, "IPoE");
			}
			else if(!strncmp("ATM.Link.", LowerLayer, 9) && !strcmp("IP_Routed", CurrMode)){
				atmLinkIid.level = 1;
				sscanf(LowerLayer, "ATM.Link.%hhu", &atmLinkIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK, &atmLinkIid, &atmLinkObj);
				strcpy(CurrEncapsulation, "IPoA");
				memcpy(&atmLinkQosIid, &atmLinkIid, sizeof(objIndex_t));
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK_QOS, &atmLinkQosIid, &atmLinkQosObj);
				break;
			}
			else{
				return ZCFG_REQUEST_REJECT;
				//break;
			}
		}
		else if(!strncmp(HigherLayer, "PPP.Interface.", 14)){
			if(!strncmp("Ethernet.VLANTermination.", LowerLayer, 25)){
				vlanTermIid.level = 1;
				sscanf(LowerLayer, "Ethernet.VLANTermination.%hhu", &vlanTermIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, &vlanTermObj);
				HigherLayer = LowerLayer;
				LowerLayer = json_object_get_string(json_object_object_get(vlanTermObj, "LowerLayers"));
				strcpy(CurrEncapsulation, "PPPoE");
			}
			else if(!strncmp("ATM.Link.", LowerLayer, 9)){
				atmLinkIid.level = 1;
				sscanf(LowerLayer, "ATM.Link.%hhu", &atmLinkIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK, &atmLinkIid, &atmLinkObj);
				strcpy(CurrEncapsulation, "PPPoA");
				strcpy(CurrType, "ATM");
				memcpy(&atmLinkQosIid, &atmLinkIid, sizeof(objIndex_t));
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK_QOS, &atmLinkQosIid, &atmLinkQosObj);
				break;
			}
			else{
				return ZCFG_REQUEST_REJECT;
				//break;
			}
		}
		else if(!strncmp("Ethernet.VLANTermination.", HigherLayer, 25)){
			if(!strncmp("Ethernet.Link.", LowerLayer, 14)){
				ethLinkIid.level = 1;
				sscanf(LowerLayer, "Ethernet.Link.%hhu", &ethLinkIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ETH_LINK, &ethLinkIid, &ethLinkObj);
				HigherLayer = LowerLayer;
				LowerLayer = json_object_get_string(json_object_object_get(ethLinkObj, "LowerLayers"));
			}
			else{
				return ZCFG_REQUEST_REJECT;
				//break;
			}
		}
		else if(!strncmp("Ethernet.Link.", HigherLayer, 14)){
			if(!strncmp("ATM.Link.", LowerLayer, 9)){
				atmLinkIid.level = 1;
				sscanf(LowerLayer, "ATM.Link.%hhu", &atmLinkIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK, &atmLinkIid, &atmLinkObj);
				strcpy(CurrType, "ATM");
				memcpy(&atmLinkQosIid, &atmLinkIid, sizeof(objIndex_t));
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ATM_LINK_QOS, &atmLinkQosIid, &atmLinkQosObj);
				break;
			}
			if(!strncmp("PTM.Link.", LowerLayer, 9)){
				ptmLinkIid.level = 1;
				sscanf(LowerLayer, "PTM.Link.%hhu", &ptmLinkIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_PTM_LINK, &ptmLinkIid, &ptmLinkObj);
				strcpy(CurrType, "PTM");
				break;
			}
			if(!strncmp("Ethernet.Interface.", LowerLayer, 19)){
				ethIfaceIid.level = 1;
				sscanf(LowerLayer, "Ethernet.Interface.%hhu", &ethIfaceIid.idx[0]);
				zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ETH_IFACE, &ethIfaceIid, &ethIfaceObj);
				strcpy(CurrType, "ETH");
				if(json_object_get_boolean(json_object_object_get(ethIfaceObj, "Upstream")) == false){
					if(json_object_get_boolean(json_object_object_get(ethLinkObj, "X_ZYXEL_OrigEthWAN")) == false){
						return ZCFG_REQUEST_REJECT;
						//break;
					}
				}
			}
			else if(!strcmp("", LowerLayer)){
				if(json_object_get_boolean(json_object_object_get(ethLinkObj, "X_ZYXEL_OrigEthWAN")) == false){
					return ZCFG_REQUEST_REJECT;
					//break;
				}
			}
			else{
				return ZCFG_REQUEST_REJECT;
				//break;
			}
		}
	}

	if(isDelete)
		return ZCFG_SUCCESS;

	if(Type == NULL)
		Type = CurrType;

	//dont allow to change Type
	if(strcmp(CurrType, Type))
		return ZCFG_REQUEST_REJECT;

	if(!strcmp(Mode, "IP_Bridged")){
		json_object_object_add(Jobj, "IGMPEnable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "MLDEnable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "sysGwEnable", json_object_new_boolean(false));
		json_object_object_add(Jobj, "sysGw6Enable", json_object_new_boolean(false));
		return ret;
	}

	if(!strcmp(CurrEncapsulation, "IPoE") || !strcmp(CurrEncapsulation, "IPoA")){
		v4enable = json_object_get_boolean(json_object_object_get(ipIfaceObj, "IPv4Enable"));
		v6enable = json_object_get_boolean(json_object_object_get(ipIfaceObj, "IPv6Enable"));
	}
	else{ //PPPoE or PPPoA
		v4enable = json_object_get_boolean(json_object_object_get(ipIfaceObj, "IPCPEnable"));
		v6enable = json_object_get_boolean(json_object_object_get(ipIfaceObj, "IPv6CPEnable"));
	}

	if(v4enable && v6enable)
		strcpy(CurrIpMode, "DualStack");
	else if(v4enable)
		strcpy(CurrIpMode, "IPv4");
	else if(v6enable)
		strcpy(CurrIpMode, "IPv6");

	if(Encapsulation == NULL)
		Encapsulation = CurrEncapsulation;
	if(ipMode == NULL)
		ipMode = CurrIpMode;

	getSpecificObj(RDM_OID_DHCPV4_CLIENT, "Interface", json_type_string, ipIfacePath, &v4ClientIid, &v4ClientObj);
	if(v4ClientObj){
		getDhcpv4ClientOpt(&v4ClientIid);
		if(!strcmp(CurrIpMode, "IPv4"))
			CurrEnable_6RD = json_object_get_boolean(json_object_object_get(ipIfaceObj, "X_ZYXEL_Enable_6RD"));
		
		if(CurrEnable_6RD)
			strcpy(CurrV6RD_Type, json_object_get_string(json_object_object_get(ipIfaceObj, "X_ZYXEL_6RD_Type")));
	}

	Enable_6RD = false;
	if(!strcmp(ipMode, "IPv4")){
		pramJobj = json_object_object_get(Jobj, "Enable_6RD");
		if(pramJobj)
			Enable_6RD = json_object_get_boolean(pramJobj);
		else
			Enable_6RD = CurrEnable_6RD;

		if(Enable_6RD){
			pramJobj = json_object_object_get(Jobj, "v6RD_Type");
			if(pramJobj){
				v6RD_Type = json_object_get_string(json_object_object_get(Jobj, "v6RD_Type"));
			}
			else{
				if(strcmp(CurrV6RD_Type, ""))
					v6RD_Type = CurrV6RD_Type;
				else{
					strcpy(CurrV6RD_Type, "dhcp");
					v6RD_Type = CurrV6RD_Type;
				}
			}

			if(!strcmp(v6RD_Type, "dhcp"))
				json_object_object_add(Jobj, "option212Enable", json_object_new_boolean(true));
		}
	}

	//NAT
	getSpecificObj(RDM_OID_NAT_INTF_SETTING, "Interface", json_type_string, ipIfacePath, &natIntfIid, &natIntfObj);
	getSpecificObj(RDM_OID_ROUTING_RIP_INTF_SET, "Interface", json_type_string, ipIfacePath, &ripIid, &ripObj);

	//Default Gateway
	IID_INIT(routerIid);
	routerIid.level = 1;
	routerIid.idx[0] = 1;
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ROUTING_ROUTER, &routerIid, &routerObj);
	
	//static ipv4 Addr
	IID_INIT(v4AddrIid);
#if 1
	v4AddrIid.level = 2;
	v4AddrIid.idx[0] = ipIfaceIid.idx[0];
	v4AddrIid.idx[1] = 1;
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_IP_IFACE_V4_ADDR, &v4AddrIid, &v4AddrObj);
	if(v4AddrObj){
		AddressingType = json_object_get_string(json_object_object_get(v4AddrObj, "AddressingType"));
		Enable = json_object_get_string(json_object_object_get(v6AddrObj, "Enable"));
		if(Enable == true && !strcmp(AddressingType, "Static")){
			CurrIpStatic = true;
		}
	}
#else
	while(zcfgFeSubInObjJsonGetNextWithoutUpdate(RDM_OID_IP_IFACE_V4_ADDR, &ipIfaceIid, &v4AddrIid, &v4AddrObj) == ZCFG_SUCCESS){
		AddressingType = json_object_get_string(json_object_object_get(v4AddrObj, "AddressingType"));
		if(!strcmp(AddressingType, "Static")){
			break;
		}
		zcfgFeJsonObjFree(v4AddrObj);
	}
#endif
	//if(CurrIpStatic){
		IID_INIT(v4FwdIid);
		while(zcfgFeSubInObjJsonGetNextWithoutUpdate(RDM_OID_ROUTING_ROUTER_V4_FWD, &routerIid, &v4FwdIid, &v4FwdObj) == ZCFG_SUCCESS){
			Interface = json_object_get_string(json_object_object_get(v4FwdObj, "Interface"));
			Origin = json_object_get_string(json_object_object_get(v4FwdObj, "Origin"));
			//if(!strcmp(Interface, ipIfacePath) && !strcmp(Origin, "Static")){
			if(!strcmp(Interface, ipIfacePath)){
				DestSubnetMask = json_object_get_string(json_object_object_get(v4FwdObj, "DestSubnetMask"));
				DestIPAddress = json_object_get_string(json_object_object_get(v4FwdObj, "DestIPAddress"));
				if(!strcmp(DestIPAddress, "") && !strcmp(DestSubnetMask, "")){
					break;
				}
			}
			zcfgFeJsonObjFree(v4FwdObj);
		}
	//}

	//static ipv6 Addr
	IID_INIT(v6AddrIid);
#if 1
	v6AddrIid.level = 2;
	v6AddrIid.idx[0] = ipIfaceIid.idx[0];
	v6AddrIid.idx[1] = 1;
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_IP_IFACE_V6_ADDR, &v6AddrIid, &v6AddrObj);
	if(v6AddrObj){
		Origin = json_object_get_string(json_object_object_get(v6AddrObj, "Origin"));
		Enable = json_object_get_string(json_object_object_get(v6AddrObj, "Enable"));
		if(Enable == true && !strcmp(Origin, "Static")){
			CurrIp6Static = true;
		}
	}
#else
	while(zcfgFeSubInObjJsonGetNextWithoutUpdate(RDM_OID_IP_IFACE_V6_ADDR, &ipIfaceIid, &v6AddrIid, &v6AddrObj) == ZCFG_SUCCESS){
		Origin = json_object_get_string(json_object_object_get(v6AddrObj, "Origin"));
		if(!strcmp(Origin, "Static")){
			CurrIp6Static = true;
			break;
		}
		zcfgFeJsonObjFree(v6AddrObj);
	}
#endif
	//if(CurrIp6Static){
		IID_INIT(v6FwdIid);
		while(zcfgFeSubInObjJsonGetNextWithoutUpdate(RDM_OID_ROUTING_ROUTER_V6_FWD, &routerIid, &v6FwdIid, &v6FwdObj) == ZCFG_SUCCESS){
			Interface = json_object_get_string(json_object_object_get(v6FwdObj, "Interface"));
			Origin = json_object_get_string(json_object_object_get(v6FwdObj, "Origin"));
			//if(!strcmp(Interface, ipIfacePath) && !strcmp(Origin, "Static")){
			if(!strcmp(Interface, ipIfacePath)){
				DestIPPrefix = json_object_get_string(json_object_object_get(v6FwdObj, "DestIPPrefix"));
				if(!strcmp(DestIPPrefix, "::/0") || !strcmp(DestIPPrefix, "")){
					break;
				}
			}
			zcfgFeJsonObjFree(v6FwdObj);
		}
	//}

	//static DNS
	IID_INIT(iid);
	while(zcfgFeObjJsonGetNextWithoutUpdate(RDM_OID_DNS_CLIENT_SRV, &iid, &obj) == ZCFG_SUCCESS){
		Interface = json_object_get_string(json_object_object_get(obj, "Interface"));
		X_ZYXEL_Type = json_object_get_string(json_object_object_get(obj, "X_ZYXEL_Type"));
		if(!strcmp(Interface, ipIfacePath) && !strcmp(X_ZYXEL_Type, "Static")){
			DNSServer = json_object_get_string(json_object_object_get(obj, "DNSServer"));
			if((strchr(DNSServer, ':') == NULL) && (dnsClientSrv4Obj == NULL)){
				dnsClientSrv4Obj = obj;
				memcpy(&dnsClientSrv4Iid, &iid, sizeof(objIndex_t));
			}
			else if(dnsClientSrv6Obj == NULL){
				dnsClientSrv6Obj = obj;
				memcpy(&dnsClientSrv6Iid, &iid, sizeof(objIndex_t));
			}
			else{
				zcfgFeJsonObjFree(obj);
			}
		}
		else if(!strcmp(Interface, ipIfacePath) && strcmp(X_ZYXEL_Type, "Static")){
			DNSServer = json_object_get_string(json_object_object_get(obj, "DNSServer"));
			if((strchr(DNSServer, ':') == NULL) && (dynamicDnsClientSrv4Obj == NULL)){
				dynamicDnsClientSrv4Obj = obj;
				memcpy(&dynamicDnsClientSrv4Iid, &iid, sizeof(objIndex_t));
			}
			else if(dynamicDnsClientSrv6Obj == NULL){
				dynamicDnsClientSrv6Obj = obj;
				memcpy(&dynamicDnsClientSrv6Iid, &iid, sizeof(objIndex_t));
			}
			else{
				zcfgFeJsonObjFree(obj);
			}
		}
		else{
			zcfgFeJsonObjFree(obj);
		}
	}
	
	//IGMP, MLD
	IID_INIT(igmpIid);
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ZY_IGMP, &igmpIid, &igmpObj);
	IID_INIT(mldIid);
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_ZY_MLD, &mldIid, &mldObj);

	IID_INIT(dnsIid);
	zcfgFeObjJsonGetWithoutUpdate(RDM_OID_DNS, &dnsIid, &dnsObj);

	return ret;
}

void deleteUnnecessaryObj(){

	bool delPpp = false, delVlanEthLink = false;

	printf("CurrMode=%s, Mode=%s\n", CurrMode, Mode);

	if(!strcmp(CurrMode, "IP_Routed") && !strcmp(Mode, "IP_Bridged")){
		if(strstr(CurrEncapsulation, "PPP"))
			delPpp = true;
	}
	else if(!strcmp(CurrMode, "IP_Routed") && !strcmp(Mode, "IP_Routed")){
		if((!strcmp(CurrEncapsulation, "PPPoA") || !strcmp(CurrEncapsulation, "PPPoE")) &&
		   (!strcmp(Encapsulation, "IPoA") || !strcmp(Encapsulation, "IPoE"))){
		   delPpp = true;
		}
		if((!strcmp(CurrEncapsulation, "PPPoE") || !strcmp(CurrEncapsulation, "IPoE")) &&
		   (!strcmp(Encapsulation, "PPPoA") || !strcmp(Encapsulation, "IPoA"))){
		   delVlanEthLink = true;
		}
	}
	else if(!strcmp(CurrMode, "IP_Bridged") && !strcmp(Mode, "IP_Routed")){
		if(!strcmp(Encapsulation, "PPPoA") || !strcmp(Encapsulation, "IPoA"))
			delVlanEthLink = true;
	}

	if(delPpp){
		printf("delPpp\n");
		zcfgFeObjJsonDel(RDM_OID_PPP_IFACE, &pppIfaceIid, NULL);
		zcfgFeJsonObjFree(pppIfaceObj);
	}

	if(delVlanEthLink){
		printf("delVlanEthLink\n");
		zcfgFeObjJsonDel(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, NULL);
		zcfgFeObjJsonDel(RDM_OID_ETH_LINK, &ethLinkIid, NULL);
		zcfgFeJsonObjFree(vlanTermObj);
		zcfgFeJsonObjFree(ethLinkObj);
	}
}

zcfgRet_t zcfgFeDalWanAdd(struct json_object *Jobj, char *replyMsg)
{
	zcfgRet_t ret = ZCFG_SUCCESS;

	isAdd = true;
	isDelete = false;
	initGlobalObjects();
	getBasicInfo(Jobj);

	//check if duplicate Name exist
	if(getSpecificObj(RDM_OID_IP_IFACE, "X_ZYXEL_SrvName", json_type_string, Name, NULL, NULL))
		return ZCFG_REQUEST_REJECT;
	
	if((ret = AddandCheckDefaultParam(Jobj)) != ZCFG_SUCCESS)//for CLI
		return ret;

	if((ret = editPhyLayerObjects(Jobj)) != ZCFG_SUCCESS)
		return ret;

	if((ret = editEthLinkObject(Jobj)) != ZCFG_SUCCESS)
		return ret;

	if((ret = editVlanTermObject(Jobj)) != ZCFG_SUCCESS)
		return ret;

	if((ret = addLayer3Objects(Jobj)) != ZCFG_SUCCESS)
		return ret;

	t2 = time(NULL);
    printf("before set, time=%d seconds\n", (int) difftime(t2, t1));
	
	setAllObjects(Jobj);

	t2 = time(NULL);
    printf("after set, time=%d seconds ret=%d\n", (int) difftime(t2, t1), ret);

	freeAllObjects();
	
	return ret;
}

zcfgRet_t zcfgFeDalWanEdit(struct json_object *Jobj, char *replyMsg){
	zcfgRet_t ret = ZCFG_SUCCESS;

	isAdd = false;
	isDelete = false;
	initGlobalObjects();
	getBasicInfo(Jobj);

	t2 = time(NULL);
    printf("line=%d, time=%d\n", __LINE__, (int) difftime(t2, t1));
	
	if ((ret = getCurrentConfig(Jobj)) != ZCFG_SUCCESS)
		goto dalwan_edit_fail;

	t2 = time(NULL);
    printf("line=%d, time=%d\n", __LINE__, (int) difftime(t2, t1));

	//disable ipIface first
	json_object_object_add(ipIfaceObj, "Enable", json_object_new_boolean(false));
	zcfgFeObjJsonSet(RDM_OID_IP_IFACE, &ipIfaceIid, ipIfaceObj, NULL);
	
	//Always clean dynamic dns
	if(dynamicDnsClientSrv4Obj){
		json_object_object_add(dynamicDnsClientSrv4Obj, "Interface", json_object_new_string(""));
		zcfgFeObjJsonSetWithoutApply(RDM_OID_DNS_CLIENT_SRV, &dynamicDnsClientSrv4Iid, dynamicDnsClientSrv4Obj, NULL);
		zcfgFeJsonObjFree(dynamicDnsClientSrv4Obj);
	}
	if(dynamicDnsClientSrv6Obj){
		json_object_object_add(dynamicDnsClientSrv6Obj, "Interface", json_object_new_string(""));
		zcfgFeObjJsonSetWithoutApply(RDM_OID_DNS_CLIENT_SRV, &dynamicDnsClientSrv6Iid, dynamicDnsClientSrv6Obj, NULL);
		zcfgFeJsonObjFree(dynamicDnsClientSrv6Obj);
	}
	
	deleteUnnecessaryObj();
	
	if((ret = editPhyLayerObjects(Jobj)) != ZCFG_SUCCESS)
		goto dalwan_edit_fail;
	
	if((ret = editEthLinkObject(Jobj)) != ZCFG_SUCCESS)
		goto dalwan_edit_fail;

	if((ret = editVlanTermObject(Jobj)) != ZCFG_SUCCESS)
		goto dalwan_edit_fail;
	
    printf("line=%\n", __LINE__);
	
	if((ret = editLayer3Objects(Jobj)) != ZCFG_SUCCESS)
		goto dalwan_edit_fail;

    printf("line=%d\n", __LINE__);

	t2 = time(NULL);
    printf("before set, time=%d seconds\n", (int) difftime(t2, t1));
	
	setAllObjects(Jobj);

dalwan_edit_fail:
	freeAllObjects();
	
	return ret;
}

zcfgRet_t zcfgFeDalWanDelete(struct json_object *Jobj, char *replyMsg){
	zcfgRet_t ret = ZCFG_SUCCESS;

	isDelete = true;
	initGlobalObjects();
	getBasicInfo(Jobj);
	getCurrentConfig(Jobj);

	if(ipIfaceObj)
		zcfgFeObjJsonDel(RDM_OID_IP_IFACE, &ipIfaceIid, NULL);

	if(pppIfaceObj)
		zcfgFeObjJsonDel(RDM_OID_IP_IFACE, &pppIfaceIid, NULL);

	if(vlanTermObj)
		zcfgFeObjJsonDel(RDM_OID_ETH_VLAN_TERM, &vlanTermIid, NULL);

	if(ethLinkObj)
		zcfgFeObjJsonDel(RDM_OID_ETH_LINK, &ethLinkIid, NULL);

	if(ptmLinkObj){
		if(!isXTMLinkHasReference(Jobj))
			zcfgFeObjJsonDel(RDM_OID_PTM_LINK, &ptmLinkIid, NULL);
	}

	if(atmLinkObj){
		if(!isXTMLinkHasReference(Jobj))
			zcfgFeObjJsonDel(RDM_OID_ATM_LINK, &atmLinkIid, NULL);
	}

	freeAllObjects();
	return ret;
}

zcfgRet_t zcfgFeDalWan(const char *method, struct json_object *Jobj, char *replyMsg){
	zcfgRet_t ret = ZCFG_SUCCESS;

	t1 = time(NULL);
	
	if(!strcmp(method, "POST"))
		ret = zcfgFeDalWanAdd(Jobj, NULL);
	else if(!strcmp(method, "PUT"))
		ret = zcfgFeDalWanEdit(Jobj, NULL);
	else if(!strcmp(method, "DELETE"))
		ret = zcfgFeDalWanDelete(Jobj, NULL);
	else
		printf("Unknown method:%s\n", method);

	t2 = time(NULL);
    printf("zcfgFeDalWan() Total time=%d seconds ret=%d\n", (int) difftime(t2, t1), ret);

	return ret;
}


