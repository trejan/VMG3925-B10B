#include "zcfg_common.h"
#include <json/json.h>
#include <netinet/in.h>

#include "zcfg_fe_dal_common.h"

#define isdigit(c) ((c >= 0x30) && (c < 0x3A))


extern dal_param_t WAN_param[];

extern zcfgRet_t zcfgFeDalWan(const char *method, struct json_object *Jobj, char *replyMsg);


typedef struct dal_handler_s {
	char				*name;
	dal_param_t			*parameter;
	int					(*handler)(const char*, struct json_object *, char *);
}dal_handler_t;


dal_handler_t dalHandler[] = {
{"WAN",				WAN_param,			zcfgFeDalWan},
{NULL,				NULL,				NULL}
};

static bool validateIPv6(const char *ipStr){

	struct in6_addr ip6addr;
	
	if (inet_pton(AF_INET6, ipStr, &ip6addr) <= 0)
		return false;

	return true;
} 


static bool validateIPv4(const char *ipStr){
	int i, cnt = 0, value;
	const char *cp = ipStr;

	if(ipStr == NULL)
		return false;
	
	for(; *cp != '\0'; cp++) {
		if (*cp == '.')
			cnt++;
		else if((!isdigit(*cp)) && (*cp != '.')) {
			return false;
		}
	}
	if (cnt !=3)
		return false;

	cnt =0;
	cp = ipStr;
	for(i = 24; i >= 0; i -= 8) {
		if((*cp == '\0') || (*cp == '.'))
			return false;
		
		value = atoi(cp);
		if((value > 255) || (value < 0))
			return false;

		cnt++;
		if((cp = strchr(cp, '.')) == NULL)
			break;			
		cp++;
	}
	
	if(cnt != 4)
		return false;

	return true;
} 

bool validateParam(struct json_object *Jobj, dal_param_t *paramList)
{
	int i;
	struct json_object *pramJobj = NULL;
	const char *stringPtr = NULL;
	char *ptr = NULL;
	char buf[64] = {0};
	int intValue = 0, len;
	bool ret = false;

	if(Jobj == NULL || paramList == NULL)
		return true;
	
	for(i=0;paramList[i].paraName;i++){
		if((pramJobj = json_object_object_get(Jobj, paramList[i].paraName)) != NULL){
			printf("o_type=%d\n", json_object_get_type(pramJobj));
			if(paramList[i].validate != NULL){
				ret = paramList[i].validate(paramList[i].type);
				return ret;
			}
			else{
				switch(paramList[i].type){
					case dalType_string:
						stringPtr = json_object_get_string(pramJobj);
						printf("%s\t\t%s\n",  paramList[i].paraName, stringPtr);
						len = strlen(stringPtr);
						if(paramList[i].min || paramList[i].max){ // if min ==0 and max ==0, skip
							if(len<paramList[i].min || len>paramList[i].max)
								return false;
						}
						break;
					case dalType_int:
						intValue = json_object_get_int(pramJobj);
						printf("%s\t\t%d\n",  paramList[i].paraName, intValue);
						if(paramList[i].min || paramList[i].max){
							if(intValue<paramList[i].min || intValue>paramList[i].max)
								return false;
						}
						break;
					case dalType_boolean:
						intValue = json_object_get_boolean(pramJobj);
						printf("%s\t\t%d\n",  paramList[i].paraName, intValue);
						break;
					case dalType_v4Addr:
					case dalType_v4Mask:
						stringPtr = json_object_get_string(pramJobj);
						printf("%s\t\t%s\n",  paramList[i].paraName, stringPtr);
						if(validateIPv4(stringPtr) == false)
							return false;
						break;
					case dalType_v6Addr:
						stringPtr = json_object_get_string(pramJobj);
						printf("%s\t\t%s\n",  paramList[i].paraName, stringPtr);
						if(validateIPv6(stringPtr) == false)
							return false;
						break;
					case dalType_v6AddrPrefix: //ex. 2001:123::11:22:33/64
						stringPtr = json_object_get_string(pramJobj);
						printf("%s\t\t%s\n",  paramList[i].paraName, stringPtr);
						strcpy(buf, stringPtr);
						ptr = strchr(buf, '/');
						*ptr = '\0';
						intValue = atoi(ptr+1);
						printf("v6addr=%s, prefix=%d\n", buf, intValue);
						if(intValue<0 || intValue>64)
							return false;
						if(validateIPv6(buf) == false)
							return false;
						break;
					default:
						break;
				}
			}
		}
	}

	return true;
}

zcfgRet_t zcfgFeDalHandler(const char *handlerName, const char *method, struct json_object *Jobj, char *replyMsg){
	zcfgRet_t ret = ZCFG_SUCCESS;
	int i = 0, found = 0;

	if(handlerName == NULL)
		return ret;
	
	for(i=0; dalHandler[i].name != NULL; i++){
		if(!strcmp(handlerName, dalHandler[i].name)){
			found =1;
			break;
		}
	}

	printf("handlerName=%s method=%s i=%d\n", handlerName, method, i);

	if(!found){
		printf("Unknown handlerName:%s\n", handlerName);
		return ret;
	}

	if(validateParam(Jobj, dalHandler[i].parameter) == false)
		return ZCFG_INVALID_PARAM_VALUE;

	if(dalHandler[i].handler != NULL)
		ret = dalHandler[i].handler(method, Jobj, replyMsg);

	return ret;
}



